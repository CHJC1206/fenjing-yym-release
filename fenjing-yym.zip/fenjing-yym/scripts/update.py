#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键更新：检查版本 → 打印计划 → 确认 → 更新（含备份与回滚）。

用法：
    python scripts/update.py          # 交互：有新版才问，y 才更新
    python scripts/update.py --yes    # 不问，直接更新（仍先打印计划）
    python scripts/update.py --check  # 只检查，不更新

更新源取值：--source > 环境变量 FENJING_UPDATE_SOURCE > config.json 的 update_source > 内置默认源。
只想看深层细节时，仍可单独使用 update_check.py / update_apply.py。
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = sys.executable


def run(script, *args):
    cmd = [PY, str(ROOT / "scripts" / script)] + list(args)
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def main(argv=None):
    ap = argparse.ArgumentParser(description="一键更新技能")
    ap.add_argument("--source", default=None, help="留空用默认源")
    ap.add_argument("--yes", action="store_true", help="不询问，直接更新")
    ap.add_argument("--check", action="store_true", help="只检查")
    args = ap.parse_args(argv)

    src_args = ["--source", args.source] if args.source else []

    code, out = run("update_check.py", *src_args, "--json")
    try:
        info = json.loads(out[out.find("{"):out.rfind("}") + 1])
    except Exception:
        print("检查失败：\n%s" % out.strip())
        return 2

    status = info.get("status")
    if not info.get("ok"):
        print(info.get("detail") or out.strip())
        return 2

    print("本地 %s ／ 远端 %s" % (info.get("local"), info.get("remote")))
    if status == "same":
        print("已是最新，无需更新。")
        return 0
    if status == "local_ahead":
        print("本地版本比远端高（可能你本地改过），不更新。")
        return 0

    print("发现新版本：%s" % info.get("notes", ""))
    if info.get("package_url"):
        print("安装包直链：%s" % info["package_url"])

    code, out = run("update_apply.py", *src_args, "--dry-run")
    print("\n" + out.strip())

    if args.check:
        print("\n（--check 模式：未执行更新）")
        return 1

    if not args.yes:
        try:
            ans = input("\n是否现在更新？输入 y 确认，其他键取消：").strip().lower()
        except EOFError:
            ans = ""
        if ans not in ("y", "yes"):
            print("已取消，未做任何改动。")
            return 0

    code, out = run("update_apply.py", *src_args, "--apply")
    print("\n" + out.strip())
    return code


if __name__ == "__main__":
    sys.exit(main())
