#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查 fenjing-yym 是否有新版本（只读：不下载、不解压、不执行任何东西）。

用法：
    python scripts/update_check.py --source "<共享盘目录或 version.json 的 http 地址>"
    python scripts/update_check.py --source ... --json

退出码：0 已是最新 / 1 有新版本 / 2 无法访问更新源
只用标准库。
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_SOURCE = "https://raw.githubusercontent.com/CHJC1206/fenjing-yym-release/main"
DEFAULT_SOURCE_HINT = "更新源见 SKILL.md 的 BO-09，默认 " + DEFAULT_SOURCE


def github_api_url(url):
    """把 raw.githubusercontent.com/<o>/<r>/<ref>/<path> 映射成 api 端点，绕过 raw 的 CDN 缓存。"""
    m = re.match(r"https?://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)", url)
    if not m:
        return None
    owner, repo, ref, path = m.groups()
    return "https://api.github.com/repos/%s/%s/contents/%s?ref=%s" % (owner, repo, path, ref)


def load_manifest(src):
    src = str(src)
    if src.startswith(("http://", "https://")):
        if not src.lower().endswith(".json"):
            src = src.rstrip("/") + "/version.json"
        api = github_api_url(src)
        targets = [api, src] if api else [src]
        last = None
        for i in range(3):
            try:
                for target in targets:
                    try:
                        req = urllib.request.Request(target, headers={"User-Agent": "fenjing-update/1.0", "Accept": "application/vnd.github.raw"})
                        with urllib.request.urlopen(req, timeout=12) as r:
                            return json.loads(r.read().decode("utf-8"))
                    except Exception as inner:  # noqa: BLE001
                        last = inner
                        continue
                raise last
            except Exception as e:  # noqa: BLE001
                last = e
                if getattr(e, "code", None) == 404:
                    raise
                if i < 2:
                    time.sleep(2)
        raise last
    p = Path(src)
    if p.is_dir():
        p = p / "version.json"
    return json.loads(p.read_text(encoding="utf-8"))


def resolve_source(arg):
    """--source > 环境变量 FENJING_UPDATE_SOURCE > config.json 的 update_source > 内置默认源。"""
    if arg:
        return arg
    env = os.environ.get("FENJING_UPDATE_SOURCE")
    if env:
        return env
    cfg = ROOT / "config.json"
    if cfg.is_file():
        try:
            d = json.loads(cfg.read_text(encoding="utf-8"))
            if d.get("update_source"):
                return d["update_source"]
        except Exception:
            pass
    return DEFAULT_SOURCE


def probe_package(url):
    """轻量探测安装包是否可下载（只看状态码，不落盘）。返回 (ok, note)。"""
    if not url:
        return True, "未提供 package_url，跳过探测"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "fenjing-update/1.0"}, method="HEAD")
        with urllib.request.urlopen(req, timeout=12) as r:
            size = r.headers.get("Content-Length")
            return True, "安装包可达%s" % ("（%s 字节）" % size if size else "")
    except Exception as e:  # noqa: BLE001
        code = getattr(e, "code", None)
        if code in (403, 405):  # 不支持 HEAD，退回读首字节
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "fenjing-update/1.0",
                                                           "Range": "bytes=0-0"})
                with urllib.request.urlopen(req, timeout=12) as r:
                    r.read(1)
                return True, "安装包可达（HEAD 不支持，已用 Range 探测）"
            except Exception as e2:  # noqa: BLE001
                return False, "安装包不可下载：%s" % e2
        if code == 404:
            return False, "清单里写的安装包地址 404：%s（可能只传了 version.json，忘了传 zip）" % url
        return False, "安装包探测失败：%s" % e


def ver_tuple(v):
    out = []
    for x in str(v).replace("-", ".").split("."):
        out.append(int(x) if x.isdigit() else 0)
    return tuple(out)


def main(argv=None):
    ap = argparse.ArgumentParser(description="检查技能版本（只读）")
    ap.add_argument("--source", default=None, help="留空则用 config.json 的 update_source，或内置默认源")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--no-probe", action="store_true", help="不探测安装包是否可下载")
    args = ap.parse_args(argv)

    local = load_manifest(str(ROOT))
    source = resolve_source(args.source)
    if not source:
        print("没有可用的更新源：请用 --source 指定，或写入 config.json 的 update_source")
        return 2
    try:
        remote = load_manifest(source)
    except Exception as e:
        code = getattr(e, "code", None)
        if code == 404:
            msg = "更新源里没有 version.json（%s）——仓库可能还没上传发布文件" % source
        else:
            msg = "无法访问更新源：%s（%s）" % (source, e)
        if args.json:
            print(json.dumps({"ok": False, "status": "unreachable", "detail": msg}, ensure_ascii=False))
        else:
            print(msg)
            print("提示：%s" % DEFAULT_SOURCE_HINT)
        return 2

    lv = local.get("skill_version", "0")
    rv = remote.get("skill_version", "0")
    newer = ver_tuple(rv) > ver_tuple(lv)
    status = "newer" if newer else ("same" if ver_tuple(rv) == ver_tuple(lv) else "local_ahead")
    result = {
        "ok": True,
        "status": status,
        "local": lv,
        "remote": rv,
        "tables_local": local.get("tables_version", "—"),
        "tables_remote": remote.get("tables_version", "—"),
        "published_at": remote.get("published_at", "—"),
        "notes": remote.get("notes", ""),
        "package_url": remote.get("package_url", ""),
    }

    if newer and not args.no_probe:
        ok, note = probe_package(remote.get("package_url", ""))
        result["package_ok"] = ok
        result["package_note"] = note

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("== fenjing-yym 版本检查（只读）==")
        print("本地：%s（词表 %s）" % (lv, result["tables_local"]))
        print("远端：%s（词表 %s）" % (rv, result["tables_remote"]))
        if status == "newer":
            print("状态：有新版本（远端 %s 发布）" % result["published_at"])
            if result["notes"]:
                print("变更：%s" % result["notes"])
            if result["package_url"]:
                print("安装包直链：%s" % result["package_url"])
            if "package_note" in result:
                print("包探测：%s" % result["package_note"])
            print("下一步：python scripts/update.py            # 一键检查+更新")
            print("      或：python scripts/update_apply.py --source \"%s\" --dry-run" % source)
        elif status == "same":
            print("状态：已是最新")
        else:
            print("状态：本地版本高于远端（可能是本地改过或远端未更新）")
    return 1 if newer else 0


if __name__ == "__main__":
    sys.exit(main())
