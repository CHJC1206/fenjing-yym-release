# -*- coding: utf-8 -*-
"""清理旧版遗留文件（首次从旧版更新到内置版时用）。

旧版更新脚本只做逐项覆盖，会把旧分支文件（references/style-caiqian.md 等）留在目录里；
本脚本把「不在当前包清单内」的文件移入 _backup/obsolete-<时间戳>/，不直接删除。
"""
import json
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from _files import REQUIRED_FILES, KEEP_ON_UPDATE  # noqa: E402

KEEP_EXTRA = set(KEEP_ON_UPDATE) | {"version.json"}


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    fix = "--fix" in argv
    allow = {f.replace("/", "\\") for f in REQUIRED_FILES} | set(REQUIRED_FILES) | KEEP_EXTRA
    obsolete = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_dir():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if rel.startswith("_backup/") or "__pycache__" in rel or rel in allow:
            continue
        obsolete.append(p)
    if not obsolete:
        print("结构干净：没有旧版遗留文件")
        return 0
    print("发现 %d 个不在当前包内的文件：" % len(obsolete))
    for p in obsolete[:30]:
        print("  -", p.relative_to(ROOT).as_posix())
    if len(obsolete) > 30:
        print("  …其余 %d 个" % (len(obsolete) - 30))
    if not fix:
        print("\n加 --fix 把它们移入 _backup/obsolete-<时间戳>/，随后跑 python scripts/doctor.py")
        return 1
    dst = ROOT.parent / "_backup" / ("obsolete-" + time.strftime("%Y%m%d-%H%M%S"))
    dst.mkdir(parents=True, exist_ok=True)
    moved = 0
    for p in obsolete:
        rel = p.relative_to(ROOT)
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(p), str(target))
        moved += 1
    print("已移出 %d 个文件 → %s" % (moved, dst))
    print("下一步：python scripts/doctor.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
