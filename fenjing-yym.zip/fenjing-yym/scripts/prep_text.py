#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阶段一前置处理：清洗 → 字数 → 候选截断点 → BO-01 全局替换。

用法：
    python scripts/prep_text.py --input 原文.txt --name 导出稿名
    python scripts/prep_text.py --input 原文.txt --name 稿名 --out-dir ./_prep
    python scripts/prep_text.py --input 原文.txt --name 稿名 --min 4900 --max 5300
    python scripts/prep_text.py --input 原文.txt --name 稿名 --keep-all   # 不清洗

输出（默认写到 <out-dir>/_prep/）：
    <name>.clean.txt     清洗后纯正文
    <name>.replaced.txt  替换后正文（制作正文）
    <name>.prep.json     机器可读报告
    <name>.prep.md       人工核对报告

只做确定性工作：字数、候选点、替换。悬念点由模型从候选清单中判断。
替换表从 SKILL.md 的【后门 BO-01】表格解析，改表不需改脚本。
只用标准库。
"""

import argparse
import io
import tempfile
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
else:  # pragma: no cover
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL_ROOT = Path(__file__).resolve().parent.parent

CHAPTER_SENTINEL = "\x00CH\x00"
CHAPTER_RE = re.compile(
    r"^\s*[【\[「『（(]?\s*(第\s*[0-9０-９一二三四五六七八九十百千零两]+\s*[章节節回卷篇集话話]"
    r"|楔子|序章|序言|前言|引子|尾声|尾聲|后记|後記|番外|正文)\s*[】\]」』）)]?\s*[:：、.．]?\s*(.{0,30})$"
)
META_RE = re.compile(
    r"^\s*(作者|作\s*者|文案|简介|簡介|内容简介|标签|標籤|分类|分類|来源|來源|转自|轉自|"
    r"书名|書名|作品名|字数|字數|状态|狀態|更新|声明|聲明|版权|版權)\s*[:：]"
)
TAGLINE_RE = re.compile(r"^\s*([#＃][^\s#＃]+\s*)+$")
NUM_HEAD_RE = re.compile(r"^\s*[0-9０-９]{1,4}\s*[.．、]?\s*$")
INTRO_ANCHOR_RE = re.compile(r"^\s*(简介|簡介|内容简介|內容簡介|故事简介|文案|导语|導語)\s*[:：]")
SEP_RE = re.compile(r"^\s*[-=*_—－~～·\s]{3,}\s*$")
SUSPENSE = (
    "突然", "忽然", "竟", "却", "没想到", "不料", "谁知", "猛然", "骤然",
    "转身", "愣", "怔", "僵", "颤抖", "发白", "沉默", "抬头", "看见",
    "开门", "电话", "响", "血", "倒", "碎", "喊", "哭", "笑", "？", "！", "……",
)


def read_text(path):
    raw = Path(path).read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    raise SystemExit("无法识别文件编码，请转成 UTF-8 后重试：%s" % path)


def norm_newlines(s):
    return s.replace("\r\n", "\n").replace("\r", "\n")


def count_chars(s):
    """中文出版口径：非空白字符数；同时给出汉字数。"""
    non_space = len(re.sub(r"\s", "", s))
    cjk = len(re.findall(r"[\u3400-\u4dbf\u4e00-\u9fff]", s))
    return non_space, cjk


def load_backdoor_table(skill_md, section_key, header_cols=2):
    """解析 SKILL.md 中某个后门小节里的第一张两列表格。"""
    if not skill_md.is_file():
        return []
    text = norm_newlines(skill_md.read_text(encoding="utf-8"))
    idx = text.find(section_key)
    if idx < 0:
        return []
    block = text[idx:]
    m = re.search(r"\n#{1,6}\s", block[len(section_key):])
    if m:
        block = block[: len(section_key) + m.start()]
    rows, skip_sep = [], False
    for line in block.split("\n"):
        line = line.strip()
        if not line.startswith("|"):
            skip_sep = False
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) != header_cols:
            continue
        if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
            continue
        if cells[0] in ("原字", "显示名", "ID", "项", "子技能"):
            continue
        rows.append(cells)
    del skip_sep
    return rows



def load_anchor_table_from(path, anchor, cols=2):
    """从指定 md 文件按锚点取表（本地表 _local_tables.md 用）。"""
    if not path.is_file():
        return []
    text = norm_newlines(path.read_text(encoding="utf-8"))
    idx = -1
    for m in re.finditer(re.escape(anchor), text):
        tail = [l.strip() for l in text[m.end():].split("\n")]
        nxt = next((l for l in tail if l and not l.startswith("<!--")), "")
        if nxt.startswith("|"):
            idx = m.start()
            break
    if idx < 0:
        return []
    rows = []
    for line in text[idx:].split("\n")[1:]:
        line = line.strip()
        if not line.startswith("|"):
            if rows:
                break
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) != cols:
            continue
        if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
            continue
        if cells[0] in ("禁用", "原字", "原词", "语义类", "显示名", "项"):
            continue
        rows.append(cells)
    return rows


def load_anchor_table(anchor, cols=2):
    """解析 SKILL.md 中锚点标题之后的表格；优先取标题行内的命中，避免正文提及同名时截错位置。"""
    skill_md = SKILL_ROOT / "SKILL.md"
    if not skill_md.is_file():
        return []
    text = norm_newlines(skill_md.read_text(encoding="utf-8"))
    idx = -1
    for m in re.finditer(re.escape(anchor), text):
        tail = [l.strip() for l in text[m.end():].split("\n")]
        nxt = next((l for l in tail if l and not l.startswith("<!--")), "")
        if nxt.startswith("|"):
            idx = m.start()
            break
    if idx < 0:
        idx = text.find(anchor)
    if idx < 0:
        return []
    rows = []
    for line in text[idx:].split("\n")[1:]:
        line = line.strip()
        if not line.startswith("|"):
            if rows:
                break
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) != cols:
            continue
        if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
            continue
        if cells[0] in ("禁用", "原字", "原词", "语义类", "显示名", "项"):
            continue
        rows.append(cells)
    return rows


def clean_text(text):
    """保守清洗：只删明显不属于正文的行，并记录删了什么。"""
    lines = text.split("\n")
    kept, removed = [], []
    expect_num = None  # 章节序号序列：只删「接得上上一章」的纯数字行，正文里的孤立数字保留
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if not s:
            kept.append("")
            continue
        reason = None
        if SEP_RE.match(s):
            reason = "分隔线"
        elif TAGLINE_RE.match(s):
            reason = "标签行"
        elif META_RE.match(s):
            reason = "元信息（作者/文案/标签等）"
        elif NUM_HEAD_RE.match(s):
            v = int(re.sub(r"\D", "", s) or 0)
            if (expect_num is None and v == 1) or (expect_num is not None and v == expect_num):
                reason = "章节标记（纯数字）"
                expect_num = v + 1
        elif CHAPTER_RE.match(s) and len(s) <= 24 and not re.search(r"[。！？；…”」]", s):
            reason = "章节标题"
        elif re.match(r"^\s*#{1,6}\s", s):
            reason = "Markdown 标题"
        if reason:
            removed.append({"line": i, "reason": reason, "text": s[:80]})

        else:
            kept.append(line.rstrip())
    out = "\n".join(kept)
    out = re.sub(r"\n{3,}", "\n\n", out).strip("\n")
    return out, removed


def paragraphs(text):
    parts = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if len(parts) <= 1:
        parts = [p.strip() for p in text.split("\n") if p.strip()]
    return parts


def cut_candidates(text, lo, hi, limit=15):
    """段落末尾累计字数落在 [lo-500, hi+600] 的候选截断点。"""
    paras = paragraphs(text)
    total, out = 0, []
    for i, p in enumerate(paras):
        total += count_chars(p)[0]
        if lo - 500 <= total <= hi + 600:
            tail = p[-24:]
            hits = [w for w in SUSPENSE if w in tail]
            out.append(
                {
                    "段落序号": i + 1,
                    "累计字数": total,
                    "入区": lo <= total <= hi,
                    "悬念词": hits,
                    "尾句": tail,
                }
            )
    out.sort(key=lambda d: (not d["入区"], -len(d["悬念词"]), abs(d["累计字数"] - (lo + hi) // 2)))
    return total, out[:limit]


def apply_replace(text, table):
    counts, unknown_pairs = {}, []
    for src, dst in table:
        if not src:
            continue
        n = text.count(src)
        if n:
            text = text.replace(src, dst)
            counts[src] = {"replaced_to": dst, "count": n}
    return text, counts, unknown_pairs



def ngram_set(text, n=3):
    s = re.sub(r"\s+", "", text)
    if len(s) <= n:
        return {s} if s else set()
    return {s[i : i + n] for i in range(len(s) - n + 1)}


def overlap_ratio(a, b):
    """a 与 b 的字级 3-gram 重合度（以 a 为基准，0–1）。"""
    sa = ngram_set(a)
    if not sa:
        return 0.0
    sb = ngram_set(b)
    return len(sa & sb) / float(len(sa))


def strip_title(text, title):
    """删除书名：整行标题行整行删，行内出现则就地删，避免留下残句。"""
    title = title.strip().strip("《》").strip()
    if not title:
        return text, 0
    n = 0
    out = []
    for line in text.split("\n"):
        s = line.strip()
        # 疑似标题行：整行删，防止书名被截短后留下「，我走后……」这类残句
        if title in s and len(s) <= 40 and (s.startswith(title) or len(title) * 2 >= len(s)):
            n += 1
            continue
        if ("《%s》" % title) in line:
            n += line.count("《%s》" % title)
            line = line.replace("《%s》" % title, "")
        if title in line:
            n += line.count(title)
            line = line.replace(title, "")
        out.append(line)
    text = "\n".join(out)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip("\n"), n


def detect_title(text):
    """检测首行书名候选：返回 (候选, 依据) 或 (None, "")。"""
    paras = paragraphs(text)
    if not paras:
        return None, ""
    # 只取首段的第一行：清洗后书名行可能与简介行相邻
    first = paras[0].strip().split("\n")[0].strip()
    if len(first) > 30 or first[-1:] in "。！？…":
        return None, ""
    if first.startswith("《") and first.endswith("》"):
        return first, "书名号"
    if re.fullmatch(r"[《「『][^》」』]{1,28}[》」』]", first):
        return first, "书名号"
    return first, "首行短句（需人工确认）"


def sentence_hits(p, tail):
    """整句命中：p 里长度≥8 的句子有多少原样出现在 tail 中。"""
    sents = [s.strip() for s in re.split(r"(?<=[。！？…”])", p) if len(s.strip()) >= 8]
    if not sents:
        return 0.0, 0, 0
    hit = sum(1 for s in sents if s in tail)
    return hit / float(len(sents)), hit, len(sents)


def common_prefix_len(a, b):
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def intro_candidates(text, limit=6, threshold=0.30):
    """前几段与「其后正文」高度重合的段落，判定为「疑似简介」。不自动删除。"""
    paras = paragraphs(text)
    if len(paras) < 4:
        return []
    flagged = {}
    basis_map = {}
    for i, p in enumerate(paras[:limit], 1):
        if count_chars(p)[0] < 30:
            continue
        tail = "".join(paras[i:])
        if len(tail) < 60:
            continue
        r = overlap_ratio(p, tail)
        ratio, hit, total_s = sentence_hits(p, tail)
        nxt = paras[i] if i < len(paras) else ""
        prefix_hit = bool(nxt) and common_prefix_len(p, nxt) >= 10
        why = []
        if r >= threshold:
            why.append("与后文重合度 %.2f" % r)
        if total_s >= 3 and ratio >= 0.5:
            why.append("整句原样复现 %d/%d" % (hit, total_s))
        if prefix_hit:
            why.append("开头与下一段重复")
        if why:
            flagged[i] = max(r, ratio)
            basis_map[i] = "；".join(why)
    # 短残段（书名/标记残留）紧接命中段时并入同一块
    for i in sorted(flagged):
        j = i - 1
        while j >= 1 and count_chars(paras[j - 1])[0] < 30:
            flagged.setdefault(j, 0.0)
            j -= 1
    out = []
    for i in sorted(flagged):
        block = [i]
        # 合并连续段
        for k in list(flagged):
            if k == block[-1] + 1:
                block.append(k)
        if out and out[-1]["end"] >= block[0] - 1:
            out[-1]["end"] = max(out[-1]["end"], block[-1])
            out[-1]["字数"] += sum(count_chars(paras[x - 1])[0] for x in block[1:])
            continue
        block_text = "".join(paras[x - 1] for x in block)
        out.append(
            {
                "段落": "%d-%d" % (block[0], block[-1]) if len(block) > 1 else block[0],
                "end": block[-1],
                "字数": sum(count_chars(paras[x - 1])[0] for x in block),
                "重合度": round(max(flagged.get(x, 0.0) for x in block), 2),
                "依据": "；".join(basis_map.get(x, "") for x in block if basis_map.get(x)) or "与后文重合",
                "首20字": block_text[:20].replace("|", "｜"),
                "全文": block_text,
            }
        )
    # 简介不会太长：超过 900 字或占全文 30% 以上的块不按简介处理，避免把正文开头误判
    total = sum(count_chars(p)[0] for p in paras)
    cap = max(200, min(900, int(total * 0.30))) if total else 900
    out = [d for d in out if d["字数"] <= cap]
    return [{k: v for k, v in d.items() if k != "end"} for d in out]


def first_sentences(text, n=3, cap=90):
    """取正文开头 n 句，单句超长时截断并加省略号。"""
    out = []
    for s in re.split(r"(?<=[。！？…])", text):
        t = s.strip()
        if not t:
            continue
        out.append(t if len(t) <= cap else t[:cap] + "…")
        if len(out) >= n:
            break
    return out


INVISIBLE_RE = re.compile(r"[\ue000-\uf8ff\U000e0000-\U000e007f\u200b-\u200f\u2060\ufeff]")


def strip_invisible(text):
    """清除私用区与零宽/标签字符，返回 (text, 次数)。"""
    n = len(INVISIBLE_RE.findall(text))
    if n:
        text = INVISIBLE_RE.sub("", text)
    return text, n


def title_from_name(name, head):
    """导出稿名切词 × 原文前两行 双证判定书名。"""
    if not name:
        return None
    lines = [l.strip() for l in head.split("\n") if l.strip()][:2]
    head2 = "".join(lines)
    nm = name.strip().strip("《》").strip()
    # 整名优先：避免按标点切分后只删掉半句
    if nm and nm in head2:
        return nm
    for k in (10, 8, 6, 4):
        if len(nm) >= k and nm[:k] in head2:
            return nm[:k]
    return None



CN_DIGITS = {"零": 0, "〇": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
             "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}


def cn2num(s):
    """中文/阿拉伯章节号转整数，支持 1-99；无法解析返回 None。"""
    s = s.strip()
    if s.isdigit():
        return int(s)
    if "十" in s:
        left, _, right = s.partition("十")
        tens = CN_DIGITS.get(left, 1) if left else 1
        ones = CN_DIGITS.get(right, 0) if right else 0
        return tens * 10 + ones
    if len(s) == 1 and s in CN_DIGITS:
        return CN_DIGITS[s]
    return None


def head_num(s):
    """从标题行取章节序号，取不到返回 None。"""
    m = re.search(r"第\s*([0-9０-９一二三四五六七八九十百千零两]+)\s*[章节節回卷篇集话話]", s)
    if m:
        return cn2num(m.group(1).translate(str.maketrans("０１２３４５６７８９", "0123456789")))
    m = re.match(r"^\s*#*\s*([0-9０-９]{1,4})\s*[.．、]?\s*$", s)
    if m:
        return int(m.group(1).translate(str.maketrans("０１２３４５６７８９", "0123456789")))
    return None


def find_intro_block(lines, deep=False):
    """检测简介块：优先「简介：」锚点后的连续段落，其次首个章节标题前/两标题间的短块。

    deep=True 时放宽字数下限（20 字起）与上限（2000 字），用于「重新识别」。
    """
    lo_chars, hi_chars = (20, 2000) if deep else (60, 1200)
    # 1) 锚点优先：锚点行起，连续非空行，遇到章节标题或空行即停
    for i, raw_line in enumerate(lines, 1):
        s = raw_line.strip()
        if not INTRO_ANCHOR_RE.match(s):
            continue
        start, end, chars, capped = i, i, 0, False
        for j in range(i, len(lines) + 1):
            cur = lines[j - 1].strip()
            if not cur:
                break
            if j > i and len(cur) <= 40 and (CHAPTER_RE.match(cur) or NUM_HEAD_RE.match(cur)):
                break
            end = j
            chars += count_chars(cur)[0]
            if chars > 2000:
                capped = True
                break
        if chars >= 10:
            full = "".join(l.strip() for l in lines[start - 1:end])
            head = full[:20]
            return {"起": start, "止": end, "字数": chars, "首20字": head.replace("|", "｜"),
                    "全文": full, "来源": "简介锚点", "超长": capped}
        break

    def is_head(s):
        return bool(
            (CHAPTER_RE.match(s) and len(s) <= 40)
            or NUM_HEAD_RE.match(s)
            or re.match(r"^#{1,6}\s", s)
        )

    heads = [i for i, l in enumerate(lines, 1) if l.strip() and is_head(l.strip())]
    ranges = []
    if heads:
        ranges.append((1, heads[0] - 1, "首个标题前"))
        if len(heads) >= 2:
            n1, n2 = head_num(lines[heads[0] - 1].strip()), head_num(lines[heads[1] - 1].strip())
            # 两个标题指同一章（如「## 第1章」与「【第一章】」）时，中间那块才是简介/导语
            if n1 is not None and n1 == n2:
                ranges.append((heads[0] + 1, heads[1] - 1, "重复标题夹层"))
    else:
        ranges.append((1, len(lines), "全文无标题"))

    for lo, hi, origin in ranges:
        block, start_no, end_no, chars = [], None, None, 0
        for i in range(lo, hi + 1):
            s = lines[i - 1].strip()
            if not s:
                continue
            if SEP_RE.match(s) or TAGLINE_RE.match(s) or META_RE.match(s):
                continue
            if start_no is None:
                start_no = i
            end_no = i
            block.append(s)
            chars += count_chars(s)[0]
        if start_no and lo_chars <= chars <= hi_chars:
            # 块后面必须真有正文，否则整篇就是正文（无标题、已删过简介的情况），不能当前置块
            tail = [l.strip() for l in lines[end_no:] if l.strip()]
            if not tail:
                continue
            full = "".join(block)
            return {
                "起": start_no,
                "止": end_no,
                "字数": chars,
                "首20字": full[:20].replace("|", "｜"),
                "全文": full,
                "来源": origin,
                "超长": False,
            }
    return None


def sentence_at(text, idx):
    """取 idx 所在的整句（按中英文句末标点与换行切分）。"""
    left = max(text.rfind(ch, 0, idx) for ch in "。！？…\n；")
    left = 0 if left < 0 else left + 1
    rights = [text.find(ch, idx) for ch in "。！？…\n；"]
    rights = [r for r in rights if r >= 0]
    right = (min(rights) + 1) if rights else len(text)
    # 收尾引号/括号一并纳入，避免「你好凶。」丢掉后引号
    while right < len(text) and text[right] in "”’」』）)】\"'":
        right += 1
    return text[left:right].strip()


IDIOM_FIX = (
    ("凶神恶煞", "满脸煞气"),
    ("穷凶极恶", "丧心病狂"),
    ("凶相毕露", "戾气毕露"),
    ("凶多吉少", "九死一生"),
    ("凶横", "蛮横"),
    ("凶戾", "戾气"),
)


def suggest_rewrite(sent, ch):
    """给出可直接替换的整句建议。"""
    if ch == "血":
        out = sent
        for a, b in (("血液检查", "抽检"), ("浑身血液逆流", "浑身发冷"), ("血液逆流", "浑身一凉"),
                     ("血液", "身体"),
                     ("血肉模糊", "创口深重"), ("血淋淋的场面", "惨烈的场面"), ("血淋淋", "伤痕"),
                     ("血流成河", "殷红遍地"), ("血流如注", "殷红涌出"), ("血债血偿", "代价清算"),
                     ("血债", "代价"), ("血洗", "清算"), ("血战", "恶战"), ("血案", "命案"),
                     ("血书", "字条"), ("血亲", "亲眷"), ("血缘", "亲缘"), ("血脉", "本源"),
                     ("血性", "天性"), ("血气", "火气"), ("热血", "天性"), ("血统", "本源"),
                     ("血迹", "殷红"), ("血渍", "暗红痕迹"), ("血痕", "暗红痕迹"),
                     ("血污", "暗红痕迹"), ("血痂", "暗红结痂"), ("血滴", "殷红"),
                     ("血珠", "殷红"), ("血丝", "殷红"), ("血沫", "殷红"), ("血色", "气色"),
                     ("血腥", "腥气"), ("鲜血", "猩红"), ("血泊", "暗红液体"),
                     ("血水", "暗红液体"), ("流血", "殷红"), ("血", "殷红")):
            out = out.replace(a, b)
        return out
    if ch in ("巴掌", "耳光"):
        out = sent
        for a, b in (("一个巴掌拍不响", "一只手掌拍不响"), ("一巴掌", "一掌"), ("一记耳光", "一记掌掴"),
                     ("一个耳光", "一记掌掴"), ("一耳光", "一记掌掴"), ("巴掌大", "掌心大"),
                     ("巴掌心", "掌心"), ("手巴掌", "手掌"), ("巴掌印", "掌印"),
                     ("耳光", "掌掴"), ("巴掌", "手掌")):
            out = out.replace(a, b)
        return out
    if ch == "床":
        out = sent
        for a, b in (("上床", "回房休息"), ("床单", "褥单"), ("床铺", "铺位"), ("病床", "病榻")):
            out = out.replace(a, b)
        return out.replace("床", "榻")
    out = sent
    for a, b in IDIOM_FIX:
        out = out.replace(a, b)
    if "凶" not in out:
        return out
    if re.search(r"[好很太挺真]凶", out):
        return out.replace("凶", "吓人")
    return out.replace("凶", "狠")

def main(argv=None):
    ap = argparse.ArgumentParser(description="fenjing-yym 前置文本处理")
    ap.add_argument("--input", required=True, help="原文文件路径")
    ap.add_argument("--name", required=True, help="导出稿名称")
    ap.add_argument("--out-dir", default=None, help="输出目录，默认当前目录/_prep")
    ap.add_argument("--min", type=int, default=4900)
    ap.add_argument("--max", type=int, default=5300)
    ap.add_argument("--min-body", type=int, default=5000, help="正文字数门槛，低于即停止任务")
    ap.add_argument("--keep-all", action="store_true", help="跳过清洗")
    ap.add_argument("--title", default=None, help="书名，全局删除（含《》）")
    ap.add_argument("--drop", default=None, help="删除的段落号，如 1,2 或 1-3")
    ap.add_argument("--drop-lines", default=None, help="按原文行号删除，如 7-15")
    ap.add_argument("--rewrite-file", default=None, help="用户确认的改句 JSON：[{from,to}]")
    ap.add_argument("--intro-deep", action="store_true", help="疑似简介加深扫描（对应「重新识别」）")
    ap.add_argument("--keep-intro", action="store_true", help="已确认保留疑似简介，不再拦截（对应「保留该段落并继续」）")
    ap.add_argument("--genre", default="auto", choices=["auto", "modern", "period"],
                    help="题材，决定「床」用榻还是铺；默认自动判定")
    ap.add_argument("--cut", default=None,
                    help="按候选序号（1 起）或段落号（写 p368）直接落「截断稿.txt」")
    args = ap.parse_args(argv)

    src = Path(args.input)
    if not src.is_file():
        raise SystemExit("找不到原文：%s" % src)
    if args.out_dir:
        out_dir = Path(args.out_dir)
    else:
        cwd = Path.cwd().resolve()
        # 防止在技能目录内直接运行时把中间产物写进技能包
        if str(cwd).lower().startswith(str(SKILL_ROOT).lower()):
            out_dir = Path(tempfile.gettempdir()) / "fenjing-yym-prep"
            print("⚠ 当前目录在技能包内，改写到 %s" % out_dir)
        else:
            out_dir = cwd / "_prep"
    out_dir.mkdir(parents=True, exist_ok=True)

    raw, enc = read_text(src)
    raw = norm_newlines(raw)
    raw_n, raw_cjk = count_chars(raw)

    # 按原文行号删行（1 起），在清洗前生效更稳
    dropped_lines = []
    if args.drop_lines:
        idxs = set()
        for tok in re.split(r"[,\s]+", args.drop_lines):
            tok = tok.strip()
            if not tok:
                continue
            m = re.fullmatch(r"(\d+)\s*[-–~]\s*(\d+)", tok)
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                idxs.update(range(min(a, b), max(a, b) + 1))
            elif tok.isdigit():
                idxs.add(int(tok))
        raw_lines = raw.split("\n")
        kept_lines = [l for i, l in enumerate(raw_lines, 1) if i not in idxs]
        dropped_lines = [{"行": i, "内容": raw_lines[i - 1].strip()[:40]} for i in sorted(idxs) if 1 <= i <= len(raw_lines)]
        raw = "\n".join(kept_lines)


    if args.keep_all:
        cleaned, removed = raw, []
    else:
        cleaned, removed = clean_text(raw)

    cleaned, invis_n = strip_invisible(cleaned)

    intro_block = find_intro_block(raw.split("\n"), deep=args.intro_deep)

    # 书名删除：显式给出即删；未给出则自动检测，仅书名号或重复出现才自动删
    title_info = {"value": "", "count": 0, "source": "未检测到"}
    if args.title:
        cleaned, n = strip_title(cleaned, args.title)
        title_info = {"value": args.title, "count": n, "source": "--title"}
    else:
        by_name = title_from_name(args.name, cleaned)
        cand, why = detect_title(cleaned)
        if by_name:
            cleaned, n = strip_title(cleaned, by_name)
            title_info = {"value": by_name, "count": n, "source": "自动：导出稿名×前两行双证"}
        elif cand:
            repeat = cleaned.count(cand.strip("《》")) > 1
            blocked = cand.startswith(("《", "「", "『"))
            if blocked or repeat:
                cleaned, n = strip_title(cleaned, cand)
                title_info = {"value": cand, "count": n, "source": "自动：" + why}
            else:
                title_info = {"value": cand, "count": 0, "source": "仅候选（未删，需 --title 确认）"}

    intros = intro_candidates(cleaned, limit=12 if args.intro_deep else 6,
                              threshold=0.18 if args.intro_deep else 0.30)

    # 按确认后的段落号删段（1 起，基于清洗后的段落顺序）
    dropped = []
    if args.drop:
        idxs = set()
        for tok in re.split(r"[,\s]+", args.drop):
            tok = tok.strip()
            if not tok:
                continue
            m = re.fullmatch(r"(\d+)\s*[-–~]\s*(\d+)", tok)
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                idxs.update(range(min(a, b), max(a, b) + 1))
            elif tok.isdigit():
                idxs.add(int(tok))
        idxs = sorted(idxs)
        paras = paragraphs(cleaned)
        keep = []
        for i, p in enumerate(paras, 1):
            if i in idxs:
                dropped.append({"段落": i, "字数": count_chars(p)[0], "首20字": p[:20].replace("|", "｜")})
            else:
                keep.append(p)
        cleaned = "\n\n".join(keep)

    # 强制兜底确认：拟删（疑似简介）＋ 保留（正文前三句及起始位置）
    gate = None
    if (intro_block or intros) and not args.keep_intro:
        if intro_block:
            src = intro_block
            cut_range = "%d–%d" % (src["起"], src["止"])
            cut_para = "—"
            basis = src.get("来源", "结构判定")
            cut_text, cut_chars = src.get("全文", ""), src["字数"]
        else:
            src = None
            it = intros[0]
            cut_range = "段落 " + str(it["段落"])
            cut_para = str(it["段落"])
            basis = it.get("依据") or ("与后文重合度 %s" % it["重合度"])
            cut_text, cut_chars = it.get("全文", ""), it["字数"]
        # 书名已在前面自动删除，块内残留的书名行不应展示成简介内容
        if title_info.get("value"):
            cut_text = strip_title(cut_text, title_info["value"])[0]
            cut_text = re.sub(r"\s{2,}", " ", cut_text).strip()
            cut_chars = count_chars(cut_text)[0]
        # 正文起始
        if src:
            lines_ = raw.split("\n")
            start_no = src["止"] + 1
            while start_no <= len(lines_):
                s = lines_[start_no - 1].strip()
                if (not s) or SEP_RE.match(s) or TAGLINE_RE.match(s) or META_RE.match(s) \
                        or (CHAPTER_RE.match(s) and len(s) <= 40) or NUM_HEAD_RE.match(s) \
                        or re.match(r"^#{1,6}\s", s):
                    start_no += 1
                    continue
                break
            body = "\n".join(lines_[start_no - 1:])
            body_clean, _ = clean_text(body)
            body_para = 1
        else:
            endp = int(str(intros[0]["段落"]).split("-")[-1])
            paras_ = paragraphs(cleaned)
            body = "\n\n".join(paras_[endp:])
            body_clean, _ = clean_text(body)
            body_para = endp + 1
            # 简介按段落号删，正文起点以段落定位为准（行号会因简介自身重复而搜错）
            start_no = 0
        gate = {
            "起止": cut_range,
            "段落": cut_para,
            "字数": cut_chars,
            "占比": round(cut_chars * 100.0 / max(1, count_chars(cleaned)[0]), 1),
            "依据": basis,
            "全文": cut_text,
            "正文行": start_no,
            "正文段": body_para,
            "前三句": first_sentences(body_clean, 3),
        }

    clean_n, clean_cjk = count_chars(cleaned)

    table = load_backdoor_table(SKILL_ROOT / "SKILL.md", "【后门 BO-01")
    if not table:
        raise SystemExit("未能从 SKILL.md 解析 BO-01 替换表，请检查后门表格格式")
    # 「死」「杀」语境表：成语／惯用语先整词改写，不命中才走主表 死→si／杀→sha
    idiom_cases = []
    for anchor in ("「死」语境表", "「杀」语境表"):
        tb = load_anchor_table(anchor)
        for src_w, dst_w in sorted(tb, key=lambda r: -len(r[0])):
            if not src_w or not dst_w:
                continue
            n = cleaned.count(src_w)
            if n:
                cleaned = cleaned.replace(src_w, dst_w)
                idiom_cases.append({"原词": src_w, "替换为": dst_w, "次数": n})
    # 剩下的「死死X」按紧握/凝视两类收口
    for pat_, dst_ in ((r"死死(?=[盯望])", "直勾勾"), (r"死死(?=[注凝])", "直直"), (r"死死", "紧紧")):
        hits = len(re.findall(pat_, cleaned))
        if hits:
            cleaned = re.sub(pat_, dst_, cleaned)
            idiom_cases.append({"原词": pat_.replace("(?=", "（后接").replace(")", "）").replace("\\", ""),
                                "替换为": dst_, "次数": hits})
    replaced, counts, _ = apply_replace(cleaned, table)
    # 本地表（_local_tables.md）：本地优先，无条件生效，覆盖全局映射
    local_cases = []
    local_path = SKILL_ROOT / "_local_tables.md"
    local_rows = load_anchor_table_from(local_path, "【本地表｜词映射】", cols=2)
    if local_rows:
        for src_w, dst_w in sorted(local_rows, key=lambda r: -len(r[0])):
            if not src_w or not dst_w:
                continue
            n = replaced.count(src_w)
            if n:
                replaced = replaced.replace(src_w, dst_w)
                local_cases.append({"原词": src_w, "替换为": dst_w, "次数": n})
    bo1_n = count_chars(replaced)[0]

    # 题材判定（决定「床」走榻还是铺）
    GENRE_MODERN = ("手机", "微信", "公司", "电梯", "地铁", "直播", "公寓", "医院",
                    "屏幕", "外卖", "打车", "咖啡", "视频", "合同", "宿舍", "微博", "短信")
    GENRE_PERIOD = ("王爷", "丫鬟", "奴才", "客栈", "朝堂", "银两", "小厮", "侯爷", "马车",
                    "衙门", "老爷", "府里", "妾", "宫", "武林", "师兄", "师父", "轿")

    def detect_genre(text):
        m_hits = {w: text.count(w) for w in GENRE_MODERN if w in text}
        p_hits = {w: text.count(w) for w in GENRE_PERIOD if w in text}
        ms, ps = sum(m_hits.values()), sum(p_hits.values())
        if args.genre in ("modern", "period"):
            return args.genre, "手动指定（--genre）", m_hits, p_hits
        if not ms and not ps:
            return None, "关键词零命中", m_hits, p_hits
        if ms >= ps * 1.5:
            return "modern", "现代关键词占优", m_hits, p_hits
        if ps >= ms * 1.5:
            return "period", "古装关键词占优", m_hits, p_hits
        return None, "两侧相当", m_hits, p_hits

    genre, genre_why, genre_m, genre_p = detect_genre(cleaned)
    genre_cases = []
    rank_table = load_anchor_table("称谓替换表")
    rank_counts = {}
    if rank_table:
        # 单遍替换，避免「军长→战团长」后再被「团长」二次命中
        rank_map = {r[0]: r[1] for r in rank_table if r[0] and r[1]}
        pat = re.compile("|".join(re.escape(k) for k in sorted(rank_map, key=len, reverse=True)))
        hits = {}

        def _sub(m):
            w = m.group(0)
            hits[w] = hits.get(w, 0) + 1
            return rank_map[w]

        replaced = pat.sub(_sub, replaced)
        rank_counts = {k: {"replaced_to": rank_map[k], "count": v} for k, v in hits.items()}
    # 现实军队建制／机构词：同上机制，避免「战区/军区/总司令」这类建制名带进画面
    org_counts = {}
    org_table = load_anchor_table("建制替换表")
    if org_table:
        org_map = {r[0]: r[1] for r in org_table if r[0] and r[1]}
        pat_org = re.compile("|".join(re.escape(k) for k in sorted(org_map, key=len, reverse=True)))
        org_hits = {}

        def _sub_org(m):
            w = m.group(0)
            org_hits[w] = org_hits.get(w, 0) + 1
            return org_map[w]

        replaced = pat_org.sub(_sub_org, replaced)
        org_counts = {k: {"replaced_to": org_map[k], "count": v} for k, v in org_hits.items()}
    # BO-01 子表：语境替换（上床按邻近语境判定，其余长词优先、单字兜底）
    ctx_table = load_anchor_table("语境替换表")
    ctx_counts = {}
    bed_cases = []
    bed_hold = {}  # 占位符 → 原始词，避免被「床」表误改，也保住「了/到」
    blood_cases = []
    slap_cases = []
    if ctx_table:
        # 「上床」语境建议表：语义类｜建议改成｜线索词（表序即优先级）
        bed_rules = []
        for row in load_anchor_table("「上床」语境建议表", cols=3):
            if len(row) < 3 or not row[0] or not row[1]:
                continue
            cues = tuple(c.strip() for c in re.split(r"[、,，/／]", row[2]) if c.strip())
            bed_rules.append((row[0].strip(), row[1].strip(), cues))

        def _bed(m):
            s = m.string
            suffix = m.group("suf") or ""
            # 「床边/床沿/床下…」这类方位短语不是「上床」动作，交给后天题材词表处理
            if not suffix and s[m.end(): m.end() + 1] in ("边", "沿", "头", "下", "前", "里"):
                return m.group(0)
            # 先取句内上下文，避免跨句误判；再按邻近 6 字优先
            left = max(s.rfind(ch, 0, m.start()) for ch in "。！？…\n；")
            left = 0 if left < 0 else left + 1
            rights = [s.find(ch, m.end()) for ch in "。！？…\n；"]
            rights = [r for r in rights if r >= 0]
            right = min(rights) if rights else len(s)
            sent = s[left:right]
            near = s[max(0, m.start() - 6): m.end() + 6]

            hits = []  # [(近邻优先, 表序, 语义类, 建议词, 依据)]
            for order, (kind, dst, cues) in enumerate(bed_rules):
                if not cues:
                    continue
                if any(c in near for c in cues):
                    hits.append((0, order, kind, dst, "近6字「%s」" % next(c for c in cues if c in near)))
                elif any(c in sent for c in cues):
                    hits.append((1, order, kind, dst, "整句「%s」" % next(c for c in cues if c in sent)))
            if not hits and suffix:
                hits.append((0, 0, bed_rules[0][0], bed_rules[0][1], "后缀「%s」" % suffix))
            if not hits:
                word = m.group(0)
                head = s[max(0, m.start() - 6): m.start()]
                # A 句按近邻线索给：被搬动/搀扶 → 到床上；其余 → 躺下
                sug_a = "到床上" if any(w in head for w in ("抱", "扶", "抬", "背", "拖", "推", "拉", "送")) else "躺下"
                bed_cases.append({
                    "原词": "上床", "判定": "待判定", "依据": "无任何语义线索",
                    "上下文": sent.strip(),
                    "建议A": sent.replace(word, sug_a).strip(),
                    "建议B": sent.replace(word, "回房").strip(),
                })
                token = "\u0001BED%d\u0001" % len(bed_hold)
                bed_hold[token] = word
                return token
            hits.sort(key=lambda h: (h[0], h[1]))
            _, _, kind, dst, where = hits[0]
            # 「一上床就…」「刚上床就…」：回房休息会成病句，改「躺下」
            if dst == "回房休息" and s[max(0, m.start() - 1):m.start()] in ("一", "刚", "才"):
                where += "；紧接「%s」，改「躺下」更顺" % s[max(0, m.start() - 1):m.start()]
                dst = "躺下"
            note = ""
            if len({h[2] for h in hits}) > 1:
                others = "、".join(sorted({h[2] for h in hits if h[2] != kind}))
                note = "两类线索都命中（%s），按%s优先，可改选%s" % (others, kind, others)
            bed_cases.append({"原词": "上床", "判定": dst, "依据": where + ("；" + note if note else ""),
                              "上下文": sent.strip(), "建议A": "", "建议B": ""})
            return dst

        replaced = re.sub(r"上(?P<mid>了|到|过)?床(?P<suf>休息|睡觉|睡)?", _bed, replaced)

        # 「床」题材词表：在「上床」判定之后跑，避免把「上床」提前吃掉
        bed_table = load_anchor_table("「床」题材词表", cols=3)
        if bed_table:
            for row in sorted(bed_table, key=lambda r: -len(r[0])):
                if len(row) < 3 or not row[0]:
                    continue
                if genre == "modern":
                    dst = row[2]
                elif genre == "period":
                    dst = row[1]
                else:
                    # 题材未定：只执行古装／现代两列相同的通用条目，区分性条目留待人工
                    dst = row[1] if row[1] and row[1] == row[2] else ""
                if not dst:
                    continue
                n = replaced.count(row[0])
                if n:
                    replaced = replaced.replace(row[0], dst)
                    genre_cases.append({"原词": row[0], "替换为": dst, "次数": n})

        # 血（BO-01 子规则）：谓语用法先平替，其余形态交子表长词映射
        def _blood_prog(m):
            dst = m.group("pre") + "渗着殷红"
            blood_cases.append({"原词": m.group(0), "判定": dst,
                                "原句": sentence_at(replaced, m.start())})
            return dst

        replaced = re.sub(r"(?P<pre>在|还|正|仍|不断|一直|兀自)(?:地)?流着?血", _blood_prog, replaced)

        def _blood_flow(m):
            blood_cases.append({"原词": m.group(0), "判定": "淌着殷红",
                                "原句": sentence_at(replaced, m.start())})
            return "淌着殷红"

        replaced = re.sub(r"流着?血", _blood_flow, replaced)

        # 「血淋淋的场面／画面」按场面语义作「惨烈」，避免「伤痕的场面」这类硬套
        def _blood_grue(m):
            blood_cases.append({"原词": m.group(0), "判定": "惨烈",
                                "原句": sentence_at(replaced, m.start())})
            return "惨烈"

        replaced = re.sub(r"血淋淋(?=的(?:场面|画面|景象|模样|一幕|镜头))", _blood_grue, replaced)

        for src, dst in sorted(ctx_table, key=lambda r: -len(r[0])):
            if not src or not dst:
                continue
            n = replaced.count(src)
            if n:
                replaced = replaced.replace(src, dst)
                ctx_counts[src] = {"replaced_to": dst, "count": n}

        # 兜底单字「血」：除现代医学词（血型/血压/血管等）留待人工，其余一律平替为「殷红」
        BLOOD_KEEP = ("血液", "气血", "血象", "输血", "血常规", "血库", "血型", "血压", "血管", "血友", "血浆", "血糖", "血检")

        def _blood_last(m):
            s = m.string
            if any(s.startswith(w, m.start()) for w in BLOOD_KEEP):
                if len(blood_cases) < 20:
                    blood_cases.append({"原词": "血", "判定": "待判定",
                                        "原句": sentence_at(replaced, m.start())})
                return "血"
            if len(blood_cases) < 20:
                blood_cases.append({"原词": m.group(0), "判定": "殷红",
                                    "原句": sentence_at(replaced, m.start())})
            return "殷红"

        replaced = re.sub("血", _blood_last, replaced)

        # 巴掌／耳光（BO-01 子规则）：部位→掌心；力度／接触瞬间→掌掴；动作→挥掌／反手一击
        SLAP_FORCE = ("狠狠", "重重", "猛地", "猛", "用力", "死命", "发狠", "抡圆",
                      "清脆", "响亮", "啪", "狠")
        SLAP_VERB = "扇打抽甩搧掴抡"
        SLAP_OBJ = r"(?:他|她|它|我|你|对方|那人|人)"

        def _slap_sub(pattern, pick):
            """pick(match) -> (替换为, 依据) 或 None（待判定）。"""
            nonlocal replaced

            def _rep(m):
                sent = sentence_at(replaced, m.start())
                got = pick(m)
                if not got:
                    slap_cases.append({"原词": m.group(0), "判定": "待判定",
                                       "依据": "语境不明", "原句": sent})
                    return m.group(0)
                dst, kind = got
                slap_cases.append({"原词": m.group(0), "判定": dst, "依据": kind, "原句": sent})
                return dst

            replaced = re.sub(pattern, _rep, replaced)

        # 1) 部位：巴掌大／巴掌心／手巴掌／巴掌印
        _slap_sub(r"巴掌大", lambda m: ("掌心大", "部位"))
        _slap_sub(r"手?巴掌心", lambda m: ("掌心", "部位"))
        _slap_sub(r"手巴掌", lambda m: ("手掌", "部位"))
        _slap_sub(r"巴掌印", lambda m: ("掌印", "部位"))

        # 2) 动作：动词(+了/宾语/数量)+巴掌｜耳光
        def _slap_act(m):
            s, obj = m.string, m.group("obj")
            near = s[max(0, m.start() - 4): m.start()]
            force = any(w in near for w in SLAP_FORCE)
            if force:
                return ("掌掴" + ("了" + obj if obj else ""), "力度／接触瞬间")
            if obj:
                return ("掌掴了" + obj, "动作（带宾语）")
            return ("挥掌", "动作")

        _slap_sub(r"[%s](?P<le>了)?(?P<obj>%s)?(?:一|一记|一个|两|两个|几|几个)?(?:个)?(?:巴掌|耳光)"
                  % (SLAP_VERB, SLAP_OBJ), _slap_act)

        # 3) 量词形态（一记耳光／一巴掌）单独出现：耳光→一记掌掴；巴掌→掌心／一掌
        SLAP_MOTION = "拍落扇挥抽打抡砸掴甩震扬"

        def _slap_quant(m):
            q, noun = m.group("q"), m.group("noun")
            if noun == "巴掌":
                head = m.string[max(0, m.start() - 6): m.start()]
                if any(w in head for w in ("挨", "受", "吃", "得到", "赏", "落", "顶")):
                    return ("%s记掌掴" % q, "动作（承受）")
                return ("%s掌" % q, "动作（量词）")
            return ("%s记掌掴" % q, "接触瞬间（名词）")

        _slap_sub(r"一个巴掌拍不响", lambda m: ("一只手掌拍不响", "部位（熟语）"))
        _slap_sub(r"(?P<q>[0-9]+|[一二三四五六七八九十百千万两几]+)(?:个|记)?(?P<noun>巴掌|耳光)", _slap_quant)

        # 4) 无数量词但搭配明确：扬起巴掌→手掌；巴掌落下／扇来→一掌
        _slap_sub(r"(?<=扬起|抬起|举起)巴掌", lambda m: ("手掌", "部位"))
        _slap_sub(r"(?<=扬|抬|举)巴掌", lambda m: ("手掌", "部位"))
        _slap_sub(r"巴掌(?=(?:落|打|扇|抽|甩|挥|拍|掴|砸))", lambda m: ("一掌", "动作（工具）"))

        # 4) 剩余未改写形态 → 待判定，交人工按语境改
        seen_slap = set()
        for w in ("巴掌", "耳光"):
            for m in re.finditer(w, replaced):
                sent = sentence_at(replaced, m.start())
                if sent in seen_slap:
                    continue
                seen_slap.add(sent)
                slap_cases.append({"原词": w, "判定": "待判定",
                                   "依据": "搭配形态未覆盖", "原句": sent})
                if len(slap_cases) >= 40:
                    break

    # 待判定的「上床」还原（已由 bed_cases 逐条问，不再进残留重复报警）
    for token, word in bed_hold.items():
        replaced = replaced.replace(token, word)

    # 残留敏感字（床/凶/巴掌/耳光 必须归零，交模型或人工改写）
    residuals = []
    seen_sent = set()
    for ch in ("床", "凶", "血", "巴掌", "耳光"):
        for m in re.finditer(ch, replaced):
            sent = sentence_at(replaced, m.start())
            if ch == "床" and re.search(r"上(?:了|到|过)?床", sent):
                continue
            key = (ch, sent)
            if key in seen_sent:
                continue
            seen_sent.add(key)
            residuals.append({
                "字": ch,
                "原句": sent,
                "建议句": suggest_rewrite(sent, ch),
            })
            if len(residuals) >= 30:
                break

    # 用户确认过的改句（--rewrite-file）：[{ "from": 原句, "to": 建议句 }]
    rewrites = []
    if args.rewrite_file:
        data = json.loads(Path(args.rewrite_file).read_text(encoding="utf-8"))
        for item in data:
            src, dst = item.get("from", ""), item.get("to", "")
            if src and src in replaced:
                replaced = replaced.replace(src, dst)
                rewrites.append({"from": src, "to": dst})
        if rewrites:
            residuals = [
                r for r in residuals if r["原句"] in replaced
            ]

    rep_n, rep_cjk = count_chars(replaced)

    total, cands = cut_candidates(cleaned, args.min, args.max)
    for c in cands:
        c["来源"] = "段落"
    # 段落粒度过粗时（长段、空行少）补逐行候选；仍无入区再补句子级
    if len(cands) < 3 or not any(c["入区"] for c in cands):
        line_text = "\n\n".join(l.strip() for l in cleaned.split("\n") if l.strip())
        _, line_cands = cut_candidates(line_text, args.min, args.max)
        seen = {c["累计字数"] for c in cands}
        extra = [c for c in line_cands if c["累计字数"] not in seen]
        for c in extra:
            c["来源"] = "逐行"
        if extra:
            cands = sorted(cands + extra, key=lambda d: (not d["入区"], -len(d["悬念词"]), abs(d["累计字数"] - (args.min + args.max) // 2)))
            cands = cands[:15]
    if not any(c["入区"] for c in cands):
        sents = [s.strip() for s in re.split(r"(?<=[。！？…”])", cleaned) if s.strip()]
        sent_text = "\n\n".join(sents)
        _, sent_cands = cut_candidates(sent_text, args.min, args.max)
        seen = {c["累计字数"] for c in cands}
        extra = [c for c in sent_cands if c["累计字数"] not in seen]
        for c in extra:
            c["来源"] = "句子"
        if extra:
            cands = sorted(cands + extra, key=lambda d: (not d["入区"], -len(d["悬念词"]), abs(d["累计字数"] - (args.min + args.max) // 2)))
            cands = cands[:15]
    too_short = clean_n < args.min_body

    stem = re.sub(r'[\\/:*?"<>|]', "_", args.name).strip() or "未命名"
    p_clean = out_dir / ("%s.clean.txt" % stem)
    p_rep = out_dir / ("%s.replaced.txt" % stem)
    p_clean.write_text(cleaned, encoding="utf-8", newline="\n")
    p_rep.write_text(replaced, encoding="utf-8", newline="\n")

    # 按候选序号／段落号直接落截断稿
    cut_info = None
    if args.cut:
        origin = "段落"
        try:
            if args.cut.lower().startswith("p"):
                idx = int(args.cut[1:])
            else:
                cand = cands[int(args.cut) - 1]
                idx = cand["段落序号"]
                origin = cand.get("来源", "段落")
        except (ValueError, IndexError):
            raise SystemExit("--cut 用法：候选序号（如 --cut 2）或段落号（如 --cut p368）")
        # 候选来源为「逐行」时，序号按非空行算；否则按段落算
        if origin == "逐行":
            units = [l.strip() for l in replaced.split("\n") if l.strip()]
        elif origin == "句子":
            units = [s.strip() for s in re.split(r"(?<=[。！？…”])", replaced) if s.strip()]
        else:
            units = paragraphs(replaced)
        if not 1 <= idx <= len(units):
            raise SystemExit("--cut %s 超出范围（按%s共 %d 个单位）" % (args.cut, origin, len(units)))
        cut_text = "\n\n".join(units[:idx])
        p_cut = out_dir / ("%s.截断稿.txt" % stem)
        p_cut.write_text(cut_text, encoding="utf-8", newline="\n")
        n_cut, cjk_cut = count_chars(cut_text)
        cut_info = {
            "粒度": origin,
            "段落": idx,
            "字数": n_cut,
            "汉字": cjk_cut,
            "在区间": args.min <= n_cut <= args.max,
            "最后两段": units[max(0, idx - 2): idx],
            "文件": str(p_cut),
        }

    report = {
        "导出稿名": args.name,
        "源文件": str(src),
        "源编码": enc,
        "原始字数": raw_n,
        "原始汉字数": raw_cjk,
        "清洗后字数": clean_n,
        "清洗后汉字数": clean_cjk,
        "替换后字数": rep_n,
        "BO-01增减": bo1_n - clean_n,
        "字数一致": rep_n == bo1_n,
        "称谓增字": rep_n - bo1_n,
        "删除行": removed,
        "书名": title_info,
        "不可见字符": invis_n,
        "疑似简介": intros,
        "前置块": intro_block,
        "删除段落": dropped,
        "替换统计": counts,
        "本地表统计": local_cases,
        "语境替换统计": ctx_counts,
        "语境改写统计": idiom_cases,
        "上床判定": bed_cases,
        "敏感字残留": residuals,
        "已改句": rewrites,
        "称谓替换统计": rank_counts,
        "建制替换统计": org_counts,
        "区间": [args.min, args.max],
        "总累计字数": total,
        "字数不足": too_short,
        "候选截断点": cands,
        "截断结果": cut_info,
        "文件": {
            "clean": str(p_clean),
            "replaced": str(p_rep),
        },
    }
    (out_dir / ("%s.prep.json" % stem)).write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n"
    )

    lines = []
    lines.append("# 前置处理报告：%s" % args.name)
    lines.append("")
    lines.append("| 项 | 值 |")
    lines.append("|---|---|")
    lines.append("| 源编码 | %s |" % enc)
    lines.append("| 原始字数 | %d（汉字 %d） |" % (raw_n, raw_cjk))
    lines.append("| 截断前正文字数 | %d（汉字 %d，清洗后的全文；确认删除简介前） |" % (clean_n, clean_cjk))
    lines.append("| 删除行数 | %d |" % len(removed))
    lines.append(
        "| 替换后字数 | %d（BO-01 后 %d，BO-01 增减 %+d，语境／称谓／建制增减 %+d） |"
        % (rep_n, bo1_n, bo1_n - clean_n, rep_n - bo1_n)
    )
    lines.append("| 不可见字符 | 清除 %d 个 |" % invis_n)
    ttl_src = title_info["source"]
    if dropped_lines and not title_info["value"]:
        ttl_src += "；书名行若在删除区块内，见「已删行」"
    title_meta_hit = None
    if not title_info["value"]:
        # 书名以「书名：…」形式出现时，会先被元信息规则整行删掉，这里如实注明
        title_meta_hit = next((r for r in removed
                               if re.match(r"^\s*(书\s*名|書\s*名|标\s*题|題\s*名)\s*[:：]", r["text"])), None)
        if title_meta_hit:
            ttl_src = "已随元信息行删除（%s）" % title_meta_hit["text"][:18]
    if not title_info["value"] and not title_meta_hit:
        first_line = next((l.strip() for l in raw.split("\n") if l.strip()), "")
        if first_line and any(k in first_line for k in (row[0] for row in table if row)):
            ttl_src += "；⚠ 首行疑似书名但未检出，已照替换规则改写，若是书名请补 --title 重跑"
    lines.append("| 书名处理 | %s（%s，删 %d 处） |" % (title_info["value"] or "—", ttl_src, title_info["count"]))
    lines.append("| 正文字数门槛 | %d（不足即停止） |" % args.min_body)
    lines.append("| 目标区间 | %d–%d |" % (args.min, args.max))
    if genre:
        top = sorted((genre_m if genre == "modern" else genre_p).items(), key=lambda kv: -kv[1])[:3]
        lines.append("| 题材判定 | %s（%s：%s）｜用 %s 词表 |"
                     % ("现代／都市" if genre == "modern" else "古装／民国", genre_why,
                        "、".join("%s×%d" % (k, v) for k, v in top) or "—", genre))
    else:
        lines.append("| 题材判定 | 未定（%s；现代 %d／古装 %d）｜「床」留待人工 |"
                     % (genre_why, sum(genre_m.values()), sum(genre_p.values())))
    lines.append("")
    bed_hits = replaced.count("床")
    if not genre and bed_hits:
        lines.append("## ⛔ 强制确认｜题材未定（决定「床」走榻还是铺）")
        lines.append("")
        lines.append("| 项 | 值 |")
        lines.append("|---|---|")
        lines.append("| 依据 | %s（现代 %d ／ 古装 %d） |"
                     % (genre_why, sum(genre_m.values()), sum(genre_p.values())))
        lines.append("| 待处理 | 含「床」%d 处，其中通用条目已按两列相同的规则替换，区分性条目（床→榻／铺、床边、床头、床沿等）需定题材 |" % bed_hits)
        lines.append("| 选项卡 | `现代/都市`（`--genre modern`） / `古装/民国`（`--genre period`） |")
        lines.append("")
        lines.append("定完题材重跑即可自动落词，**不要用逐条改句绕过**。")
        lines.append("")
    if gate:
        lines.append("## ⛔ 强制确认｜疑似简介（禁止静默删除，必须等我选）")
        lines.append("")
        lines.append("### 1. 拟删除")
        lines.append("")
        lines.append("| 项 | 值 |")
        lines.append("|---|---|")
        lines.append("| 位置 | %s |" % gate["起止"])
        lines.append("| 段落 | %s |" % gate["段落"])
        lines.append("| 字数 | %d（占清洗后正文 %.1f%%） |" % (gate["字数"], gate["占比"]))
        lines.append("| 依据 | %s |" % gate["依据"])
        lines.append("")
        shown = gate["全文"]
        if len(shown) > 600:
            shown = shown[:600] + "……（共 %d 字，此处显示前 600 字）" % gate["字数"]
        lines.append("内容：")
        lines.append("")
        lines.append("> " + shown.replace("\n", "\n> "))
        lines.append("")
        if len(intros) > 1:
            lines.append("其他候选（可改选，确认后按段落删）：")
            lines.append("")
            lines.append("| 段落 | 字数 | 重合度 | 首20字 |")
            lines.append("|---|---|---|---|")
            for it in intros[1:6]:
                lines.append("| %s | %d | %.2f | %s |"
                             % (it["段落"], it["字数"], it["重合度"], it["首20字"]))
            lines.append("")
        lines.append("### 2. 保留（正文起始）")
        lines.append("")
        pos = "原文第 %d 行" % gate["正文行"] if gate["正文行"] else None
        if pos:
            lines.append("- 起始位置：%s／段落 %d" % (pos, gate["正文段"]))
        else:
            lines.append("- 起始位置：段落 %d 起（按段落号删：`--drop %d`）"
                         % (gate["正文段"], gate["正文段"]))
        lines.append("")
        if gate["前三句"]:
            lines.append("前三句：")
            lines.append("")
            for i, s in enumerate(gate["前三句"], 1):
                lines.append("%d. %s" % (i, s))
        else:
            lines.append("前三句：—（正文为空，需核对）")
        lines.append("")
        lines.append("### 3. 选项卡（等我明确选择，禁止跳过）")
        lines.append("")
        lines.append("`确认删除并继续` / `保留该段落并继续` / `重新识别`")
        lines.append("")
        lines.append("- 确认删除并继续 → %s 重跑"
                     % ("`--drop-lines %s`" % gate["起止"].replace("–", "-") if "–" in gate["起止"]
                        else "`--drop %s`" % gate["段落"]))
        lines.append("- 保留该段落并继续 → 不加删除参数，附 `--keep-intro` 重跑，报告标「已确认保留」，此后不得再提删")
        lines.append("- 重新识别 → 附 `--intro-deep` 重跑，放宽到 20–2000 字、重合度 0.18，列出更多候选后重弹本选项卡")
        lines.append("")
    elif args.keep_intro and (intro_block or intros):
        lines.append("## ✔ 已确认保留疑似简介（--keep-intro）")
        lines.append("")
        block = intro_block or ({"起": 0, "止": 0, "字数": intros[0]["字数"], "来源": "与后文重合"} if intros else None)
        if block:
            lines.append("| 项 | 值 |")
            lines.append("|---|---|")
            lines.append("| 位置 | %s |" % ("第 %d–%d 行" % (block["起"], block["止"]) if block["起"] else "段落 " + str(intros[0]["段落"])))
            lines.append("| 字数 | %d |" % block["字数"])
            lines.append("| 依据 | %s |" % block.get("来源", "结构判定"))
            lines.append("")
            lines.append("按我的选择保留该段落，已并入正文，不再提删。")
            lines.append("")
    if too_short:
        lines.append("## ⛔ 字数不足")
        lines.append("")
        lines.append(
            "清洗后仅 **%d** 字，低于正文门槛 %d。按规则停止任务并告知用户；"
            "严禁捏造或续写。" % (clean_n, args.min_body)
        )
        lines.append("")
    if intro_block and not gate:
        lines.append(
            "## 前置块明细（%s；按行号删 %d-%d）%s"
            % (
                intro_block.get("来源", "结构判定"),
                intro_block["起"],
                intro_block["止"],
                "｜⚠ 已达 2000 字上限，请核对结束行" if intro_block.get("超长") else "",
            )
        )
        lines.append("")
        lines.append("| 行号 | 字数 | 首20字 |")
        lines.append("|---|---|---|")
        lines.append("| %d–%d | %d | %s |"
                     % (intro_block["起"], intro_block["止"], intro_block["字数"], intro_block["首20字"]))
        lines.append("")
    if intros and not gate:
        lines.append("## 疑似简介（与后文重合，需确认后 --drop 删除）")
        lines.append("")
        lines.append("| 段落 | 字数 | 重合度 | 首20字 |")
        lines.append("|---|---|---|---|")
        for it in intros:
            lines.append("| %s | %d | %.2f | %s |" % (it["段落"], it["字数"], it["重合度"], it["首20字"]))
        lines.append("")
    if dropped:
        lines.append("## 已删段落（--drop）")
        lines.append("")
        lines.append("| 段落 | 字数 | 首20字 |")
        lines.append("|---|---|---|")
        for d in dropped:
            lines.append("| %d | %d | %s |" % (d["段落"], d["字数"], d["首20字"]))
        lines.append("")
    lines.append("## 替换统计（BO-01）")
    lines.append("")
    if counts:
        lines.append("| 原字 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for k, v in counts.items():
            lines.append("| %s | %s | %d |" % (k, v["replaced_to"], v["count"]))
    else:
        lines.append("未命中任何替换字（正常，若原文确有敏感字则需检查）。")
    lines.append("")
    lines.append("## 语境替换（BO-01 子表）")
    lines.append("")
    if local_cases:
        lines.append("**本地表（本地优先，覆盖全局映射）**")
        lines.append("")
        lines.append("| 原词 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for d in local_cases:
            lines.append("| %s | %s | %d |" % (d["原词"], d["替换为"], d["次数"]))
        lines.append("")
        lines.append("以上条目来自 `_local_tables.md`，非全局规则；更新技能时该文件原地保留。")
        lines.append("")
    if genre_cases:
        lines.append("**床（题材词表｜%s）**" % ("modern" if genre == "modern" else ("period" if genre else "通用（题材未定）")))
        lines.append("")
        lines.append("| 原词 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for d in genre_cases:
            lines.append("| %s | %s | %d |" % (d["原词"], d["替换为"], d["次数"]))
        lines.append("")
    if idiom_cases:
        lines.append("**死／杀（成语／惯用语语境改写，先于主表执行）**")
        lines.append("")
        lines.append("| 原词 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for d in idiom_cases:
            lines.append("| %s | %s | %d |" % (d["原词"], d["替换为"], d["次数"]))
        lines.append("")
    if bed_cases:
        lines.append("**「上床」判定（语义分派；待判定给 A／B 建议句，排在最前）**")
        lines.append("")
        lines.append("| # | 原句 | 判定 | 依据 | 建议 |")
        lines.append("|---|---|---|---|---|")
        ordered = sorted(bed_cases, key=lambda b: b["判定"] != "待判定")
        for i, b in enumerate(ordered, 1):
            if b["判定"] == "待判定":
                sug = "A %s ／ B %s" % (b.get("建议A", ""), b.get("建议B", ""))
            else:
                sug = "—"
            lines.append("| %d | %s | %s | %s | %s |"
                         % (i, b["上下文"].replace("|", "｜"), b["判定"],
                            b.get("依据", "").replace("|", "｜"), sug.replace("|", "｜")))
        if any(b["判定"] == "待判定" for b in bed_cases):
            lines.append("")
            lines.append("待判定逐条问：`改原文吧（A）` / `改原文吧（B）` / `不要改原文`，禁止默认取「亲热」。")
        lines.append("")
    if ctx_counts:
        lines.append("| 原词 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for k, v in ctx_counts.items():
            lines.append("| %s | %s | %d |" % (k, v["replaced_to"], v["count"]))
    if blood_cases:
        lines.append("")
        lines.append("**血（谓语用法，按语境平替）**")
        lines.append("")
        lines.append("| # | 原词 | 判定 | 原句 |")
        lines.append("|---|---|---|---|")
        for i, s in enumerate(blood_cases, 1):
            lines.append("| %d | %s | %s | %s |"
                         % (i, s["原词"].replace("|", "｜"), s["判定"].replace("|", "｜"),
                            s["原句"].replace("|", "｜")))
    if slap_cases:
        lines.append("")
        lines.append("**巴掌／耳光（按语境替换，逐条可回查）**")
        lines.append("")
        lines.append("| # | 原词 | 判定 | 依据 | 原句 |")
        lines.append("|---|---|---|---|---|")
        for i, s in enumerate(slap_cases, 1):
            lines.append("| %d | %s | %s | %s | %s |"
                         % (i, s["原词"].replace("|", "｜"), s["判定"].replace("|", "｜"),
                            s["依据"], s["原句"].replace("|", "｜")))
        if any(s["判定"] == "待判定" for s in slap_cases):
            lines.append("")
            lines.append("标「待判定」的条目须人工按语境改写，禁止保留「巴掌」「耳光」原词。")
    if not bed_cases and not ctx_counts and not slap_cases and not blood_cases:
        lines.append("未命中语境替换。")
    lines.append("")
    if residuals:
        lines.append("## ⚠ 敏感字残留（床／凶／血／巴掌／耳光，须改写为 0）")
        lines.append("")
        lines.append("| # | 字 | 原句 | 建议句 |")
        lines.append("|---|---|---|---|")
        for i, r in enumerate(residuals, 1):
            lines.append("| %d | %s | %s | %s |"
                         % (i, r["字"], r["原句"].replace("|", "｜"), r["建议句"].replace("|", "｜")))
        lines.append("")
        lines.append("确认方式：逐条弹选项卡【改原文吧／不要改原文】。选「改原文吧」的条目写入 edits.json，"
                     "用 `--rewrite-file edits.json` 重跑；选「不要改原文」的保留原句。")
        lines.append("")
    lines.append("## 称谓替换（BO-02）")
    lines.append("")
    if org_counts:
        lines.append("| 建制原词 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for k, v in org_counts.items():
            lines.append("| %s | %s | %d |" % (k, v["replaced_to"], v["count"]))
        lines.append("")
    if rank_counts:
        lines.append("| 原称谓 | 替换为 | 次数 |")
        lines.append("|---|---|---|")
        for k, v in rank_counts.items():
            lines.append("| %s | %s | %d |" % (k, v["replaced_to"], v["count"]))
    else:
        lines.append("未命中任何现实称谓。")
    lines.append("")
    lines.append("## 候选截断点（按可信度排序，择一确认）")
    lines.append("")
    if cands:
        lines.append("| # | 行/段 | 来源 | 累计字数 | 在区间内 | 悬念词 | 段落尾 |")
        lines.append("|---|---|---|---|---|---|---|")
        for i, c in enumerate(cands, 1):
            lines.append(
                "| %d | %d | %s | %d | %s | %s | %s |"
                % (
                    i,
                    c["段落序号"],
                    c.get("来源", "段落"),
                    c["累计字数"],
                    "是" if c["入区"] else "否",
                    "、".join(c["悬念词"]) or "—",
                    c["尾句"].replace("|", "｜"),
                )
            )
    else:
        lines.append("区间内无段落末尾可用，需检查是否通篇无分段。")
    lines.append("")
    if cut_info:
        lines.append("## ✔ 截断结果（--cut %s）" % args.cut)
        lines.append("")
        lines.append("| 项 | 值 |")
        lines.append("|---|---|")
        lines.append("| 截断段落 | %d |" % cut_info["段落"])
        lines.append("| 截断后字数 | %d（汉字 %d） |" % (cut_info["字数"], cut_info["汉字"]))
        lines.append("| 在区间内 | %s |" % ("是" if cut_info["在区间"] else "否，需换点"))
        lines.append("| 文件 | %s |" % cut_info["文件"])
        lines.append("")
        lines.append("最后两段：")
        lines.append("")
        for p in cut_info["最后两段"]:
            lines.append("> " + p.replace("\n", " "))
        lines.append("")
    if dropped_lines:
        lines.append("## 已删行（--drop-lines，原文行号）")
        lines.append("")
        lines.append("| 行号 | 内容 |")
        lines.append("|---|---|")
        for d in dropped_lines:
            lines.append("| %d | %s |" % (d["行"], d["内容"].replace("|", "｜") or "（空行）"))
        lines.append("")
    if removed:
        lines.append("## 已删除内容（核对有无误删）")
        lines.append("")
        lines.append("| 行号 | 原因 | 内容 |")
        lines.append("|---|---|---|")
        for r in removed[:60]:
            lines.append("| %d | %s | %s |" % (r["line"], r["reason"], r["text"].replace("|", "｜")))
        if len(removed) > 60:
            lines.append("| … | 其余 %d 行见 json | |" % (len(removed) - 60))
        lines.append("")
    (out_dir / ("%s.prep.md" % stem)).write_text(
        "\n".join(lines), encoding="utf-8", newline="\n"
    )

    print("\n".join(lines))
    print("\n---")
    print("clean    : %s" % p_clean)
    print("replaced : %s" % p_rep)
    print("json     : %s" % (out_dir / ("%s.prep.json" % stem)))
    return 2 if too_short else 0


if __name__ == "__main__":
    sys.exit(main())
