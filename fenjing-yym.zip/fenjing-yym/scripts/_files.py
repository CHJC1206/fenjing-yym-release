# -*- coding: utf-8 -*-
"""技能必需文件清单（单一来源）。

doctor.py / check_package.py / update_apply.py 共用本清单，
避免三处各写一份、改一处漏两处。
本文件自身也算必需文件。
"""

REQUIRED_FILES = (
    "SKILL.md",
    "version.json",
    "安装与更新说明.md",
    "references/tables.md",
    "references/update.md",
    "references/scripts.md",
    "references/bo01-rules.md",
    "references/local.md",
    "references/style-caiqian.md",
    "references/style-huochai.md",
    "references/import.md",
    "references/import-style-profiles.md",
    "references/import-workflow.md",
    "scripts/_files.py",
    "scripts/prep_text.py",
    "scripts/audit_storyboard.py",
    "scripts/doctor.py",
    "scripts/guard_subskills.py",
    "scripts/check_package.py",
    "scripts/selftest.py",
    "scripts/update_check.py",
    "scripts/update_apply.py",
    "scripts/update.py",
    "scripts/publish_release.py",
    "scripts/grow_tables.py",
    "scripts/setup_deliver.py",
    "scripts/yy.mjs",
)

# 更新时原地保留（本机文件，不随版本覆盖）
KEEP_ON_UPDATE = ("_local_tables.md", "_gaps.json", "config.json")
