#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""fenjing-yym 环境自检（BO-08 / 通用性检查）。

用法：
    python scripts/doctor.py            # 自检，硬失败退出码 1
    python scripts/doctor.py --json     # 只输出 JSON

检查项：
    1 Python 版本 >= 3.7
    2 三个子技能是否存在
    3 成品目录 DELIVER_DIR 可写（BO-07，换机改这里）
    4 UTF-8 往返（防 GBK 乱码）
    5 状态目录可写（不写技能目录）
    6 技能自身文件完整性
只用标准库。
"""

import io
import json
import os
import re
import sys
import tempfile
from pathlib import Path

MIN_PY = (3, 7)
SUB_SKILLS = ("xiaoshuoman", "manhuaxiaoshuo")
SELF_FILES = (
    "SKILL.md",
    "version.json",
    "安装与更新说明.md",
    "scripts/update_check.py",
    "scripts/update_apply.py",
    "scripts/update.py",
    "scripts/publish_release.py",
    "scripts/grow_tables.py",
    "scripts/check_package.py",
    "scripts/selftest.py",
    "scripts/setup_deliver.py",
    "references/style-caiqian.md",
    "references/style-huochai.md",
    "scripts/prep_text.py",
    "scripts/audit_storyboard.py",
    "scripts/guard_subskills.py",
    "scripts/yy.mjs",
    "scripts/mock-server.mjs",
    "references/import.md",
    "references/import-style-profiles.md",
    "references/import-workflow.md",
)

DELIVER_DIR = Path.home() / "Desktop" / "YYM分镜稿"  # BO-07 默认值：当前用户桌面

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
else:  # pragma: no cover
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL_ROOT = Path(__file__).resolve().parent.parent


def resolve_deliver():
    """成品目录：环境变量 > 本机 config.json > BO-07 默认。"""
    env = os.environ.get("FENJING_DELIVER_DIR")
    if env:
        return Path(env), "环境变量"
    cfg = SKILL_ROOT / "config.json"
    if cfg.is_file():
        try:
            d = json.loads(cfg.read_text(encoding="utf-8"))
            if d.get("deliver_dir"):
                return Path(d["deliver_dir"]), "config.json"
        except Exception:
            pass
    return DELIVER_DIR, "BO-07 默认"


def skills_roots():
    """候选技能根目录，按优先级。"""
    cands = [SKILL_ROOT.parent]
    home = Path.home()
    cands += [
        home / ".workbuddy" / "skills",
        home / ".claude" / "skills",
        home / ".codebuddy" / "skills",
    ]
    seen, out = set(), []
    for c in cands:
        try:
            key = str(c.resolve()).lower()
        except Exception:
            key = str(c).lower()
        if key not in seen and c.is_dir():
            seen.add(key)
            out.append(c)
    return out


def check_python():
    ok = sys.version_info[:2] >= MIN_PY
    return {
        "id": "python",
        "hard": True,
        "ok": ok,
        "detail": "Python %d.%d.%d" % sys.version_info[:3]
        + ("" if ok else "（需 >= 3.7）"),
    }


def check_subskills():
    roots = skills_roots()
    found, missing, where = {}, [], {}
    for name in SUB_SKILLS:
        hit = None
        for r in roots:
            p = r / name / "SKILL.md"
            if p.is_file():
                hit = p
                break
        if hit:
            found[name] = str(hit)
            where[name] = str(hit.parent)
        else:
            missing.append(name)
    return {
        "id": "subskills",
        "hard": False,
        "ok": not missing,
        "detail": ("全部就位：" + "、".join(SUB_SKILLS))
        if not missing
        else ("缺失：" + "、".join(missing) + "｜缺失分支不可用，禁止降级到另一画风"),
        "found": found,
    }


def check_deliver():
    target, src = resolve_deliver()
    try:
        target.mkdir(parents=True, exist_ok=True)
        probe = target / ".doctor_write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        writable, err = True, ""
    except Exception as e:  # noqa: BLE001
        writable, err = False, "%s: %s" % (type(e).__name__, e)
    return {
        "id": "deliver",
        "hard": True,
        "ok": writable,
        "detail": ("成品目录可用：" + str(target) + "（%s）" % src)
        if writable
        else ("成品目录不可写：" + str(target) + "（%s）｜" % src + err
              + "｜跑 python scripts/setup_deliver.py --desktop 或 --path 指定本机目录"),
        "deliver_dir": str(target),
    }


def check_utf8():
    sample = "测试：洗虾荮千 表情😀 繁體 生僻𠮷 分镜"
    try:
        fd, tmp = tempfile.mkstemp(suffix=".txt")
        os.close(fd)
        p = Path(tmp)
        p.write_text(sample, encoding="utf-8")
        back = p.read_text(encoding="utf-8")
        p.unlink()
        ok = back == sample
        detail = "UTF-8 往返正常" if ok else "UTF-8 往返失配，中文将乱码"
    except Exception as e:  # noqa: BLE001
        ok, detail = False, "UTF-8 往返失败：%s" % e
    return {"id": "utf8", "hard": True, "ok": ok, "detail": detail}



def check_node():
    """阶段三导入依赖 Node >= 18。"""
    import shutil as _sh
    import subprocess as _sp
    exe = _sh.which("node")
    if not exe:
        return {"id": "node", "hard": False, "ok": False,
                "detail": "未找到 node，阶段三导入不可用（可手动导入）"}
    try:
        out = _sp.run([exe, "-v"], capture_output=True, text=True, timeout=10).stdout.strip()
        major = int(out.lstrip("v").split(".")[0])
        ok = major >= 18
        return {"id": "node", "hard": False, "ok": ok,
                "detail": ("Node %s（导入可用）" % out) if ok else ("Node %s，需 >= 18" % out)}
    except Exception as e:  # noqa: BLE001
        return {"id": "node", "hard": False, "ok": False, "detail": "Node 检测失败：%s" % e}


def check_guard():
    """子技能是否已写入入口守卫（迁移后需补齐，缺失只算警告）。"""
    roots = skills_roots()
    states = {}
    for name in ("xiaoshuoman", "manhuaxiaoshuo"):
        p = next((r / name / "SKILL.md" for r in roots if (r / name / "SKILL.md").is_file()), None)
        if not p:
            states[name] = "未安装"
            continue
        try:
            t = p.read_text(encoding="utf-8")
        except Exception:  # noqa: BLE001
            states[name] = "读取失败"
            continue
        states[name] = "已守卫" if ("入口守卫" in t and "fenjing-yym" in t) else "缺守卫"
    missing = [k for k, v in states.items() if v == "缺守卫"]
    return {
        "id": "guard",
        "hard": False,
        "ok": not missing,
        "detail": "子技能守卫齐全"
        if not missing
        else ("缺守卫：" + "、".join(missing) + "｜运行 scripts/guard_subskills.py --apply 补齐"),
        "states": states,
    }


def check_state_dir():
    cwd = Path.cwd()
    inside_skill = str(cwd).lower().startswith(str(SKILL_ROOT).lower())
    base = (
        Path(tempfile.gettempdir()) / "fenjing-yym-state"
        if inside_skill
        else cwd / ".workbuddy" / "yym-state"
    )
    try:
        base.mkdir(parents=True, exist_ok=True)
        probe = base / ".write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        ok, detail = True, "状态目录可写：" + str(base)
    except Exception as e:  # noqa: BLE001
        ok, detail = False, "状态目录不可写：%s（改用 %%TEMP%%）" % e
    return {
        "id": "state",
        "hard": False,
        "ok": ok,
        "detail": detail,
        "path": str(base),
    }


def _table_rows_after(lines, start):
    """统计 start 之后第一张表的行数（去掉表头与分隔行）。"""
    rows, started = 0, False
    for line in lines[start:]:
        s = line.strip()
        if s.startswith("|"):
            started = True
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                continue
            rows += 1
            continue
        if started:
            break
    return max(0, rows - 1)


# 表锚点名 → 最少数据行数。任一张解析不出即判硬失败，防止「表读空但流程照跑」的静默失效。
TABLE_ANCHORS = (
    ("【后门 BO-01", 6),        # 主表：死杀药奸枪刀
    ("语境替换表", 30),          # 凶／血
    ("「死」语境表", 14),
    ("「杀」语境表", 11),
    ("「床」题材词表", 13),
    ("「上床」语境建议表", 4),
    ("称谓替换表", 17),
)


def check_tables():
    md = SKILL_ROOT / "SKILL.md"
    if not md.is_file():
        return {"id": "tables", "hard": True, "ok": False, "detail": "SKILL.md 不存在"}
    lines = md.read_text(encoding="utf-8").split("\n")
    bad, seen = [], []
    for anchor, need in TABLE_ANCHORS:
        best = 0
        for i, line in enumerate(lines):
            if anchor in line:
                best = max(best, _table_rows_after(lines, i + 1))
        seen.append("%s=%d" % (anchor.replace("【后门 ", ""), best))
        if best < need:
            bad.append("%s 解析 %d 行（至少 %d）" % (anchor, best, need))
    return {
        "id": "tables",
        "hard": True,
        "ok": not bad,
        "detail": ("各表行数：" + "，".join(seen)) if not bad else ("表解析失败：" + "；".join(bad)),
    }


def check_local_tables():
    p = SKILL_ROOT / "_local_tables.md"
    if not p.is_file():
        return {"id": "localtab", "hard": False, "ok": True, "detail": "无本地表（可选）"}
    rows, bad = 0, 0
    started = False
    for line in p.read_text(encoding="utf-8").split("\n"):
        s = line.strip()
        if s.startswith("|"):
            started = True
            cells = [c.strip() for c in s.strip("|").split("|")]
            if len(cells) != 2:
                bad += 1
            elif cells[0] not in ("原词", "禁用") and not all(set(c) <= set("-: ") for c in cells):
                rows += 1
        elif started and rows:
            break
    ok = bad == 0
    return {"id": "localtab", "hard": True, "ok": ok,
            "detail": ("本地表 %d 条，均两列" % rows) if ok else ("本地表有 %d 行列数不对（应为两列）" % bad)}


def check_update_source():
    """若本机配了 update_source，校验格式；未配置则用内置默认源（BO-09）。"""
    src, where = None, ""
    env = os.environ.get("FENJING_UPDATE_SOURCE")
    cfg = SKILL_ROOT / "config.json"
    if env:
        src, where = env, "环境变量"
    elif cfg.is_file():
        try:
            d = json.loads(cfg.read_text(encoding="utf-8"))
            if d.get("update_source"):
                src, where = d["update_source"], "config.json"
        except Exception:
            pass
    if not src:
        return {"id": "updsrc", "hard": False, "ok": True,
                "detail": "未配置，使用内置默认源（见 BO-09）"}
    if str(src).startswith(("http://", "https://")):
        return {"id": "updsrc", "hard": False, "ok": True, "detail": "远端源（%s）：%s" % (where, src)}
    if Path(src).is_dir():
        return {"id": "updsrc", "hard": False, "ok": True, "detail": "本地源（%s）：%s" % (where, src)}
    return {"id": "updsrc", "hard": False, "ok": False,
            "detail": "update_source 格式不对（%s）：%s｜应为 http(s) 地址或已存在的目录" % (where, src)}


def check_version():
    p = SKILL_ROOT / "version.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        v = d.get("skill_version", "")
        ok = bool(v)
        detail = "版本 %s（词表 %s）" % (v, d.get("tables_version", "—")) if ok else "version.json 缺 skill_version"
    except Exception as e:
        ok, detail = False, "version.json 无法解析：%s" % e
    return {"id": "version", "hard": True, "ok": ok, "detail": detail}


def check_self():
    missing = [f for f in SELF_FILES if not (SKILL_ROOT / f).is_file()]
    return {
        "id": "self",
        "hard": True,
        "ok": not missing,
        "detail": "技能文件完整" if not missing else ("缺失：" + "、".join(missing)),
        "root": str(SKILL_ROOT),
    }


def main(argv):
    as_json = "--json" in argv
    checks = [
        check_python(),
        check_subskills(),
        check_deliver(),
        check_utf8(),
        check_node(),
        check_guard(),
        check_state_dir(),
        check_tables(),
        check_version(),
        check_local_tables(),
        check_update_source(),
        check_self(),
    ]
    hard_fail = [c for c in checks if c["hard"] and not c["ok"]]
    soft_fail = [c for c in checks if not c["hard"] and not c["ok"]]
    result = {
        "skill_root": str(SKILL_ROOT),
        "ok": not hard_fail,
        "hard_fail": [c["id"] for c in hard_fail],
        "warn": [c["id"] for c in soft_fail],
        "checks": checks,
    }
    if as_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("== fenjing-yym doctor ==")
        for c in checks:
            mark = "OK  " if c["ok"] else ("FAIL" if c["hard"] else "WARN")
            print("[%s] %-9s %s" % (mark, c["id"], c["detail"]))
        d = next(c for c in checks if c["id"] == "deliver")
        print("交付目录：%s" % d.get("deliver_dir"))
        print("结论：%s" % ("通过" if not hard_fail else "硬失败，禁止进入制作"))
    return 1 if hard_fail else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
