#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把当前技能打包成发布件，并写出带 sha256 的 version.json（供 update_check 使用）。

用法：
    python scripts/publish_release.py --out "<发布目录>"
    python scripts/publish_release.py --out ... --version 2026.11.20.1 --notes "新增 xx 词"

产出（--out 目录内）：
    fenjing-yym.zip       技能包
    version.json          发布清单（含 sha256）
本脚本只在发布端使用，对方机器不需要。
"""

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_BASE_URL = "https://raw.githubusercontent.com/CHJC1206/fenjing-yym-release/main"
SKIP_DIRS = {"__pycache__", "_backup"}


def main(argv=None):
    ap = argparse.ArgumentParser(description="打包并发布技能")
    ap.add_argument("--out", required=True, help="发布目录（共享盘／网盘）")
    ap.add_argument("--version", default=None, help="技能版本，缺省沿用 version.json")
    ap.add_argument("--tables", default=None, help="词表版本，缺省沿用 version.json")
    ap.add_argument("--notes", default="", help="变更摘要")
    ap.add_argument("--base-url", default="", help="公开仓库 raw 根地址，如 https://raw.githubusercontent.com/owner/repo/main")
    ap.add_argument("--skip-check", action="store_true", help="跳过发布前干净度自检（不推荐）")
    args = ap.parse_args(argv)

    if not args.skip_check:
        r = subprocess.run([sys.executable, str(ROOT / "scripts" / "check_package.py")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print("发布前自检未通过，已中止（确认无问题可加 --skip-check）：")
            print((r.stdout or r.stderr).strip())
            return 1
        print("发布前自检：通过")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    local = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    version = args.version or local.get("skill_version")
    tables = args.tables or local.get("tables_version") or version
    notes = args.notes or local.get("notes", "")

    # 先把版本号写回本地 version.json，再打包，否则包内版本号会落后一版
    local.update({"skill_version": version, "tables_version": tables,
                  "published_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
                  "notes": notes})
    (ROOT / "version.json").write_text(
        json.dumps(local, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

    files = sorted(p for p in ROOT.rglob("*")
                   if p.is_file() and not (SKIP_DIRS & set(p.relative_to(ROOT).parts)))
    pkg = out / "fenjing-yym.zip"
    with zipfile.ZipFile(pkg, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, Path("fenjing-yym") / p.relative_to(ROOT))

    digest = hashlib.sha256(pkg.read_bytes()).hexdigest()
    # 打包后自校验：包内 version.json 必须是本次版本，且 sha256 与清单一致
    with zipfile.ZipFile(pkg) as z:
        inner = json.loads(z.read("fenjing-yym/version.json").decode("utf-8"))
    if inner.get("skill_version") != version:
        print("自校验失败：包内版本 %s ≠ 本次 %s" % (inner.get("skill_version"), version))
        return 1
    manifest = {
        "skill_version": version,
        "tables_version": tables,
        "package": "fenjing-yym.zip",
        "sha256": digest,
        "size": pkg.stat().st_size,
        "files": len(files),
        "published_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
        "notes": notes,
        "package_url": ((args.base_url or DEFAULT_BASE_URL).rstrip("/") + "/fenjing-yym.zip"),
        "source": "publish_release.py",
    }
    (out / "version.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


    print("已发布：%s" % pkg)
    print("版本：%s（词表 %s）  文件 %d 个  %d 字节" % (version, tables, len(files), pkg.stat().st_size))
    print("sha256：%s" % digest)
    print("清单：%s" % (out / "version.json"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
