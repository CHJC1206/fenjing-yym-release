#!/usr/bin/env node
/**
 * mock-server.mjs —— 用于离线自测 yy.mjs 全流程，协议与真实 MCP 一致（NDJSON JSON-RPC）。
 * 状态存 %TEMP%/yy-mock-state.json，可跨进程保持，便于验证「复用项目」分支。
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const STATE = path.join(os.tmpdir(), 'yy-mock-state.json');
const load = () => {
  try {
    return JSON.parse(fs.readFileSync(STATE, 'utf8'));
  } catch {
    return { projects: [] };
  }
};
const save = (s) => fs.writeFileSync(STATE, JSON.stringify(s, null, 2), 'utf8');

const STYLES = [
  { id: 'style-qban-yuanrun-huochairen', name: 'Q版圆润火柴人（现代Q版）' },
  { id: 'style-qban-huochairen', name: 'Q版火柴人（现代酷版）' },
  { id: 'style-qban-guyan-yuanrun-huochairen', name: 'Q版古言圆润火柴人' },
  { id: 'style-qban-guyan-huochairen', name: 'Q版古言火柴人' },
  { id: 'style-shigan-huochairen', name: '实感火柴人' },
  { id: 'style-dushi-yanqing-huochairen-mingliang-jingzhi', name: '都市言情火柴人' },
  { id: 'style-caiqian-shouhui', name: '彩铅手绘' },
  { id: 'style-gangbi-dancai-shouhui', name: '钢笔淡彩手绘' },
  { id: 'style-default', name: '清新韩漫' },
  { id: 'style-xin-gufeng-hanman-rouguang', name: '新古风韩漫柔光' },
  { id: 'style-1791256111967-z10s9d', name: '上文下图' },
  { id: 'style-1786700640159-52ncev', name: '自定义「新画风」' },
];

const SAVE_MODE = process.env.MOCK_SAVE_MODE || 'tool'; // tool | action | none

function toolList() {
  const names = [
    'list_projects',
    'create_project',
    'import_storyboard',
    'get_project',
    'get_settings',
    'manage_settings',
    'save_settings',
    'list_generation_options',
  ].filter((n) => !(n === 'save_settings' && SAVE_MODE !== 'tool'));
  return names.map((name) => ({
    name,
    description: name,
    inputSchema:
      name === 'manage_settings'
        ? { type: 'object', properties: { action: { type: 'string', enum: ['update', 'save'] } } }
        : { type: 'object' },
  }));
}

function toolCall(name, args) {
  const s = load();
  const text = (o) => JSON.stringify(o, null, 2);
  switch (name) {
    case 'list_projects':
      return text({ projects: s.projects.map((p) => ({ id: p.id, name: p.name, pageCount: p.pageCount })) });
    case 'create_project': {
      const p = { id: 'project_' + Math.random().toString(36).slice(2, 8), name: args.name, pageCount: 0, fields: {}, draft: {}, rev: 1 };
      s.projects.push(p);
      save(s);
      return text({ project: { id: p.id }, chapterId: 'chapter-1' });
    }
    case 'import_storyboard': {
      const p = s.projects.find((x) => x.id === args.projectId);
      if (!p) throw new Error('project not found');
      if (!fs.existsSync(args.filePath)) throw new Error('file not found: ' + args.filePath);
      const md = fs.readFileSync(args.filePath, 'utf8');
      const pages = (md.match(/^##\s*第?\s*\d+\s*页/gm) || []).length || 3;
      p.pageCount = pages;
      p.characterCount = 6;
      save(s);
      return text({ counts: { characters: 6, pagePrompts: pages } });
    }
    case 'get_project': {
      const p = s.projects.find((x) => x.id === args.projectId);
      if (!p) throw new Error('project not found');
      return text({ project: { id: p.id, name: p.name, pageCount: p.pageCount, characterCount: p.characterCount || 0, storyboardReady: p.pageCount > 0 } });
    }
    case 'get_settings': {
      const p = s.projects.find((x) => x.id === args.projectId);
      if (!p) throw new Error('project not found');
      return text({ fields: p.fields || {}, draft: p.draft || {}, revision: p.rev || 1 });
    }
    case 'manage_settings': {
      const p = s.projects.find((x) => x.id === args.projectId);
      if (!p) throw new Error('project not found');
      if (args.action === 'update') {
        if (Number(args.expectedRevision) !== Number(p.rev || 1)) throw new Error('revision conflict');
        p.draft = { ...(p.draft || {}), ...(args.fields || {}) };
        p.rev = Number(p.rev || 1) + 1;
        save(s);
        return text({ ok: true, revision: p.rev, saved: false });
      }
      if (args.action === 'save') {
        if (SAVE_MODE === 'none') throw new Error('unsupported action: save');
        p.fields = { ...(p.fields || {}), ...(p.draft || {}) };
        p.draft = {};
        p.rev = Number(p.rev || 1) + 1;
        save(s);
        return text({ ok: true, revision: p.rev, saved: true });
      }
      throw new Error('unsupported action: ' + args.action);
    }
    case 'save_settings': {
      if (SAVE_MODE !== 'tool') throw new Error('unknown tool: save_settings');
      const p = s.projects.find((x) => x.id === args.projectId);
      if (!p) throw new Error('project not found');
      p.fields = { ...(p.fields || {}), ...(p.draft || {}) };
      p.draft = {};
      p.rev = Number(p.rev || 1) + 1;
      save(s);
      return text({ ok: true, revision: p.rev, saved: true });
    }
    case 'list_generation_options':
      return text({ styleProfiles: STYLES });
    default:
      throw new Error('unknown tool: ' + name);
  }
}

let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buf += chunk;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      continue;
    }
    if (msg.id === undefined) continue;
    try {
      let result;
      if (msg.method === 'initialize') {
        result = { protocolVersion: '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: 'yy-mock', version: '1.0.0' } };
      } else if (msg.method === 'tools/list') {
        result = { tools: toolList() };
      } else if (msg.method === 'tools/call') {
        const out = toolCall(msg.params.name, msg.params.arguments || {});
        result = { content: [{ type: 'text', text: out }] };
      } else {
        result = {};
      }
      process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: msg.id, result }) + '\n');
    } catch (e) {
      process.stdout.write(
        JSON.stringify({ jsonrpc: '2.0', id: msg.id, result: { isError: true, content: [{ type: 'text', text: String(e.message) }] } }) + '\n'
      );
    }
  }
});
process.stdin.on('end', () => process.exit(0));
