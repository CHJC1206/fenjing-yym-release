#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""维护本机偏好表 `_local_tables.md`（只改本地文件，不碰 SKILL.md）。

用法：
    python scripts/grow_tables.py --list
    python scripts/grow_tables.py --local "战区=战域" "军区=军域"
    python scripts/grow_tables.py --local "床=床" --note "这题材不改床"
    python scripts/grow_tables.py --remove "战区"

规则：本地表优先于全局表，更新技能时 _local_tables.md 原地保留。
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LOCAL = ROOT / "_local_tables.md"
ANCHOR = "### 【本地表｜词映射】"
TEMPLATE = """# 本机偏好表（本地优先）

本文件只在本机生效，**优先级高于 SKILL.md 的全局表**，`update_apply.py` 更新技能时会原地保留。
每行一条：`| 原词 | 替换为 |`。想让某个词不再被替换时，把两边写成一样（如 `| 床 | 床 |`）。

{anchor}

<!-- 由 grow_tables.py 维护，也可手改；改完跑一次 doctor.py 确认格式 -->

| 原词 | 替换为 |
|---|---|
"""


def parse_rows():
    if not LOCAL.is_file():
        return []
    text = LOCAL.read_text(encoding="utf-8")
    out, started = [], False
    for line in text.split("\n"):
        s = line.strip()
        if s.startswith("|"):
            started = True
            cells = [c.strip() for c in s.strip("|").split("|")]
            if len(cells) != 2 or all(set(c) <= set("-: ") for c in cells):
                continue
            if cells[0] in ("原词", "禁用"):
                continue
            out.append((cells[0], cells[1]))
        elif started:
            break
    return out


def write_rows(rows, note=""):
    body = TEMPLATE.format(anchor=ANCHOR)
    if note:
        body += "<!-- %s -->\n" % note
    body += "".join("| %s | %s |\n" % (a, b) for a, b in rows)
    LOCAL.write_text(body, encoding="utf-8", newline="\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description="维护本机偏好表")
    ap.add_argument("--list", action="store_true", help="列出当前本地映射")
    ap.add_argument("--local", nargs="+", default=None, help="新增/覆盖，如 \"战区=战域\"")
    ap.add_argument("--remove", nargs="+", default=None, help="删除指定原词")
    ap.add_argument("--note", default="", help="写进文件的备注")
    args = ap.parse_args(argv)

    rows = parse_rows()
    changed = []

    if args.local:
        for item in args.local:
            if "=" not in item:
                print("跳过（格式应为 原词=替换）: %s" % item)
                continue
            a, b = [x.strip() for x in item.split("=", 1)]
            if not a or not b:
                continue
            old = dict(rows).get(a)
            rows = [(x, y) for x, y in rows if x != a]
            rows.append((a, b))
            changed.append("%s → %s%s" % (a, b, "（原 %s）" % old if old else ""))

    if args.remove:
        for a in args.remove:
            n = len(rows)
            rows = [(x, y) for x, y in rows if x != a]
            changed.append("删除 %s%s" % (a, "" if len(rows) < n else "（未找到）"))

    if changed:
        write_rows(rows, args.note)
        print("已更新 %s：" % LOCAL.name)
        for c in changed:
            print("  - %s" % c)
        print("当前共 %d 条本地映射。建议跑一次 python scripts/doctor.py 校验。" % len(rows))
    elif args.list or not (args.local or args.remove):
        if not rows:
            print("本地表为空（%s 不存在或没有数据行）" % LOCAL.name)
        else:
            print("本地映射 %d 条：" % len(rows))
            for a, b in rows:
                print("  %s → %s" % (a, b))
    return 0


if __name__ == "__main__":
    sys.exit(main())
