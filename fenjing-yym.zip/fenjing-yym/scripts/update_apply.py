#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""安装新版本：备份 → 校验 → 解压 → 自检 → 覆盖，任一步失败自动回滚。

用法：
    python scripts/update_apply.py --source "<共享盘目录>" --dry-run   # 只看要做什么
    python scripts/update_apply.py --source "<共享盘目录>" --apply     # 真正写入

保留：_gaps.json、_local_additions.md、.workbuddy 状态目录不动。
只用标准库。
"""

import argparse
import hashlib
import json
import re
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_SOURCE = "https://raw.githubusercontent.com/CHJC1206/fenjing-yym-release/main"


def resolve_source(arg):
    """--source > 环境变量 FENJING_UPDATE_SOURCE > config.json 的 update_source > 内置默认源。"""
    if arg:
        return arg
    env = os.environ.get("FENJING_UPDATE_SOURCE")
    if env:
        return env
    cfg = ROOT / "config.json"
    if cfg.is_file():
        try:
            import json as _j
            d = _j.loads(cfg.read_text(encoding="utf-8"))
            if d.get("update_source"):
                return d["update_source"]
        except Exception:
            pass
    return DEFAULT_SOURCE
REQUIRED = (
    "SKILL.md",
    "version.json",
    "references/style-caiqian.md",
    "references/style-huochai.md",
    "scripts/prep_text.py",
    "scripts/audit_storyboard.py",
    "scripts/doctor.py",
    "scripts/update_check.py",
    "scripts/update_apply.py",
    "scripts/update.py",
    "scripts/grow_tables.py",
    "scripts/setup_deliver.py",
    "scripts/guard_subskills.py",
    "scripts/yy.mjs",
)
KEEP_IN_PLACE = ("_local_tables.md", "_gaps.json", "config.json")


def ver_tuple(v):
    return tuple(int(x) if x.isdigit() else 0 for x in str(v).replace("-", ".").split("."))


def github_api_url(url):
    """把 raw.githubusercontent.com/<o>/<r>/<ref>/<path> 映射到 api 端点，绕过 raw 的 CDN 缓存。"""
    m = re.match(r"https?://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)", url)
    if not m:
        return None
    owner, repo, ref, path = m.groups()
    return "https://api.github.com/repos/%s/%s/contents/%s?ref=%s" % (owner, repo, path, ref)


def fetch(url, timeout=30):
    api = github_api_url(url)
    targets = [x for x in (api, url) if x]
    last = None
    for i in range(3):
        try:
            for target in targets:
                try:
                    req = urllib.request.Request(target, headers={"User-Agent": "fenjing-update/1.0", "Accept": "application/vnd.github.raw"})
                    with urllib.request.urlopen(req, timeout=timeout) as r:
                        return r.read()
                except Exception as inner:  # noqa: BLE001
                    last = inner
                    continue
            raise last
        except Exception as e:  # noqa: BLE001
            last = e
            if getattr(e, "code", None) == 404:
                raise
            if i < 2:
                time.sleep(2)
    raise last


def sha256_of(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser(description="安装技能新版本（默认只演练）")
    ap.add_argument("--source", default=None, help="留空则用 config.json 的 update_source，或内置默认源")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true", help="只打印计划（默认行为）")
    g.add_argument("--apply", action="store_true", help="真正写入")
    ap.add_argument("--force", action="store_true", help="允许覆盖同版本或降级")
    ap.add_argument("--prune-backups", type=int, default=0, metavar="N",
                    help="更新成功后只保留最近 N 份备份")
    args = ap.parse_args(argv)

    src_raw = str(resolve_source(args.source))
    tmp_pkg_dir = None
    if src_raw.startswith(("http://", "https://")):
        base = src_raw.rstrip("/")
        if base.lower().endswith(".json"):
            base = base.rsplit("/", 1)[0]
        try:
            remote = json.loads(fetch(base + "/version.json").decode("utf-8"))
        except Exception as e:
            code = getattr(e, "code", None)
            if code == 404:
                print("远端没有 version.json：%s ——仓库可能还没上传发布文件" % base)
            else:
                print("无法读取远端 version.json：%s（%s）" % (base, e))
            return 2
        pkg_url = remote.get("package_url") or (base + "/" + (remote.get("package") or "fenjing-yym.zip"))
        tmp_pkg_dir = Path(tempfile.mkdtemp(prefix="fenjing-dl-"))
        pkg = tmp_pkg_dir / "fenjing-yym.zip"
        try:
            pkg.write_bytes(fetch(pkg_url, timeout=120))
        except Exception as e:
            print("下载安装包失败：%s（%s）" % (pkg_url, e))
            return 2
        src = tmp_pkg_dir
    else:
        src = Path(src_raw)
        if not src.is_dir():
            print("更新源既不是目录也不是 http(s) 地址：%s" % src)
            return 2
        manifest_p = src / "version.json"
        if not manifest_p.is_file():
            print("更新源缺 version.json：%s" % manifest_p)
            return 2
        remote = json.loads(manifest_p.read_text(encoding="utf-8"))
    local = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    if tmp_pkg_dir is None:
        pkg_name = remote.get("package") or "fenjing-yym.zip"
        pkg = src / pkg_name
        if not pkg.is_file():
            print("更新源缺安装包：%s" % pkg)
            return 2

    rv, lv = remote.get("skill_version", "0"), local.get("skill_version", "0")
    newer = ver_tuple(rv) > ver_tuple(lv)
    print("本地 %s → 远端 %s" % (lv, rv))
    if not newer and not args.force:
        print("远端不比本地新，未做任何改动（要强制覆盖加 --force）")
        return 0

    want = (remote.get("sha256") or "").lower()
    got = sha256_of(pkg)
    if want and want != got:
        print("包校验失败：version.json 记 %s…，实际 %s…" % (want[:12], got[:12]))
        print("若是刚发布的版本，多半是 CDN 还没刷新（约 1–2 分钟），稍后重试即可；")
        print("若反复不一致，说明包被替换过，请联系发布者核对 sha256。")
        return 2

    local_add = ROOT / "_local_additions.md"
    plan = [
        "备份当前技能目录 → %s" % (ROOT.parent / "_backup" / ("%s-%s" % (lv, time.strftime("%Y%m%d-%H%M%S")))),
        "解压 %s（sha256 %s…）" % (pkg.name, got[:12]),
        "校验必需文件 %d 项 + 在临时目录跑 doctor.py" % len(REQUIRED),
        "保留原地的本地文件：%s" % ("、".join(k for k in KEEP_IN_PLACE if (ROOT / k).exists()) or "无"),
        "覆盖技能文件并再跑一次 doctor.py（失败即回滚）",
    ]
    if local_add.exists():
        plan.append("检测到 %s：覆盖后需重跑合并（本脚本只保留文件，不自动合并）" % local_add.name)

    print("\n计划：")
    for i, x in enumerate(plan, 1):
        print("  %d. %s" % (i, x))
    if not args.apply:
        print("\n以上为演练（--dry-run）。确认无误后加 --apply 执行。")
        return 0

    backup_dir = ROOT.parent / "_backup" / ("%s-%s" % (lv, time.strftime("%Y%m%d-%H%M%S")))
    tmp = Path(tempfile.mkdtemp(prefix="fenjing-update-"))
    try:
        # 1) 备份
        backup_dir.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(ROOT, backup_dir, ignore=shutil.ignore_patterns("__pycache__", "_backup"))
        print("已备份 → %s" % backup_dir)

        # 2) 解压
        with zipfile.ZipFile(pkg) as z:
            z.extractall(tmp)
        inner = tmp / "fenjing-yym"
        if not inner.is_dir():
            raise RuntimeError("压缩包内未找到 fenjing-yym 目录")
        missing = [f for f in REQUIRED if not (inner / f).is_file()]
        if missing:
            raise RuntimeError("新版本缺必需文件：%s" % "、".join(missing))
        print("解压与文件校验通过")

        # 3) 临时目录自检
        r = subprocess.run([sys.executable, str(inner / "scripts" / "doctor.py")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("新版本自检未通过：\n%s" % (r.stdout or r.stderr))
        print("新版本 doctor 自检通过")

        # 4) 覆盖（保留本地追加文件）
        for item in sorted(inner.iterdir()):
            if item.name in KEEP_IN_PLACE:
                continue
            dst = ROOT / item.name
            if item.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(item, dst, ignore=shutil.ignore_patterns("__pycache__"))
            else:
                shutil.copy2(item, dst)
        print("已覆盖技能文件")

        # 5) 覆盖后再自检
        r = subprocess.run([sys.executable, str(ROOT / "scripts" / "doctor.py")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("覆盖后自检未通过：\n%s" % (r.stdout or r.stderr))
        now_ver = json.loads((ROOT / "version.json").read_text(encoding="utf-8")).get("skill_version", rv)
        print("覆盖后 doctor 自检通过 → 当前版本 %s" % now_ver)
        bk_root = ROOT.parent / "_backup"
        if bk_root.is_dir():
            dirs = sorted([d for d in bk_root.iterdir() if d.is_dir()], key=lambda d: d.name)
            if args.prune_backups and len(dirs) > args.prune_backups:
                for d in dirs[: len(dirs) - args.prune_backups]:
                    shutil.rmtree(d, ignore_errors=True)
                print("已清理旧备份，保留最近 %d 份" % args.prune_backups)
            elif len(dirs) > 2:
                print("备份已累积 %d 份（可用 --prune-backups 2 只留最近两份）" % len(dirs))
        print("备份保留在：%s（确认无误后可自行删除）" % backup_dir)
        return 0
    except Exception as e:
        print("更新失败：%s" % e)
        if backup_dir.exists():
            print("开始回滚…")
            for item in sorted(backup_dir.iterdir()):
                dst = ROOT / item.name
                if item.is_dir():
                    if dst.exists():
                        shutil.rmtree(dst)
                    shutil.copytree(item, dst, ignore=shutil.ignore_patterns("__pycache__"))
                else:
                    shutil.copy2(item, dst)
            print("已回滚到更新前状态：%s" % lv)
        return 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        if tmp_pkg_dir is not None:
            shutil.rmtree(tmp_pkg_dir, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
