#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交付前分镜稿校验：页数 / 页码 / 空镜 / 文字项 / 替换残留 / 删除线 / 手机逻辑。

用法：
    python scripts/audit_storyboard.py --file 成品分镜稿.md
    python scripts/audit_storyboard.py --file 稿.md --min 91 --max 99
    python scripts/audit_storyboard.py --file 稿.md --allow-partial   # 局部页稿
    python scripts/audit_storyboard.py --file 稿.md --json

退出码：0 通过 / 1 存在硬错误（不得提交）/ 2 仅警告

页数区间默认从 SKILL.md 的【后门 BO-06】解析，替换字从 references/tables.md 的【后门 BO-01】解析。
只用标准库。
"""

import argparse
import io
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
else:  # pragma: no cover
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL_ROOT = Path(__file__).resolve().parent.parent
TABLES_MD = SKILL_ROOT / "references" / "tables.md"

PAGE_RE = re.compile(r"^第\s*(\d+)\s*页\s*[|｜]\s*(.*)$")
TEXT_RE = re.compile(r'^\s*文字\s*[:：]\s*(.*)$')
POS_RE = re.compile(r"^\s*(?:类型与位置|位置与样式)\s*[:：]")
HUOCHAI_MARK = "【画面描述】"
RENDER_RE = re.compile(r"^\s*渲染约束\s*[:：]")
SPAN_RE = re.compile(r"<span[^>]*>(.*?)</span>", re.S)
SCENE_RE = re.compile(r"【场景描述\s*[:：]\s*(.*?)】")
CAST_RE = re.compile(r"【出场角色(?:—|-|：|:)?\s*(.*?)】")
STRUCT = ("一.分镜", "二.角色设定", "三.场景设定", "【导入结束】")
STRUCT_HUOCHAI = ("【悠悠漫完整分镜导入V1】", "【逐页分镜】", "【角色设定】", "【场景设定】", "【导入结束】")
SENSITIVE = ("刀", "枪", "劍", "强奸", "性侵", "尸", "自杀", "自残", "虐待", "血腥")
GORE = ("尸", "断肢", "内脏")
WEAPON = ("刀", "枪", "匕首", "枪口", "枪身")
# 置顶③ 瞬间定格：跨时间过程的写法（只告警）
PROCESS_PATTERNS = (
    r"正在[^，。；！？]{0,8}",
    r"一边[^，。；！？]{0,12}一边",
    r"接着[^，。；！？]{0,10}",
    r"随后[^，。；！？]{0,10}",
    r"于是[^，。；！？]{0,10}",
    r"走(?:了)?过[去来][^，。；！？]{0,8}",
    r"走上前去",
    r"站起身来[^，。；！？]{0,6}又",
    r"说完[就便][^，。；！？]{0,10}",
    r"刚要[^，。；！？]{0,8}又",
)
MASK_HINT = ("打码", "模糊", "轮廓", "虚化", "遮挡")
VAGUE_REF = ("那个男人", "那个女孩", "那个女人", "那个少年", "那男人", "那女孩")
FORMULA = ("面部无明显起伏", "面无表情地看着", "面无表情", "看着对方", "面对面", "四目相对")
RANK_TERMS = []
UNIFORM = ("军装", "军服", "警服", "警装", "制服", "战术服", "迷彩", "军帽", "肩章", "领花", "臂章", "帽徽", "勋表")
CAMPS = ("阵营一", "阵营二", "阵营三", "军方", "警方", "军阀")
STRICT_HINTS = ("疑似过程写法", "模糊指代", "模糊/敷衍句式")
MAX_SCENE_CHARS = 220  # 单页「画面」描述字数上限
FORBIDDEN_SYMBOL = ("卐", "卍", "双闪电", "铁十字", "鹰徽")
NATIONAL_SYMBOL = ("国徽", "国旗", "军旗", "军徽", "警徽", "警号", "八一", "五星红旗")
NATIONAL_ORG = ("解放军", "武警", "公安", "民警", "特警", "人民警察", "大檐帽", "红领章")


def read_text(path):
    raw = Path(path).read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return raw.decode(enc).replace("\r\n", "\n").replace("\r", "\n")
        except UnicodeDecodeError:
            continue
    raise SystemExit("无法识别文件编码，请转成 UTF-8：%s" % path)


def load_table(section_key, cols=2):
    p = TABLES_MD
    if not p.is_file():
        return []
    text = read_text(p)
    idx = text.find(section_key)
    if idx < 0:
        return []
    block = text[idx:]
    m = re.search(r"\n#{1,6}\s", block[len(section_key):])
    if m:
        block = block[: len(section_key) + m.start()]
    rows = []
    for line in block.split("\n"):
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) != cols:
            continue
        if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
            continue
        if cells[0] in ("原字", "显示名", "ID", "项"):
            continue
        rows.append(cells)
    return rows


def load_rank_terms():
    """从 references/tables.md 的称谓替换表取禁用词。"""
    p = TABLES_MD
    if not p.is_file():
        return []
    text = read_text(p)
    idx = text.find("称谓替换表")
    if idx < 0:
        return []
    out = []
    for line in text[idx:].split("\n")[1:]:
        line = line.strip()
        if not line.startswith("|"):
            if out:
                break
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) != 2 or cells[0] in ("禁用",) or set(cells[0]) <= set("-: "):
            continue
        out.append(cells[0])
    return out


def load_page_range():
    text = read_text(SKILL_ROOT / "SKILL.md") if (SKILL_ROOT / "SKILL.md").is_file() else ""
    m = re.search(r"下限\s*(\d+)\s*页[，,]\s*上限\s*(\d+)\s*页", text)
    if m:
        return int(m.group(1)), int(m.group(2))
    return 91, 99


def split_pages(text):
    lines = text.split("\n")
    pages, cur = [], None
    for i, line in enumerate(lines, 1):
        m = PAGE_RE.match(line)
        if m:
            if cur:
                pages.append(cur)
            cur = {"num": int(m.group(1)), "title": m.group(2).strip(), "line": i, "body": [], "syntax": "caiqian"}
        elif cur is not None:
            if line.strip() == "【导入结束】" or re.match(r"^\s*二\.角色设定", line):
                pages.append(cur)
                cur = None
            else:
                cur["body"].append(line)
    if cur:
        pages.append(cur)
    for pg in pages:
        # 两种语法都可能有【画面描述】；以「渲染约束」或「位置与样式」判火柴
        if any(RENDER_RE.match(ln) or ln.strip().startswith("位置与样式") for ln in pg["body"]):
            pg["syntax"] = "huochai"
    return pages


def audit_page(p, repl_map):
    hard, warn = [], []
    body = "\n".join(p["body"])
    n = p["num"]
    if p.get("syntax") == "huochai":
        cnt = sum(1 for ln in p["body"] if RENDER_RE.match(ln))
        if cnt == 0:
            hard.append("第%d页[火柴]：缺「渲染约束」行" % n)
        elif cnt > 1:
            hard.append("第%d页[火柴]：「渲染约束」出现 %d 次，应恰好一次" % (n, cnt))

    texts = []
    lines = p["body"]
    for i, line in enumerate(lines):
        m = TEXT_RE.match(line)
        if not m:
            continue
        raw = re.sub(r"<[^>]*>", "", m.group(1).strip())
        q = raw.count('"') + raw.count("“") + raw.count("”")
        if q and q != 2:
            hard.append("第%d页：文字项引号不成对（%d 个），会破坏定界" % (n, q))
        inner = raw
        if len(inner) >= 2 and inner[0] in '"“' and inner[-1] in '"”':
            inner = inner[1:-1]
        if not inner.strip():
            hard.append("第%d页：存在空文字项" % n)
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        if not POS_RE.match(nxt):
            hard.append("第%d页：文字项后缺「类型与位置」" % n)
        texts.append(inner)

    if not texts:
        hard.append("第%d页：无任何文字项（空镜）" % n)

    scene = SCENE_RE.search(body)
    cast = CAST_RE.search(body)
    has_cast = bool(cast and cast.group(1).strip() and cast.group(1).strip() != "无")
    if p.get("syntax") != "huochai" and has_cast and (not scene or not scene.group(1).strip() or scene.group(1).strip() in ("无", "無")):
        warn.append("第%d页：有出场角色但场景描述为空（只有人物没有场景）" % n)

    if not re.search(r"^\s*景别\s*[:：]", body, re.M):
        warn.append("第%d页：缺「景别」字段" % n)

    if n == 1:
        m = re.search(r"^\s*分镜构图\s*[:：]\s*(.+)$", body, re.M)
        if not m:
            warn.append("第1页：缺「分镜构图」字段，无法确认单页大图")
        elif "单页大图" not in m.group(1):
            hard.append(
                "第1页：构图是「%s」，必须为单页大图（优先于所选排版）" % m.group(1).strip()[:24]
            )

    for t in texts:
        for src, dst in repl_map.items():
            if src in t:
                hard.append("第%d页：文字含未替换的「%s」（应替换为「%s」）" % (n, src, dst))

    # 床／凶／血／巴掌／耳光 必须为 0：已用 8px 删除线遮挡的（用户选「不要改原文」）放行
    _flat = SPAN_RE.sub("", body)
    for ch in ("床", "凶", "血", "巴掌", "耳光"):
        if ch in _flat:
            ctx = body[max(0, body.find(ch) - 8): body.find(ch) + 8].replace("\n", " ")
            hard.append("第%d页：残留「%s」（上下文：%s），须按 BO-01 改写" % (n, ch, ctx))

    span_texts = SPAN_RE.findall(body)
    flat = SPAN_RE.sub("", body)
    for w in SENSITIVE:
        if w in flat:
            where = "文字" if any(w in t for t in texts) else "画面"
            hard.append("第%d页：敏感词「%s」未被 span 遮挡（%s）" % (n, w, where))
    if body.count("<span") != len(span_texts):
        warn.append("第%d页：存在未闭合的 span 标签" % n)
    for attrs in re.findall(r"<span([^>]*)>", body):
        if "8px" not in attrs.replace(" ", ""):
            hard.append("第%d页：删除线缺少 8px 粗细" % n)
        if not re.search(r"#fff(?:fff)?\b", attrs, re.I):
            hard.append("第%d页：删除线颜色不是 #FFFFFF" % n)

    if any(w in body for w in GORE) or any(w in body for w in WEAPON):
        if not any(h in body for h in MASK_HINT):
            warn.append("第%d页：出现血腥/刀具描述但未标注打码或模糊" % n)

    # 置顶③ 瞬间定格：过程词告警（只查「画面」字段，避免台词里的「正在」误报）
    scene_seg = re.search(
        r"^\s*画面\s*[:：]([\s\S]*?)(?=^\s*(?:景别|台词|文字|类型|位置|分镜构图|出场角色|场景描述)\s*[:：]|\Z)",
        body, re.M)
    scan_text = scene_seg.group(1) if scene_seg else ""
    if scene_seg:
        n_char = len(re.sub(r"\s", "", scene_seg.group(1)))
        if n_char > MAX_SCENE_CHARS:
            warn.append("第%d页：画面描述 %d 字，超过 %d 字上限，建议压缩细节" % (n, n_char, MAX_SCENE_CHARS))
    for pat in PROCESS_PATTERNS:
        m = re.search(pat, scan_text)
        if m:
            ctx = scan_text[max(0, m.start() - 8): m.end() + 8].replace("\n", " ")
            warn.append("第%d页：画面疑似过程写法「%s」（上下文：%s），应改为单一瞬间定格" % (n, m.group(0), ctx))

    if "手机" in body and "特写" not in body:
        warn.append("第%d页：出现手机但未给屏幕特写" % n)

    # 制服页：必须有禁止清单，且不得出现现实/政治符号
    if any(w in body for w in UNIFORM):
        missing = [k for k in ("无徽章", "无肩章") if k not in body]
        if missing:
            warn.append(
                "第%d页：出现制服描述但未写禁止清单（缺 %s），易被画出现实徽章肩章"
                % (n, "、".join(missing))
            )
        if not any(c in body for c in CAMPS):
            warn.append(
                "第%d页：出现制服但未写明所属阵营（军方／警方／军阀），三阵营须择一并全篇统一"
                % n
            )
    for sym in FORBIDDEN_SYMBOL:
        if sym in body:
            hard.append("第%d页：出现禁止符号「%s」，必须移除并改为架空标识" % (n, sym))
    for sym in NATIONAL_SYMBOL:
        if sym in body:
            hard.append("第%d页：出现现实国家象征「%s」，必须移除并改为架空标识" % (n, sym))
    for w in FORMULA:
        if w in body:
            warn.append("第%d页：出现模糊/敷衍句式「%s」，须改写为具体视线落点或微表情" % (n, w))
    for w in VAGUE_REF:
        if w in body:
            warn.append("第%d页：出现模糊指代「%s」，须改为「姓名＋标志性外貌」" % (n, w))
    for w in NATIONAL_ORG:
        if w in body:
            warn.append("第%d页：出现现实机构/制式元素「%s」，需按 BO-02 架空阵营改写" % (n, w))
    for w in RANK_TERMS:
        if w in body:
            hard.append("第%d页：出现现实称谓「%s」，须按称谓表替换" % (n, w))

    return hard, warn


def main(argv=None):
    ap = argparse.ArgumentParser(description="fenjing-yym 分镜稿校验")
    ap.add_argument("--file", required=True)
    ap.add_argument("--min", type=int, default=None)
    ap.add_argument("--max", type=int, default=None)
    ap.add_argument("--allow-partial", action="store_true", help="局部页稿，跳过页码从1连续校验")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--excerpt", default=None,
                    help="只把命中问题的页抽成摘录文件，供复查时读，避免通读全稿")
    ap.add_argument("--strict", action="store_true",
                    help="把过程词/模糊指代/敷衍句式三类警告升级为硬错误")
    args = ap.parse_args(argv)

    p = Path(args.file)
    if not p.is_file():
        raise SystemExit("找不到稿件：%s" % p)
    text = read_text(p)
    lo, hi = load_page_range()
    lo = args.min or lo
    hi = args.max or hi
    repl_map = {r[0]: r[1] for r in load_table("【后门 BO-01") if len(r) >= 2}
    global RANK_TERMS
    RANK_TERMS = load_rank_terms()

    hard, warn = [], []

    pages = split_pages(text)
    count = len(pages)
    if args.allow_partial:
        # 分段自校：结构标记与页数区间只作提示，不当硬错误
        for s in STRUCT:
            if s not in text:
                warn.append("缺结构标记：%s（分段稿可忽略，合并后必须补齐）" % s)
        if count > hi:
            warn.append("当前 %d 页已超上限 %d" % (count, hi))
    else:
        marks = STRUCT_HUOCHAI if "【逐页分镜】" in text else STRUCT
        for s in marks:
            if s not in text:
                hard.append("缺结构标记：%s" % s)
        if not (lo <= count <= hi):
            hard.append("页数 %d 不在 %d–%d 区间" % (count, lo, hi))

    nums = [pg["num"] for pg in pages]
    if len(nums) != len(set(nums)):
        dup = sorted({x for x in nums if nums.count(x) > 1})
        hard.append("页码重复：%s" % dup)
    if not args.allow_partial:
        expect = list(range(1, count + 1))
        if nums != expect:
            bad = [(a, b) for a, b in zip(nums, expect) if a != b][:5]
            hard.append("页码未从 1 连续递增，前几处偏差（实际,期望）：%s" % bad)

    page_issues = {}
    for pg in pages:
        h, w = audit_page(pg, repl_map)
        hard += h
        warn += w
        if h or w:
            page_issues[pg["num"]] = {"hard": h, "warn": w}

    if not pages:
        hard.append("未解析到任何页（检查页标题格式：第X页 | 标题）")

    result = {
        "file": str(p),
        "pages": count,
        "range": [lo, hi],
        "hard": hard,
        "warn": warn,
        "verdict": "不合格，禁止提交" if hard else ("可提交（有警告）" if warn else "通过"),
    }

    if args.strict:
        keep = []
        for w in warn:
            (hard if any(k in w for k in STRICT_HINTS) else keep).append(w)
        warn = keep

    if args.excerpt:
        hits = [pg for pg in pages if pg["num"] in page_issues]
        out = ["# 待修页摘录（命中 %d 页 / 共 %d 页）" % (len(hits), len(pages)), ""]
        for pg in hits:
            iss = page_issues[pg["num"]]
            out.append("## 第%d页 | %s" % (pg["num"], pg["title"]))
            out.append("")
            for x in iss["hard"]:
                out.append("- ✗ %s" % x)
            for x in iss["warn"]:
                out.append("- ! %s" % x)
            out.append("")
            out.append("```")
            out.append("\n".join(pg["body"]).strip())
            out.append("```")
            out.append("")
        Path(args.excerpt).write_text("\n".join(out), encoding="utf-8", newline="\n")
        print("摘录已写出：%s（%d 页）" % (args.excerpt, len(hits)))

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("== fenjing-yym audit ==")
        print("文件：%s" % p.name)
        print("页数：%d（要求 %d–%d）" % (count, lo, hi))
        if hard:
            print("\n[硬错误 %d]" % len(hard))
            for x in hard:
                print("  ✗ %s" % x)
        if warn:
            print("\n[警告 %d]" % len(warn))
            for x in warn:
                print("  ! %s" % x)
        print("\n结论：%s" % result["verdict"])

    if hard:
        return 1
    return 2 if warn else 0


if __name__ == "__main__":
    sys.exit(main())
