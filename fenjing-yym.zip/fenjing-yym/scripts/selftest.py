#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""离线自检：把每个脚本真跑一遍，抓语法错、缺 import、参数崩这类问题。

用法：
    python scripts/selftest.py
    python scripts/selftest.py --quiet

设计原则：不联网、不碰真实技能目录、不改任何文件（只在临时目录建假发布源）。
退出码：0 全通过 / 1 有失败
"""

import argparse
import json
import py_compile
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = sys.executable
SCRIPTS = (
    "update_check.py",
    "update_apply.py",
    "update.py",
    "grow_tables.py",
    "setup_deliver.py",
    "check_package.py",
    "publish_release.py",
    "doctor.py",
    "prep_text.py",
    "audit_storyboard.py",
)


def run(args, timeout=60, env=None):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=env)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "超时"


def main(argv=None):
    ap = argparse.ArgumentParser(description="离线自检")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args(argv)

    fails, notes = [], []

    # 1) 语法编译
    for name in SCRIPTS:
        p = ROOT / "scripts" / name
        if not p.is_file():
            fails.append("%s 不存在" % name)
            continue
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception as e:  # noqa: BLE001
            fails.append("%s 语法错：%s" % (name, e))
    notes.append("语法编译：%d 个脚本" % len(SCRIPTS))

    # 2) 每个脚本至少能起得来（--help）
    for name in SCRIPTS:
        if name == "prep_text.py" or name == "audit_storyboard.py":
            continue  # 需要输入文件，--help 已由 argparse 覆盖，跳过以免噪音
        rc, out = run([PY, str(ROOT / "scripts" / name), "--help"])
        if rc != 0:
            fails.append("%s --help 失败：%s" % (name, out.strip().splitlines()[:1]))
    notes.append("参数入口：--help 可用")

    # 3) 更新链路：假发布源跑一次 dry-run（能抓 resolve_source 这类运行时错）
    tmp = Path(tempfile.mkdtemp(prefix="fenjing-selftest-"))
    try:
        rel = tmp / "rel"
        rel.mkdir()
        pkg = rel / "fenjing-yym.zip"
        with zipfile.ZipFile(pkg, "w") as z:
            z.writestr("fenjing-yym/SKILL.md", "# fake\n")
            z.writestr("fenjing-yym/version.json", json.dumps({"skill_version": "9999.1.1"}))
        import hashlib
        sha = hashlib.sha256(pkg.read_bytes()).hexdigest()
        (rel / "version.json").write_text(json.dumps({
            "skill_version": "9999.1.1", "tables_version": "9999.1.1",
            "package": "fenjing-yym.zip", "sha256": sha,
            "published_at": "2000-01-01T00:00:00+08:00", "notes": "selftest",
        }, ensure_ascii=False), encoding="utf-8")

        rc, out = run([PY, str(ROOT / "scripts" / "update_apply.py"), "--source", str(rel), "--dry-run"])
        if rc != 0 or "计划" not in out:
            fails.append("update_apply --dry-run 失败：%s" % out.strip().splitlines()[:2])
        else:
            notes.append("更新计划：dry-run 正常")

        # 再跑一次「不给 --source」，走环境变量分支（能抓 resolve_source 里的 NameError 之类）
        env = dict(__import__("os").environ)
        env["FENJING_UPDATE_SOURCE"] = str(rel)
        rc2, out2 = run([PY, str(ROOT / "scripts" / "update_apply.py"), "--dry-run"], env=env)
        if rc2 != 0 or "计划" not in out2:
            fails.append("update_apply 无 --source（走环境变量）失败：%s" % out2.strip().splitlines()[:2])
        else:
            notes.append("默认源解析：环境变量分支正常")

        rc, out = run([PY, str(ROOT / "scripts" / "update_check.py"), "--source", str(rel)])
        if rc not in (0, 1):
            fails.append("update_check 失败：%s" % out.strip().splitlines()[:2])
        else:
            notes.append("版本检查：可读取假清单（退出码 %d）" % rc)

        # 4) http 分支：本地起一个只读服务，跑 check 与 dry-run（抓 http 路径里的运行时错）
        import functools
        import http.server
        import socketserver
        import threading

        handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(rel))
        httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
        port = httpd.server_address[1]
        th = threading.Thread(target=httpd.serve_forever, daemon=True)
        th.start()
        try:
            base = "http://127.0.0.1:%d" % port
            rc3, out3 = run([PY, str(ROOT / "scripts" / "update_check.py"), "--source", base])
            if rc3 not in (0, 1):
                fails.append("update_check（http）失败：%s" % out3.strip().splitlines()[:2])
            else:
                notes.append("http 分支：版本检查正常")

            rc4, out4 = run([PY, str(ROOT / "scripts" / "update_apply.py"),
                             "--source", base + "/version.json", "--dry-run"])
            if rc4 != 0 or "计划" not in out4:
                fails.append("update_apply（http）失败：%s" % out4.strip().splitlines()[:2])
            else:
                notes.append("http 分支：更新计划正常")
        finally:
            httpd.shutdown()
            httpd.server_close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    if not args.quiet:
        print("== 离线自检 ==")
        for n in notes:
            print("  [ok] %s" % n)
        if fails:
            print("\n[失败 %d]" % len(fails))
            for f in fails:
                print("  ✗ %s" % f)
        print("\n结论：%s" % ("通过" if not fails else "未通过"))
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
