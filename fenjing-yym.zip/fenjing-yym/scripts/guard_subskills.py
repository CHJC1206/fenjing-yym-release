#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""子技能入口守卫：检查 / 写入 / 移除一行守卫声明（迁移用）。

守卫的作用：当 `fenjing-yym` 已派发任务、而平台又把 `xiaoshuoman` /
`manhuaxiaoshuo` 的正文一起注入上下文时，让子技能只提供制作细则，
不接管触发条件、默认设置、任务记录与交付路径。

用法：
    python scripts/guard_subskills.py --check     # 只检查，不改文件
    python scripts/guard_subskills.py --apply     # 缺失则补上（幂等）
    python scripts/guard_subskills.py --remove    # 回滚，删掉守卫行
    python scripts/guard_subskills.py --apply --root "<技能根目录>"   # 指定技能目录

只改 SKILL.md 正文第一段，其余内容不动；重复执行为空操作。
只用标准库。
"""

import argparse
import io
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
else:  # pragma: no cover
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

SKILL_ROOT = Path(__file__).resolve().parent.parent
TARGETS = ("xiaoshuoman", "manhuaxiaoshuo")
MARKER = "入口守卫"
GUARD = (
    "> 入口守卫：若本次任务由 `fenjing-yym` 派发，仅采用本文件的制作细则与输出格式；"
    "本文件的触发条件、默认设置、任务记录与交付路径由上层覆盖。"
)


def skills_roots(extra_root=None):
    cands = []
    if extra_root:
        cands.append(Path(extra_root))
    cands.append(SKILL_ROOT.parent)
    home = Path.home()
    cands += [
        home / ".workbuddy" / "skills",
        home / ".claude" / "skills",
        home / ".codebuddy" / "skills",
    ]
    seen, out = set(), []
    for c in cands:
        try:
            key = str(c.resolve()).lower()
        except Exception:
            key = str(c).lower()
        if key not in seen and c.is_dir():
            seen.add(key)
            out.append(c)
    return out


def locate(roots):
    found = {}
    for name in TARGETS:
        for r in roots:
            p = r / name / "SKILL.md"
            if p.is_file():
                found[name] = p
                break
    return found


def read(p):
    return p.read_bytes().decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")


def write(p, text):
    p.write_bytes(text.encode("utf-8"))


def has_guard(text):
    return MARKER in text and "fenjing-yym" in text.split(MARKER, 1)[1][:200]


def insert_guard(text):
    if has_guard(text):
        return text, False
    lines = text.split("\n")
    h1 = next((i for i, l in enumerate(lines) if re.match(r"^#\s+\S", l)), None)
    if h1 is None:
        return text, False
    # 跳过标题后的空行，插到正文之前
    j = h1 + 1
    while j < len(lines) and not lines[j].strip():
        j += 1
    lines[h1 + 1 : j] = ["", GUARD, ""]
    return "\n".join(lines), True


def remove_guard(text):
    if not has_guard(text):
        return text, False
    lines = [l for l in text.split("\n") if not (MARKER in l and "fenjing-yym" in l)]
    out = "\n".join(lines)
    out = re.sub(r"\n{3,}", "\n\n", out)
    return out, True


def main(argv=None):
    ap = argparse.ArgumentParser(description="子技能入口守卫管理")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--apply", action="store_true")
    g.add_argument("--remove", action="store_true")
    ap.add_argument("--root", default=None, help="显式指定技能根目录（测试/迁移用）")
    args = ap.parse_args(argv)

    found = locate(skills_roots(args.root))
    rc = 0
    for name in TARGETS:
        p = found.get(name)
        if not p:
            print("[MISS] %-16s 未找到（跳过）" % name)
            if args.check:
                rc = 0
            continue
        text = read(p)
        if args.check:
            ok = has_guard(text)
            print("[%s] %-16s %s" % ("OK  " if ok else "WARN", name, p))
            if not ok:
                print("       ↘ 缺入口守卫，运行 --apply 补齐")
        elif args.apply:
            new, changed = insert_guard(text)
            if changed:
                write(p, new)
            print("[%s] %-16s %s" % ("+ " if changed else "= ", name, p))
        else:
            new, changed = remove_guard(text)
            if changed:
                write(p, new)
            print("[- ] %-16s %s" % (name, p))
    return rc


if __name__ == "__main__":
    sys.exit(main())
