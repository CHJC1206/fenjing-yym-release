#!/usr/bin/env node
/**
 * 悠悠漫 MCP 驱动器（单文件、零依赖）
 * 用法：
 *   node yy.mjs doctor
 *   node yy.mjs locate [--force]
 *   node yy.mjs tools
 *   node yy.mjs styles [--project <id>] [--all]
  node yy.mjs style-check --name "<画风名或ID>" [--json]
 *   node yy.mjs call <tool> '<json>'
 *   node yy.mjs run --file "<绝对路径.md>" [--style 现代Q版] [--name 稿名] [--desc 备注] [--episode N] [--new|--reuse] [--refresh-style]
 *                   [--reimport] [--new] [--dry-run] [--json]
 * 环境变量：
 *   YY_HOME   安装根目录（含 resources\mcp\server.mjs）
 *   YY_EXE    客户端 exe 路径
 *   YY_NODE   node 可执行文件路径
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';

const nodeRequire = createRequire(import.meta.url);

const SELF = path.resolve(process.argv[1]);
const BASE = path.dirname(SELF);
const IS_WIN = process.platform === 'win32';
const CFG_DIR = IS_WIN
  ? path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'yy-mcp')
  : path.join(os.homedir(), '.config', 'yy-mcp');
const CFG_PATH = path.join(CFG_DIR, 'yy-mcp.json');

/* ------------------------------ 配置与定位 ------------------------------ */

const BUILTIN_STYLES = [
  ['Q版圆润火柴人（现代Q版）', 'style-qban-yuanrun-huochairen'],
  ['Q版火柴人（现代酷版）', 'style-qban-huochairen'],
  ['Q版古言圆润火柴人', 'style-qban-guyan-yuanrun-huochairen'],
  ['Q版古言火柴人', 'style-qban-guyan-huochairen'],
  ['实感火柴人', 'style-shigan-huochairen'],
  ['都市言情火柴人', 'style-dushi-yanqing-huochairen-mingliang-jingzhi'],
  ['彩铅手绘', 'style-caiqian-shouhui'],
  ['钢笔淡彩手绘', 'style-gangbi-dancai-shouhui'],
  ['清新韩漫', 'style-default'],
  ['新古风韩漫柔光', 'style-xin-gufeng-hanman-rouguang'],
  ['上文下图', 'style-1791256111967-z10s9d'],
  ['自定义新画风', 'style-1786700640159-52ncev'],
].map(([name, id]) => ({ name, id, builtin: true }));

const STYLE_ALIAS = {
  '现代q版': 'style-qban-yuanrun-huochairen',
  'q版圆润火柴': 'style-qban-yuanrun-huochairen',
  '圆润火柴': 'style-qban-yuanrun-huochairen',
  '现代酷版': 'style-qban-huochairen',
  'q版火柴': 'style-qban-huochairen',
  '古代q版': 'style-qban-guyan-yuanrun-huochairen',
  'q版古言圆润火柴': 'style-qban-guyan-yuanrun-huochairen',
  '古代酷版': 'style-qban-guyan-huochairen',
  'q版古言火柴': 'style-qban-guyan-huochairen',
  '实感': 'style-shigan-huochairen',
  '都市言情': 'style-dushi-yanqing-huochairen-mingliang-jingzhi',
  '彩铅': 'style-caiqian-shouhui',
  '第一遍制作': 'style-caiqian-shouhui',
  '彩铅纸白第一次': 'style-caiqian-shouhui',
  // 彩铅全彩：客户端有同名项时正名优先命中；此处仅在缺失时回退钢笔淡彩
  '彩铅全彩': 'style-gangbi-dancai-shouhui',
  '彩铅全彩第二次': 'style-gangbi-dancai-shouhui',
  '钢笔淡彩': 'style-gangbi-dancai-shouhui',
  '第二遍制作': 'style-gangbi-dancai-shouhui',
  '韩漫': 'style-default',
  '韩漫言情': 'style-default',
  '清新韩漫言情': 'style-default',
  '国风言情': 'style-xin-gufeng-hanman-rouguang',
  '古风言情': 'style-xin-gufeng-hanman-rouguang',
  '新古风韩漫': 'style-xin-gufeng-hanman-rouguang',
  '上文下图': 'style-1791256111967-z10s9d',
  '新画风': 'style-1786700640159-52ncev',
};

const norm = (s) =>
  String(s || '')
    .toLowerCase()
    .replace(/[（(][^）)]*[）)]/g, '')
    .replace(/[\s\-_·、，,。.\/\\|:：]/g, '')
    .trim();

/** 修正 Git Bash / MSYS 传参造成的 <盘符>://Users//x 形式 */
const winPath = (p) => {
  if (!p || typeof p !== 'string') return p;
  return IS_WIN ? path.win32.normalize(p.replace(/\//g, '\\').replace(/\\{2,}/g, '\\')) : p;
};

const doc = (p) => (p && typeof p === 'object' ? p : {});

function readCfg() {
  try {
    const c = JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));
    if (c.mcpDir && fs.existsSync(path.join(c.mcpDir, 'server.mjs'))) return c;
  } catch {}
  return null;
}

function writeCfg(cfg) {
  try {
    fs.mkdirSync(CFG_DIR, { recursive: true });
    fs.writeFileSync(CFG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
  } catch {}
}

// 本机画风缓存：记录「画风名 → {id, 找到它的项目}」，
// 命中时不再调用 list_generation_options，避免每次导入都在客户端开一堆项目标签。
const STYLE_CACHE_PATH = path.join(CFG_DIR, 'style-cache.json');

const RECORDS_DB = path.join(
  process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'),
  'storyboard-image-generator',
  'desktop-records-v1',
  'records.sqlite'
);

function readCurrentProjectId() {
  try {
    // 屏蔽 node:sqlite 的实验性告警，避免污染输出
    const origWarn = process.emitWarning;
    process.emitWarning = function (w, ...rest) {
      if (String(w).includes('SQLite')) return;
      return origWarn.call(process, w, ...rest);
    };
    const { DatabaseSync } = nodeRequire('node:sqlite');
    const db = new DatabaseSync(RECORDS_DB, { readOnly: true });
    const row = db.prepare("SELECT raw FROM records WHERE key = 'comic-maker-current-project-id-v1'").get();
    db.close();
    if (!row || !row.raw) return null;
    const txt = Buffer.from(row.raw).toString('utf16le').replace(/\u0000/g, '');
    const v = JSON.parse(txt);
    return typeof v === 'string' ? v : null;
  } catch {
    return null;
  }
}

// 离线画风索引：直接从客户端本地 sqlite 的 uiConfig 记录里抽 styleProfiles，
// 完全不调用 MCP，也就不会打开任何项目标签。
function readLocalStyleIndex() {
  const map = new Map();
  try {
    const origWarn = process.emitWarning;
    process.emitWarning = function (w, ...rest) {
      if (String(w).includes('SQLite')) return;
      return origWarn.call(process, w, ...rest);
    };
    const { DatabaseSync } = nodeRequire('node:sqlite');
    const db = new DatabaseSync(RECORDS_DB, { readOnly: true });
    const rows = db
      .prepare("SELECT key, raw FROM records WHERE key LIKE 'comic-maker-project-%-uiConfig'")
      .all();
    db.close();
    for (const r of rows) {
      if (!r.raw) continue;
      const pid = String(r.key)
        .replace('comic-maker-project-', '')
        .replace(/-uiConfig$/, '');
      let obj;
      try {
        obj = JSON.parse(Buffer.from(r.raw).toString('utf16le').replace(/\u0000/g, ''));
      } catch {
        continue;
      }
      const arr = obj.styleProfiles || obj.styleProfileList || [];
      for (const s of arr) {
        const id = s.id || s.styleId;
        const nm = s.name || s.label || s.displayName;
        if (!id || !nm) continue;
        const k = norm(nm);
        const arr = map.get(k) || [];
        if (!arr.some((x) => x.id === id)) {
          arr.push({ name: nm, id, projectId: pid, builtin: !!s.origin && s.origin === 'builtin' });
        }
        map.set(k, arr);
      }
    }
  } catch {
    /* 读不到就返回空表，走后续探测 */
  }
  return map;
}

function readStyleCache() {
  try {
    return JSON.parse(fs.readFileSync(STYLE_CACHE_PATH, 'utf8')) || {};
  } catch {
    return {};
  }
}

function writeStyleCache(obj) {
  try {
    fs.mkdirSync(CFG_DIR, { recursive: true });
    fs.writeFileSync(STYLE_CACHE_PATH, JSON.stringify(obj, null, 2), 'utf8');
  } catch {}
}

function validMcpDir(dir) {
  return !!dir && fs.existsSync(path.join(dir, 'server.mjs'));
}

function mcpUnder(root) {
  const cands = [
    path.join(root, 'resources', 'mcp'),
    path.join(root, 'resources', 'app', 'mcp'),
    path.join(root, 'mcp'),
  ];
  for (const c of cands) if (validMcpDir(c)) return c;
  return null;
}

/** 从 exe 路径向上追溯安装根目录 */
function resolveFromExe(exe) {
  let dir = path.dirname(exe);
  for (let i = 0; i < 6 && dir && dir !== path.dirname(dir); i++) {
    const m = mcpUnder(dir);
    if (m) return { mcpDir: m, exe, root: dir };
    dir = path.dirname(dir);
  }
  return null;
}

function readLnkTargets(file) {
  const out = new Set();
  let buf;
  try {
    buf = fs.readFileSync(file);
  } catch {
    return [];
  }
  const grab = (s) => {
    const re = /[A-Za-z]:\\[^\u0000-\u001f<>|?*"]{2,300}/g;
    let m;
    while ((m = re.exec(s))) {
      const p = m[0].replace(/[\s\u0000]+$/, '');
      if (/\.exe$/i.test(p)) out.add(p);
    }
  };
  grab(buf.toString('utf16le'));
  if (buf.toString('latin1').includes(':\\')) grab(buf.toString('latin1'));
  return [...out];
}

function shortcutDirs() {
  const home = os.homedir();
  const appdata = process.env.APPDATA || path.join(home, 'AppData', 'Roaming');
  const progdata = process.env.ProgramData || 'C:\\ProgramData';
  return [
    path.join(home, 'Desktop'),
    path.join(progdata, 'Desktop'),
    path.join(home, 'OneDrive', 'Desktop'),
    path.join(appdata, 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    path.join(progdata, 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    path.join(appdata, 'Microsoft', 'Internet Explorer', 'Quick Launch'),
  ].filter((d) => fs.existsSync(d));
}

function walkShallow(dir, depth, visit) {
  if (depth < 0) return;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    if (/^(node_modules|Windows|System32|\$Recycle\.Bin|AppData)$/i.test(e.name)) continue;
    const full = path.join(dir, e.name);
    if (visit(full, e.name) === true) return;
    walkShallow(full, depth - 1, visit);
  }
}

function installCandidates() {
  const found = [];
  const push = (r) => {
    if (r && !found.some((f) => f.mcpDir === r.mcpDir)) found.push(r);
  };
  const nameRe = /悠悠|youyou|storyboard/i;

  // 1) 快捷方式（桌面 / 开始菜单）
  for (const d of shortcutDirs()) {
    let lnks = [];
    try {
      lnks = fs.readdirSync(d, { withFileTypes: true }).filter((e) => /\.lnk$/i.test(e.name));
    } catch {}
    for (const e of lnks) {
      const p = path.join(d, e.name);
      const targets = readLnkTargets(p);
      for (const t of targets) {
        push(resolveFromExe(t));
      }
      if (nameRe.test(e.name) && !targets.length) {
        // 名字命中但解析不到路径：记录 hint
        found.push({ hint: p });
      }
    }
  }

  // 2) 常见安装位置
  const home = os.homedir();
  const roots = [
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Programs'),
    process.env.LOCALAPPDATA,
    process.env.APPDATA,
    process.env.ProgramFiles,
    process.env['ProgramFiles(x86)'],
    process.env.ProgramW6432,
    'C:\\Program Files',
    'C:\\Program Files (x86)',
  ].filter(Boolean);
  for (const r of roots) {
    if (!fs.existsSync(r)) continue;
    let kids = [];
    try {
      kids = fs.readdirSync(r, { withFileTypes: true });
    } catch {}
    for (const k of kids) {
      if (!k.isDirectory()) continue;
      if (!nameRe.test(k.name)) continue;
      const m = mcpUnder(path.join(r, k.name));
      if (m) push({ mcpDir: m, root: path.join(r, k.name), exe: guessExe(path.join(r, k.name)) });
    }
  }

  // 3) 各盘浅层扫描（兜底）
  if (IS_WIN && !found.filter((f) => f.mcpDir).length) {
    for (const letter of 'CDEFGH') {
      const drive = `${letter}:\\`;
      if (!fs.existsSync(drive)) continue;
      walkShallow(drive, 2, (full, name) => {
        if (!nameRe.test(name)) return false;
        const m = mcpUnder(full);
        if (m) {
          push({ mcpDir: m, root: full, exe: guessExe(full) });
          return true;
        }
        return false;
      });
      if (found.filter((f) => f.mcpDir).length) break;
    }
  }
  return found.filter((f) => f.mcpDir);
}

function guessExe(root) {
  try {
    const hit = fs
      .readdirSync(root)
      .filter((n) => /\.exe$/i.test(n))
      .map((n) => path.join(root, n))
      .find((p) => /悠悠|youyou|storyboard/i.test(path.basename(p)));
    if (hit) return hit;
    const anyExe = fs
      .readdirSync(root)
      .filter((n) => /\.exe$/i.test(n))
      .map((n) => path.join(root, n));
    return anyExe[0] || null;
  } catch {
    return null;
  }
}

function locate(force = false) {
  if (process.env.YY_HOME) {
    const h = winPath(process.env.YY_HOME);
    const m = validMcpDir(h) ? h : mcpUnder(h);
    if (m) {
      const root = /[\\/]resources[\\/]mcp$/i.test(m) ? path.dirname(path.dirname(m)) : path.dirname(m);
      return { mcpDir: m, exe: winPath(process.env.YY_EXE) || guessExe(root), root, from: 'env' };
    }
  }
  if (!force) {
    const cfg = readCfg();
    if (cfg) return { ...cfg, from: 'cache' };
  }
  const hits = installCandidates();
  if (!hits.length) return null;
  const best = hits[0];
  const cfg = { mcpDir: best.mcpDir, exe: best.exe || null, root: best.root || null };
  writeCfg(cfg);
  return { ...cfg, from: 'scan' };
}

/* ------------------------------ MCP 客户端 ------------------------------ */

class McpClient {
  constructor(proc) {
    this.proc = proc;
    this.seq = 0;
    this.buf = '';
    this.waiters = new Map();
    this.stderr = '';
    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', (d) => this._feed(d));
    proc.stderr.setEncoding('utf8');
    proc.stderr.on('data', (d) => {
      this.stderr = (this.stderr + d).slice(-4000);
    });
    proc.on('exit', (code) => {
      for (const [, w] of this.waiters) w.reject(new Error(`MCP 进程退出 code=${code} ${this.stderr.slice(-400)}`));
      this.waiters.clear();
    });
  }

  _feed(chunk) {
    this.buf += chunk;
    let idx;
    while ((idx = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, idx).trim();
      this.buf = this.buf.slice(idx + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        continue;
      }
      if (msg.id !== undefined && msg.method && !msg.result && !msg.error) {
        // 服务端反向请求：给个空结果，防止挂起
        this._write({ jsonrpc: '2.0', id: msg.id, result: {} });
        continue;
      }
      if (msg.id !== undefined && this.waiters.has(msg.id)) {
        const w = this.waiters.get(msg.id);
        this.waiters.delete(msg.id);
        clearTimeout(w.timer);
        msg.error ? w.reject(new Error(JSON.stringify(msg.error))) : w.resolve(msg.result);
      }
    }
  }

  _write(obj) {
    try {
      this.proc.stdin.write(JSON.stringify(obj) + '\n');
    } catch {}
  }

  _pending(id, ms, label) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.waiters.delete(id);
        reject(new Error(`${label} 超时 ${ms}ms`));
      }, ms);
      this.waiters.set(id, { resolve, reject, timer });
    });
  }

  async initialize(ms = 20000) {
    const id = ++this.seq;
    const p = this._pending(id, ms, 'initialize');
    this._write({
      jsonrpc: '2.0',
      id,
      method: 'initialize',
      params: {
        protocolVersion: '2024-11-05',
        capabilities: {},
        clientInfo: { name: 'yy-mcp', version: '1.0.0' },
      },
    });
    const res = await p;
    this._write({ jsonrpc: '2.0', method: 'notifications/initialized', params: {} });
    return res;
  }

  async listToolsRaw(ms = 15000) {
    const id = ++this.seq;
    const p = this._pending(id, ms, 'tools/list');
    this._write({ jsonrpc: '2.0', id, method: 'tools/list', params: {} });
    const r = await p;
    return r.tools || [];
  }

  async listTools(ms = 15000) {
    return (await this.listToolsRaw(ms)).map((t) => t.name);
  }

  async call(name, args = {}, ms = 120000) {
    const id = ++this.seq;
    const p = this._pending(id, ms, `tools/call ${name}`);
    this._write({ jsonrpc: '2.0', id, method: 'tools/call', params: { name, arguments: args } });
    const r = await p;
    const text = (r.content || [])
      .filter((c) => c.type === 'text')
      .map((c) => c.text)
      .join('\n');
    if (r.isError) throw new Error(`${name} 失败: ${text}`);
    return parseMaybeJson(text);
  }

  close() {
    try {
      this.proc.stdin.end();
    } catch {}
    setTimeout(() => {
      try {
        this.proc.kill();
      } catch {}
    }, 200);
  }
}

function parseMaybeJson(text) {
  if (text && typeof text === 'object') return text;
  const t = String(text || '').trim();
  if (!t) return '';
  try {
    return JSON.parse(t);
  } catch {}
  const start = t.search(/[[{]/);
  const end = Math.max(t.lastIndexOf('}'), t.lastIndexOf(']'));
  if (start >= 0 && end > start) {
    try {
      return JSON.parse(t.slice(start, end + 1));
    } catch {}
  }
  return t;
}

async function connect(loc, ms = 20000) {
  const server = path.join(loc.mcpDir, 'server.mjs');
  const strategies = [];
  if (process.env.YY_NODE) strategies.push({ label: 'YY_NODE', cmd: process.env.YY_NODE, env: {} });
  strategies.push({ label: 'node', cmd: process.execPath, env: { ELECTRON_RUN_AS_NODE: '1' } });
  if (loc.exe) strategies.push({ label: 'client-exe', cmd: loc.exe, env: { ELECTRON_RUN_AS_NODE: '1' } });

  const errors = [];
  for (const s of strategies) {
    const proc = spawn(s.cmd, [server], {
      cwd: loc.mcpDir,
      env: { ...process.env, ...s.env },
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });
    const client = new McpClient(proc);
    try {
      await client.initialize(ms);
      return client;
    } catch (e) {
      errors.push(`${s.label}: ${e.message.split('\n')[0]}`);
      client.close();
    }
  }
  throw new Error('MCP 连接失败\n  ' + errors.join('\n  '));
}

/* ------------------------------ 工具函数 ------------------------------ */

const first = (obj, keys, dflt = undefined) => {
  if (!obj || typeof obj !== 'object') return dflt;
  for (const k of keys) if (obj[k] !== undefined && obj[k] !== null) return obj[k];
  return dflt;
};

const deepArray = (obj, keys) => {
  if (Array.isArray(obj)) return obj;
  if (!obj || typeof obj !== 'object') return [];
  for (const k of keys) if (Array.isArray(obj[k])) return obj[k];
  for (const v of Object.values(obj)) {
    if (Array.isArray(v) && v.length && typeof v[0] === 'object') return v;
  }
  return [];
};

// 项目列表缓存 60 秒：一次任务里多处需要项目清单，避免重复往返客户端
const PROJECTS_CACHE = path.join(os.tmpdir(), "yym-projects-cache.json");

async function readProjectsCached(client) {
  try {
    const raw = JSON.parse(fs.readFileSync(PROJECTS_CACHE, "utf8"));
    if (Date.now() - (raw.at || 0) < 60000 && Array.isArray(raw.projects)) return raw.projects;
  } catch {}
  const list = deepArray(await client.call("list_projects", {}), ["projects", "items", "list"]);
  try {
    fs.writeFileSync(PROJECTS_CACHE, JSON.stringify({ at: Date.now(), projects: list }), "utf8");
  } catch {}
  return list;
}

const rid = (prefix, seed) =>
  `${prefix}-${crypto.createHash('sha1').update(String(seed)).digest('hex').slice(0, 8)}`;

function stylePool(options) {
  const pool = [];
  const add = (name, id) => {
    if (!id) return;
    if (pool.some((p) => p.id === id)) return;
    pool.push({ name: name || id, id, builtin: false });
  };
  for (const o of options) add(first(o, ['name', 'label', 'title', 'displayName', 'styleName']), first(o, ['id', 'styleId', 'profileId', 'key', 'value']));
  for (const b of BUILTIN_STYLES) if (!pool.some((p) => p.id === b.id)) pool.push(b);
  return pool;
}

function resolveStyle(query, options) {
  const pool = stylePool(options);
  const q = String(query || '').trim();
  if (!q) throw new Error(`未指定画风。可选：\n${pool.map((p) => `  ${p.name}  ->  ${p.id}`).join('\n')}`);
  let hit = pool.find((p) => p.id.toLowerCase() === q.toLowerCase());
  if (hit) return hit;
  const nq = norm(q);
  hit = pool.find((p) => norm(p.name) === nq);
  if (hit) return hit;
  const aliasId = STYLE_ALIAS[nq];
  if (aliasId) {
    hit = pool.find((p) => p.id === aliasId);
    if (hit) return hit;
    return { name: q, id: aliasId, builtin: true };
  }
  const fuzzy = pool.filter((p) => norm(p.name).includes(nq) || nq.includes(norm(p.name)));
  if (fuzzy.length === 1) return fuzzy[0];
  if (fuzzy.length > 1) {
    const exactish = fuzzy.find((p) => norm(p.name).startsWith(nq));
    if (exactish) return exactish;
    throw new Error(
      `画风「${q}」匹配到多个，请写全名或直接用 ID：\n${fuzzy.map((p) => `  ${p.name}  ->  ${p.id}`).join('\n')}`
    );
  }
  throw new Error(`画风「${q}」不存在。可选：\n${pool.map((p) => `  ${p.name}  ->  ${p.id}`).join('\n')}`);
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) out[k] = true;
      else {
        out[k] = next;
        i++;
      }
    } else out._.push(a);
  }
  return out;
}

/* ------------------------------ 命令实现 ------------------------------ */

async function cmdDoctor(loc) {
  const lines = [];
  lines.push(`Node        : ${process.version} (${process.execPath})`);
  lines.push(`MCP 目录    : ${loc.mcpDir}  [${loc.from}]`);
  lines.push(`客户端 EXE  : ${loc.exe || '(未识别)'}`);
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dataDir = path.join(appdata, 'storyboard-image-generator');
  lines.push(`用户数据    : ${dataDir} ${fs.existsSync(dataDir) ? '✔' : '✘'}`);
  const lock = path.join(dataDir, 'lockfile');
  let running = false;
  if (fs.existsSync(lock)) {
    try {
      const fd = fs.openSync(lock, 'r+');
      fs.closeSync(fd);
      running = true;
    } catch {
      running = true; // 被占用 = 有实例
    }
  }
  lines.push(`客户端状态  : ${running || fs.existsSync(lock) ? '运行中（单实例锁存在）' : '未检测到运行实例'}`);
  const client = await connect(loc);
  const tools = await client.listTools();
  lines.push(`MCP 连通    : ✔ 工具 ${tools.length} 个`);
  lines.push(`关键工具    : ${['create_project', 'import_storyboard', 'manage_settings']
    .map((t) => `${t}${tools.includes(t) ? '✔' : '✘'}`)
    .join('  ')}`);
  client.close();
  return lines.join('\n');
}

/** 画风写入后落库：优先专用保存工具，其次 manage_settings 的 save/commit 动作 */
async function persistSettings(client, projectId, seed, expectId) {
  const errors = [];
  // 0) 若 update 已直接落库，跳过多余的保存调用
  if (expectId) {
    try {
      const sRaw = parseMaybeJson(await client.call('get_settings', { projectId }, 20000));
      const f = first(first(sRaw, ['settings', 'data'], sRaw) || {}, ['fields'], {}) || {};
      if (first(f, ['selectedStyleProfileId']) === expectId) return { ok: true, how: 'update 已落库' };
    } catch {}
  }
  let tools = [];
  try {
    tools = await client.listToolsRaw();
  } catch {}
  const names = tools.map((t) => String(t.name));
  const schemaActions = (tool) => {
    const t = tools.find((x) => x.name === tool);
    const e = t?.inputSchema?.properties?.action?.enum;
    return Array.isArray(e) ? e : [];
  };

  // 1) 名称像「保存设置」的专用工具
  const dedicated = names.filter(
    (n) => /(save|commit|persist|apply)/i.test(n) && /(setting|config|style|project|workspace)/i.test(n)
  );
  for (const n of dedicated) {
    try {
      await client.call(n, { projectId, requestId: `${seed}-${n}` }, 30000);
      return { ok: true, how: n };
    } catch (e) {
      errors.push(`${n}: ${e.message.split('\n')[0]}`);
    }
  }

  // 2) manage_settings 自带 save / commit 动作
  const declared = schemaActions('manage_settings').filter((a) => /save|commit|persist|apply/i.test(a));
  const guessed = declared.length ? declared : ['save', 'commit'];
  for (const a of guessed) {
    try {
      await client.call('manage_settings', { projectId, action: a, requestId: `${seed}-${a}` }, 30000);
      return { ok: true, how: `manage_settings:${a}` };
    } catch (e) {
      errors.push(`manage_settings:${a}: ${e.message.split('\n')[0]}`);
    }
  }

  return { ok: false, how: null, errors };
}

async function cmdRun(opts) {
  const file = opts.file && opts.file !== true ? path.resolve(opts.file) : '';
  if (!file || !fs.existsSync(file)) throw new Error('缺少 --file，或文件不存在');
  const name = opts.name && opts.name !== true ? String(opts.name) : path.basename(file).replace(/\.md$/i, '');
  // 客户端按 filePath 读取时不认非 ASCII 路径：先复制成临时英文名再导入
  let importFile = file;
  if (/[^\x00-\x7F]/.test(file)) {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "yym-"));
    importFile = path.join(tmpDir, "storyboard.md");
    fs.copyFileSync(file, importFile);
  }
  const desc =
    opts.desc && opts.desc !== true
      ? String(opts.desc)
      : `小说改编分镜稿${opts.episode && Number(opts.episode) >= 2 ? '（第' + Number(opts.episode) + '集）' : ''}`;
  const styleQuery = opts.style && opts.style !== true ? String(opts.style) : '';
  const dry = !!opts['dry-run'];
  const episode = opts.episode && opts.episode !== true ? parseInt(opts.episode, 10) || 1 : 1;
  // 项目名带内容指纹：同一份成品稿得同名，任一处不同（排版/对白/画风/正文）即不同名。
  // 这样“同一内容做两遍”天然分开，不必也无法靠“第几遍”判断。
  const hash4 = crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex').slice(0, 4).toUpperCase();
  const projName = `${name} 第${episode}集-${hash4}`;
  const show = (s) => console.error(s);

  const loc = locate(!!opts.force || !!opts.relocate);
  if (!loc) throw new Error('未找到悠悠漫安装目录：设置 YY_HOME，或先运行 locate --force');

  const client = await connect(loc);
  try {
    const projects = await readProjectsCached(client);
    const existing = projects.find((p) => String(first(p, ['name', 'title'], '')).trim() === projName);
    const existingId = existing ? first(existing, ['id', 'projectId', '_id']) : null;
    // 同名项目不静默复用：必须由调用方显式选 --new 或 --reuse
    if (existingId && !opts.new && !opts.reuse && !dry) {
      show(`⚠ 同名项目已存在：${projName}（${existingId}）`);
      show('请明确选择：--new 新建一个 ／ --reuse 覆盖旧的（会重导分镜，另一集请勿选复用）');
      process.exitCode = 3;
      return { status: 'need-choice', projectName: projName, projectId: existingId };
    }

    // 画风解析 + 检测阀门：每次任务现查客户端，找不到对应画风即中止，不建项目、不导入
    let styleHit = null;
    if (styleQuery) {
      let options = [];
      let live = false;
      const styleCache = readStyleCache();
      const localIdx = readLocalStyleIndex();
      const cacheKey = norm(styleQuery);
      if (!opts['refresh-style'] && styleCache[cacheKey] && styleCache[cacheKey].id) {
        // 本机缓存优先：命中就不再调用 list_generation_options，避免把项目标签一个个打开
        styleHit = {
          name: styleCache[cacheKey].name || styleQuery,
          id: styleCache[cacheKey].id,
          builtin: false,
        };
        show(`③ 画风取自本机缓存：${styleHit.name} → ${styleHit.id}（用 --refresh-style 可重新探测）`);
      }
      if (!styleHit) {
        const cands = localIdx.get(cacheKey) || [];
        if (cands.length) {
          const curPid = readCurrentProjectId();
          const updAt = new Map(
            projects.map((p) => [
              String(first(p, ['id', 'projectId', '_id'], '')),
              String(first(p, ['updatedAt', 'createdAt'], '')),
            ])
          );
          const pick =
            cands.find((c) => curPid && c.projectId === curPid) ||
            cands.find((c) => existingId && c.projectId === existingId) ||
            [...cands].sort((a, b) =>
              String(updAt.get(b.projectId) || '').localeCompare(String(updAt.get(a.projectId) || ''))
            )[0];
          styleHit = { name: pick.name, id: pick.id, builtin: false };
          show(
            `③ 画风取自客户端本地索引（未打开任何项目）：${pick.name} → ${pick.id}` +
              (cands.length > 1 ? `（同名候选 ${cands.length} 个，已按当前项目/最近使用挑选；可用 --style <ID> 指定）` : '')
          );
        }
      }
      // 画风清单是「按项目」返回的：自定义画风只在其所属项目里可见，
      // 且每查一个项目都会在客户端里打开一个标签，所以数量要压到最小。
      const sortedProjects = [...projects].sort((a, b) => {
        const ta = String(first(a, ['type'], ''));
        const tb = String(first(b, ['type'], ''));
        if ((ta === 'long') !== (tb === 'long')) return ta === 'long' ? -1 : 1;
        const ua = String(first(a, ['updatedAt', 'createdAt'], ''));
        const ub = String(first(b, ['updatedAt', 'createdAt'], ''));
        return ub.localeCompare(ua);
      });
      // 默认只查「当前已打开的项目」：它本来就在前台，查询不新增标签；
      // --refresh-style 时才允许多查几个（会打开标签，属于显式选择）。
      const currentPid = readCurrentProjectId();
      const probeLimit = opts['refresh-style'] ? 3 : 1;
      const probeIds = styleHit ? [] : [...new Set([
        currentPid,
        existingId,
        styleCache[cacheKey] && styleCache[cacheKey].projectId,
        ...sortedProjects.map((p) => first(p, ['id', 'projectId', '_id'])),
      ].filter(Boolean))].slice(0, probeLimit);
      const merged = [];
      let lastErr = null;
      let hitPid = null;
      for (const pid of probeIds) {
        let got = [];
        try {
          const o = await client.call('list_generation_options', { projectId: pid }, 30000);
          got = deepArray(o, ['styleProfiles', 'styles', 'options', 'items']);
        } catch {
          continue;
        }
        if (!got.length) continue;
        live = true;
        merged.push(...got);
        try {
          styleHit = resolveStyle(styleQuery, got);
          options = got;
          hitPid = pid;
          break;
        } catch (e) {
          lastErr = e;
        }
      }
      if (!styleHit && merged.length) {
        try {
          styleHit = resolveStyle(styleQuery, merged);
          options = merged;
        } catch (e) {
          lastErr = e;
        }
      }
      if (styleHit && existingId) {
        const same = localIdx.get(norm(styleHit.name)) || [];
        const hasThere = same.some((c) => c.projectId === existingId && c.id === styleHit.id);
        if (same.length && !hasThere) {
          const where = [...new Set(same.map((c) => c.projectId))].join('、');
          show(
            `⚠ 目标项目未启用该画风：本地索引显示「${styleHit.name}」只存在于 ${where}。` +
              '写入可能失败；可先在该项目的画风设置里选一次，或导入到上面那个项目。'
          );
        }
      }
      if (styleHit && !styleCache[cacheKey]) {
        const next = { ...styleCache };
        next[cacheKey] = { name: styleHit.name, id: styleHit.id, projectId: hitPid || null };
        writeStyleCache(next);
        show(`③ 已记录本机画风缓存：${styleHit.name} → ${styleHit.id}`);
      }
      if (!styleHit) {
        const reason = ((lastErr && lastErr.message) || `画风「${styleQuery}」不存在`)
          .split('\n')[0]
          .split('。可选')[0]
          .trim();
        throw new Error(
          '悠悠漫没有相应画风，请手动导入。\n' +
            `要求画风：${styleQuery}\n` +
            `原因：${reason}\n` +
            (live ? '' : '（未能读取客户端画风清单；请确认悠悠漫已启动并连通后重试）\n') +
            '可选出路：\n' +
            '  ① 直接给 ID：--style <style-xxx>（用 styles --all 可查，会打开全部项目标签）\n' +
            '  ② 加 --refresh-style 再探一次（最多查 3 个项目，会打开标签）\n' +
            '  ③ 在当前项目里先选一次该画风，再重跑\n' +
            `当前项目可用画风（含内置兜底）：\n${stylePool(options.length ? options : merged).map((p) => `  ${p.name}  ->  ${p.id}`).join('\n')}`
        );
      }
    } else if (!opts['allow-no-style']) {
      show('⚠ 未指定 --style：只导入分镜，不设置画风。若需画风请重跑并带 --style，或加 --allow-no-style 消除本提示。');
    }

    if (dry) {
      const plan = {
        projectName: projName,
        source: file,
        mcpDir: loc.mcpDir,
        project: existingId ? `复用 ${existingId}` : '新建',
        import: existingId ? (opts.reuse ? '覆盖重新导入' : '已有分镜则跳过（--reuse 覆盖）') : '导入',
        style: styleHit ? `${styleHit.name} → ${styleHit.id}` : '(未指定 --style)',
      };
      console.log(JSON.stringify(plan, null, 2));
      return plan;
    }

    let projectId = existingId;
    let chapterId = 'chapter-1';
    let created = false;

    if (projectId && !opts.new) {
      show(`① 复用项目：${name} → ${projectId}`);
    } else {
      const r = await client.call(
        'create_project',
        { name: projName, description: desc, requestId: rid('c', projName + (opts.new ? Date.now() : '')) },
        opts.timeout ? Number(opts.timeout) : 60000
      );
      projectId = first(first(r, ['project'], r), ['id', 'projectId']);
      chapterId = first(r, ['chapterId', 'chapter_id'], 'chapter-1') || 'chapter-1';
      created = true;
      if (!projectId) throw new Error('create_project 未返回 projectId：' + JSON.stringify(r).slice(0, 300));
      show(`① 新建项目：${name} → ${projectId} / ${chapterId}`);
    }

    const beforeRaw = parseMaybeJson(await client.call('get_project', { projectId }, 30000));
    const before = first(beforeRaw, ['project', 'data'], beforeRaw) || {};
    const pageCount = Number(first(before, ['pageCount', 'pages'], 0)) || 0;

    if (created || pageCount === 0 || opts.reimport || opts.reuse) {
      const r = await client.call(
        'import_storyboard',
        {
          projectId,
          chapterId,
          text: fs.readFileSync(importFile, "utf8"),
          requestId: rid('i', name + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6)),
        },
        300000
      );      const counts = first(r, ['counts'], {}) || {};
      show(`② 导入分镜：角色 ${first(counts, ['characters'], '?')} / 页 ${first(counts, ['pagePrompts', 'pages'], '?')}`);
    } else {
      show(`② 已有 ${pageCount} 页分镜，跳过导入（--reimport 强制重导）`);
    }

    let saved = null;
    if (styleHit) {
      const setRaw = parseMaybeJson(await client.call('get_settings', { projectId }, 30000));
      const settings = first(setRaw, ['settings', 'data'], setRaw) || {};
      const fields = first(settings, ['fields'], {}) || {};
      const revision = first(settings, ['revision', 'fieldsRevision']) ?? first(fields, ['revision']);
      const current = first(fields, ['selectedStyleProfileId']);
      if (current === styleHit.id) {
        show(`③ 画风已是目标值，跳过写入：${styleHit.name}`);
        saved = { ok: true, how: '已落库' };
      } else {
        await client.call(
          'manage_settings',
          {
            projectId,
            action: 'update',
            expectedRevision: revision,
            requestId: rid('s', name + styleHit.id),
            fields: { selectedStyleProfileId: styleHit.id },
          },
          60000
        );
        show(`③ 设置画风：${styleHit.name} → ${styleHit.id}`);
        saved = await persistSettings(client, projectId, rid('v', name + styleHit.id), styleHit.id);
        show(saved.ok ? `④ 保存设置：${saved.how}` : '④ 保存：无独立保存接口，按读回结果判定');
      }
    } else {
      show('③ 未指定 --style，跳过画风设置');
    }

    const projRaw = parseMaybeJson(await client.call('get_project', { projectId }, 30000));
    const finalProj = first(projRaw, ['project', 'data'], projRaw) || {};
    const setRaw = parseMaybeJson(await client.call('get_settings', { projectId }, 30000));
    const finalFields = first(first(setRaw, ['settings', 'data'], setRaw) || {}, ['fields'], {}) || {};
    const appliedStyle = first(finalFields, ['selectedStyleProfileId']);
    const result = {
      projectId,
      chapterId,
      projectName: first(finalProj, ['name'], name),
      pageCount: first(finalProj, ['pageCount', 'pages'], null),
      characterCount: first(finalProj, ['characterCount', 'characters'], null),
      storyboardReady: first(finalProj, ['storyboardReady'], null),
      selectedStyleProfileId: appliedStyle,
      styleMatched: styleHit ? appliedStyle === styleHit.id : null,
      settingsSaved: saved ? saved.ok : null,
      saveVia: saved ? saved.how : null,
    };
    if (opts.json) result.mcpDir = loc.mcpDir;
    console.log(JSON.stringify(result, null, 2));
    if (styleHit && appliedStyle !== styleHit.id) {
      console.error(`✘ 画风未生效：期望 ${styleHit.id}，实际 ${appliedStyle || '(空)'}。保存未完成，请重跑或检查设置页。`);
      process.exitCode = 2;
    }
    return result;
  } finally {
    client.close();
  }
}

/* ------------------------------ 入口 ------------------------------ */

async function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0] || 'doctor';
  const opts = parseArgs(argv.slice(1));

  if (cmd === 'help' || cmd === '-h' || cmd === '--help') {
    const src = fs.readFileSync(SELF, 'utf8');
    const a = src.indexOf('用法：');
    const b = src.indexOf('*/');
    console.log(a >= 0 && b > a ? src.slice(a, b).replace(/^\s*\*\s?/gm, '').trim() : '见 README.md');
    return;
  }

  if (cmd === 'locate') {
    const hits = installCandidates();
    if (!hits.length) {
      console.log('未找到悠悠漫安装（已扫描快捷方式、常见目录、各盘浅层）。');
      console.log('请手动指定：set YY_HOME=<安装根目录>（含 resources\\mcp\\server.mjs）');
      process.exitCode = 1;
      return;
    }
    if (opts.force) {
      const c = hits[0];
      writeCfg({ mcpDir: c.mcpDir, exe: c.exe || null, root: c.root || null });
    }
    console.log(JSON.stringify(hits, null, 2));
    return;
  }

  if (cmd === 'launch') {
    const exe = (opts.exe && opts.exe !== true ? winPath(opts.exe) : null) || locate(true)?.exe;
    if (!exe || !fs.existsSync(exe)) throw new Error('未识别客户端 EXE，请用 --exe "路径\\悠悠漫.exe" 指定');
    const p = spawn(exe, [], { detached: true, stdio: 'ignore', windowsHide: false });
    p.unref();
    console.log('已启动：' + exe);
    return;
  }

  let loc = locate(!!opts.force);
  if (!loc && cmd === 'doctor') loc = locate(true);
  if (!loc) throw new Error('未找到悠悠漫安装目录：先运行 locate --force，或设置环境变量 YY_HOME');

  if (cmd === 'doctor') {
    console.log(await cmdDoctor(loc));
    return;
  }
  if (cmd === 'run') {
    await cmdRun(opts);
    return;
  }

  const client = await connect(loc);
  try {
    if (cmd === 'style-check') {
      // 只读预检：缓存 → 本地索引 → 当前项目各查一次；不建项目、不改设置
      const q = (opts.name && opts.name !== true ? String(opts.name) : argv[1] && !String(argv[1]).startsWith('--') ? String(argv[1]) : '').trim();
      if (!q) throw new Error('用法：node yy.mjs style-check --name "<画风名或ID>"');
      const key = norm(q);
      const cache = readStyleCache();
      let hit = cache[key] ? { name: cache[key].name || q, id: cache[key].id, source: '本机缓存' } : null;
      if (!hit) {
        const arr = readLocalStyleIndex().get(key) || [];
        if (arr.length) {
          const cur = readCurrentProjectId();
          const pick = arr.find((c) => c.projectId === cur) || arr[0];
          hit = { name: pick.name, id: pick.id, source: '本地索引' };
        }
      }
      if (!hit) {
        const cur = readCurrentProjectId();
        if (cur) {
          try {
            const o = await client.call('list_generation_options', { projectId: cur }, 30000);
            const got = deepArray(o, ['styleProfiles', 'styles', 'options', 'items']);
            const h = resolveStyle(q, got);
            hit = { name: h.name, id: h.id, source: '当前项目' };
          } catch {
            /* miss */
          }
        }
      }
      if (hit) {
        console.log(opts.json ? JSON.stringify({ ok: true, ...hit }) : `✔ 画风可用：${hit.name} → ${hit.id}（来源：${hit.source}）`);
        return hit;
      }
      process.exitCode = 1;
      console.log(opts.json ? JSON.stringify({ ok: false, name: q }) : `✘ 客户端没有该画风：${q}`);
      return { ok: false, name: q };
    }
    if (cmd === 'styles' && opts.all) {
      // 优先读本地索引：零 UI 影响，不打开任何项目标签
      const idx = readLocalStyleIndex();
      if (idx.size) {
        const lines = [];
        for (const arr of idx.values()) {
          for (const s of arr) lines.push(`${s.name}\t${s.id}\t(${s.projectId})`);
        }
        console.log(lines.join('\n'));
        return;
      }
      // 本地读不到才退回 MCP（会逐个打开项目标签）
      const projects = await readProjectsCached(client);
      const seen = new Map();
      for (const p of projects) {
        const id = first(p, ['id', 'projectId', '_id']);
        if (!id) continue;
        const pname = String(first(p, ['name', 'title'], id));
        let got = [];
        try {
          const o = await client.call('list_generation_options', { projectId: id }, 30000);
          got = deepArray(o, ['styleProfiles', 'styles', 'options', 'items']);
        } catch {
          continue;
        }
        for (const s of stylePool(got)) {
          if (s.builtin) continue;
          if (!seen.has(s.id)) seen.set(s.id, { name: s.name, project: pname });
        }
      }
      console.log([...seen.entries()].map(([id, v]) => `${v.name}\t${id}\t(${v.project})`).join('\n'));
      return;
    }
    if (cmd === 'tools') {
      console.log((await client.listTools()).join('\n'));
    } else if (cmd === 'styles') {
      const pid = opts.project && opts.project !== true ? String(opts.project) : null;
      let options = [];
      if (pid) {
        try {
          const o = await client.call('list_generation_options', { projectId: pid }, 30000);
          options = deepArray(o, ['styleProfiles', 'styles', 'options', 'items']);
        } catch {}
      }
      const pool = stylePool(options);
      console.log(pool.map((p) => `${p.name}\t${p.id}${p.builtin ? '' : '\t(动态)'}`).join('\n'));
    } else if (cmd === 'call') {
      const tool = argv[1];
      const raw = argv[2] || '{}';
      const ams = opts.timeout ? Number(opts.timeout) : 120000;
      const res = await client.call(tool, JSON.parse(raw), ams);
      console.log(typeof res === 'string' ? res : JSON.stringify(res, null, 2));
    } else {
      throw new Error(`未知命令：${cmd}`);
    }
  } finally {
    client.close();
  }
}

main().catch((e) => {
  console.error('✘ ' + e.message);
  process.exitCode = 1;
});
