#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""设置本机的成品保存目录（写 config.json，不动 SKILL.md）。

用法：
    python scripts/setup_deliver.py --show                     # 看当前生效路径与来源
    python scripts/setup_deliver.py --desktop                  # 用桌面\YYM分镜稿
    python scripts/setup_deliver.py --path "<盘符>:\漫画\分镜稿"   # 指定目录
仅改本机 config.json；更新技能时该文件原地保留。
"""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config.json"
DEFAULT_DELIVER = Path.home() / "Desktop" / "YYM分镜稿"


def resolve():
    """返回 (路径, 来源)：环境变量 > config.json > BO-07 默认。"""
    env = os.environ.get("FENJING_DELIVER_DIR")
    if env:
        return Path(env), "环境变量 FENJING_DELIVER_DIR"
    if CONFIG.is_file():
        try:
            d = json.loads(CONFIG.read_text(encoding="utf-8"))
            if d.get("deliver_dir"):
                return Path(d["deliver_dir"]), "本机 config.json"
        except Exception:
            pass
    return DEFAULT_DELIVER, "BO-07 默认"


def write_cfg(path):
    data = {}
    if CONFIG.is_file():
        try:
            data = json.loads(CONFIG.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    data["deliver_dir"] = str(path)
    CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description="设置本机成品保存目录")
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--path", default=None, help="要使用的目录")
    ap.add_argument("--desktop", action="store_true", help="用 桌面\\YYM分镜稿")
    args = ap.parse_args(argv)

    cur, src = resolve()
    if args.desktop:
        home = Path(os.path.expanduser("~"))
        target = home / "Desktop" / "YYM分镜稿"
        write_cfg(target)
        print("已写入 %s：%s" % (CONFIG.name, target))
    elif args.path:
        target = Path(args.path)
        write_cfg(target)
        print("已写入 %s：%s" % (CONFIG.name, target))
    else:
        print("当前生效：%s（来源：%s）" % (cur, src))
        print("config.json：%s" % ("存在" if CONFIG.is_file() else "不存在"))
        if not args.show:
            print("提示：--desktop 用桌面目录，--path 指定其他目录。")
        return 0

    cur, src = resolve()
    print("复查：%s（来源：%s）" % (cur, src))
    try:
        cur.mkdir(parents=True, exist_ok=True)
        print("目录可用。")
    except Exception as e:
        print("目录暂时不可写（%s），请检查路径或盘符。" % e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
