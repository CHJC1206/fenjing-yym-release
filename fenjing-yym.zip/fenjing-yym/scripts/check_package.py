#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""发布前干净度自检：确认分发包不含个人信息、凭据、稿件残留，且必需文件齐全。

用法：
    python scripts/check_package.py
    python scripts/check_package.py --json
    python scripts/check_package.py --no-doctor     # 跳过 doctor 全绿检查

退出码：0 干净 / 1 有问题（不得发布）
只用标准库。
"""

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {"__pycache__", "_backup", ".git"}
TEXT_EXT = {".md", ".py", ".mjs", ".json", ".txt", ".js"}

REQUIRED = (
    "SKILL.md",
    "version.json",
    "安装与更新说明.md",
    "references/style-caiqian.md",
    "references/style-huochai.md",
    "scripts/prep_text.py",
    "scripts/audit_storyboard.py",
    "scripts/doctor.py",
    "scripts/guard_subskills.py",
    "scripts/update_check.py",
    "scripts/update_apply.py",
    "scripts/update.py",
    "scripts/publish_release.py",
    "scripts/grow_tables.py",
    "scripts/setup_deliver.py",
    "scripts/yy.mjs",
)

# 不允许出现在发布包里的文件（本机文件、测试产物、稿件）
FORBIDDEN_FILES = (
    "config.json",
    "_local_tables.md",
    "_gaps.json",
    "*.prep.json",
    "*.clean.txt",
    "*.replaced.txt",
    "*截断稿*.txt",
    "*.bak",
)

CHECKS = (
    ("盘符路径", r"(?<![A-Za-z0-9])[A-Za-z]:[\\/]{1,2}[A-Za-z_\u4e00-\u9fa5]"),
    ("用户目录", r"Users\\[A-Za-z0-9_.\-]{2,}"),
    ("微信路径", r"wxid_[A-Za-z0-9]+"),
    ("访问令牌", r"(ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|gho_[A-Za-z0-9]{20,})"),
    ("Bearer 头", r"Bearer\s+[A-Za-z0-9._\-]{20,}"),
    ("邮箱", r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
)
# 含这些标记的行视为说明性示例，放行
ALLOW_MARKS = ("<", "示例", "%USERPROFILE%", "Path.home()")
# 系统路径（非个人信息）放行
ALLOW_SYSTEM = (r"[A-Za-z]:[\\/]{1,2}ProgramData", r"[A-Za-z]:[\\/]{1,2}Program Files",
                r"[A-Za-z]:[\\/]{1,2}Windows", r"[A-Za-z]:[\\/]{1,2}Users[\\/]{1,2}Public")


def iter_text_files():
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        if SKIP_DIRS & set(p.relative_to(ROOT).parts):
            continue
        if p.suffix.lower() in TEXT_EXT:
            yield p


def scan_text():
    hits = []
    for p in iter_text_files():
        try:
            lines = p.read_text(encoding="utf-8", errors="replace").split("\n")
        except Exception:
            continue
        for i, line in enumerate(lines, 1):
            if any(m in line for m in ALLOW_MARKS):
                continue
            if any(re.search(pat, line) for pat in ALLOW_SYSTEM):
                continue
            for name, pat in CHECKS:
                m = re.search(pat, line)
                if m:
                    hits.append({
                        "项": name,
                        "文件": str(p.relative_to(ROOT)),
                        "行": i,
                        "命中": m.group(0)[:40],
                        "上下文": line.strip()[:70],
                    })
    return hits


def scan_files():
    bad = []
    for pat in FORBIDDEN_FILES:
        for p in ROOT.rglob(pat):
            if p.is_file() and not (SKIP_DIRS & set(p.relative_to(ROOT).parts)):
                bad.append(str(p.relative_to(ROOT)))
    for p in ROOT.rglob("*.txt"):
        if p.is_file() and not (SKIP_DIRS & set(p.relative_to(ROOT).parts)):
            bad.append(str(p.relative_to(ROOT)))
    return sorted(set(bad))


def main(argv=None):
    ap = argparse.ArgumentParser(description="发布前干净度自检")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--no-doctor", action="store_true", help="跳过 doctor 全绿检查")
    args = ap.parse_args(argv)

    missing = [f for f in REQUIRED if not (ROOT / f).is_file()]
    leaks = scan_text()
    stray = scan_files()

    doctor_ok, doctor_out = True, ""
    if not args.no_doctor:
        d = ROOT / "scripts" / "doctor.py"
        if d.is_file():
            r = subprocess.run([sys.executable, str(d)], capture_output=True, text=True)
            doctor_ok = r.returncode == 0
            doctor_out = (r.stdout or "").strip().splitlines()[-1] if (r.stdout or "").strip() else ""

    ok = not missing and not leaks and not stray and doctor_ok
    result = {"ok": ok, "missing": missing, "leaks": leaks, "stray": stray,
              "doctor_ok": doctor_ok, "doctor": doctor_out}

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if ok else 1

    print("== 发布前干净度自检 ==")
    print("必需文件：%s" % ("齐全（%d 项）" % len(REQUIRED) if not missing else "缺 " + "、".join(missing)))
    if leaks:
        print("\n[个人信息／凭据 %d 处]" % len(leaks))
        for h in leaks[:20]:
            print("  ✗ %-6s %s:%d  %s" % (h["项"], h["文件"], h["行"], h["上下文"]))
    else:
        print("个人信息／凭据：无")
    if stray:
        print("\n[不该进包的文件 %d 个]" % len(stray))
        for s in stray[:20]:
            print("  ✗ %s" % s)
    else:
        print("本机文件／测试产物：无")
    print("doctor：%s" % ("通过" if doctor_ok else ("未通过：" + doctor_out)))
    print("\n结论：%s" % ("干净，可以发布" if ok else "有问题，禁止发布"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
