> 本文件为阶段三执行细则，由主文件 `SKILL.md` 在需要导入时加载。脚本位置相对技能根目录。

# 阶段三 · 导入（内置脚本）

把一份完整的悠悠漫 Markdown 分镜稿导入客户端，并设置画风，全程走官方 MCP 通道。

## 适用与不适用

- 已有 `.md` 分镜导入稿（通常 91–99 页），需要导入悠悠漫并设画风。
- 需要给项目改名、换画风、重新导入。
- 需要在无人值守/批量场景下重复执行同一套导入操作。

不适用：生成分镜（那是 xiaoshuoman / manhuaxiaoshuo 等制作技能的事）、生成图片（消耗额度，需用户明确要求）。

## 前置条件

1. Node ≥ 18（`node -v` 确认）。
2. 悠悠漫客户端已安装。**不需要知道安装路径**，脚本会自动定位。
3. 客户端建议先启动；未启动时脚本会尝试用识别到的 EXE 拉起。

## 核心命令

脚本：`scripts/yy.mjs`（零依赖，可复制到任意目录运行）。下文用 `$YY` 代指其绝对路径。

```bash
node "$YY" doctor                                            # 自检：定位/客户端/MCP 连通
node "$YY" run --file "<导出稿绝对路径.md>" --style "<画风>"   # 一键导入
```

`run` 依次完成：查重 → 建项目（项目名＝md 文件名，可用 `--name` 覆盖）→ 导入完整分镜 → 写入画风 → 保存设置 → 读回校验。

常用参数：

| 参数 | 作用 |
|---|---|
| `--name "稿名"` | 项目名，默认 md 文件名去扩展名 |
| `--desc "备注"` | 项目描述 |
| `--style 现代Q版` | 画风，中文名/别名/ID 均可，见 `references/import-style-profiles.md` |
| `--reimport` | 强制重导分镜（默认已有页数则跳过） |
| `--new` | 同名项目已存在时仍另建一个 |
| `--dry-run` | 只打印计划，不写任何数据 |
| `--json` | 输出含定位信息的完整 JSON |

其余命令：`locate [--force]` 只定位、`launch` 启动客户端、`styles [--project <id>]` 列画风、`tools` 列全部 MCP 工具、`call <tool> '<json>'` 透传任意工具。

## 执行流程

1. 跑 `doctor`。看到 `MCP 连通 : ✔` 才继续；`未找到悠悠漫安装` 时先 `locate --force`，仍失败再设 `YY_HOME`（安装根目录，须含 `resources\mcp\server.mjs`）。
2. 跑 `run --file ... --style ...`。
3. 读 stdout 的 JSON，四项全绿才算完成：`pageCount > 0`、`storyboardReady: true`、`styleMatched: true`、`settingsSaved: true`。
4. 只回一句结论，例如：`已导入「1风雪封尽温柔2L」：99 页 / 8 角色，画风 Q版圆润火柴人（现代Q版）已保存。`

退出码：`0` 成功；`1` 定位/连接/参数错误（含画风阀门中止）；`2` 画风写入了但读回不一致（保存未生效），需重跑或检查设置页。

## 画风检测阀门

`run` 在**建项目之前**先解析画风。找不到对应画风时立即中止，不建项目、不导入任何页面，并输出：

```
悠悠漫没有相应画风，请手动导入。
要求画风：<传入值>
原因：<不存在 / 匹配到多个 / 未指定>
客户端可用画风：
  <名称>  ->  <id>
```

- 命中该提示时**不得改传近似画风重试**，也不得跳过画风继续导入；原样转达用户，由用户决定手动导入或在客户端新建该画风。
- 未传 `--style` 时只警告并导入分镜、不设画风；要静音加 `--allow-no-style`。
- 检测顺序：**每次任务现查，不缓存画风清单**。`list_generation_options` 必须带 `projectId`，先试目标项目，再借任一已有项目的 ID；都取不到才用内置 12 套兜底，并在提示里明示「未能读取客户端画风清单」。
- 悠悠漫升级新增画风后无需改脚本，下次 `run` 自动识别；仅当客户端里一个项目都没有时才会退回兜底判断。
- 折纸艺术／折纸立体不在内置表；客户端也没有时必然触发本阀门。

## 设计约束（不要绕过）

- **不写死安装路径**：定位顺序为 `YY_HOME` → 缓存 `%APPDATA%\yy-mcp\yy-mcp.json` → 解析桌面/开始菜单 `.lnk` → 常见安装目录 → 各盘浅层扫描。换机器无需改脚本。
- **画风不写死**：以客户端 `list_generation_options` 返回为准，内置 12 套仅作兜底；用户自建画风用 `style-<时间戳>-<随机>` ID。
- **幂等**：同名项目复用、已有页数跳过导入、画风已是目标值跳过写入。重复执行不会产生重复项目或重复页。
- **乐观锁**：写设置前现读 `revision`；`requestId` 由稿名+画风哈希派生，重试同号。
- **不做鼠标自动化**：客户端常以管理员权限运行，普通权限的模拟输入会被 UIPI 丢弃，只走 MCP。
- **不手改** `%APPDATA%\storyboard-image-generator` 下的 sqlite；**不删** `lockfile`（存在＝已有实例在跑，属单实例锁）。

## 故障排查

| 现象 | 处理 |
|---|---|
| `未找到悠悠漫安装` | `locate --force`；仍失败设 `YY_HOME` 或 `YY_EXE` |
| `MCP 连接失败` | 客户端没开：`launch`；确认 EXE 未被安全软件拦截 |
| 双击 EXE 立即退出（exit 0） | 已有实例在跑，直接用该实例 |
| `revision conflict` | 直接重跑，脚本会重读 revision |
| `styleMatched: false` | 画风未落库，重跑一次；仍失败检查设置页是否需手动保存 |
| 画风名匹配到多个 | 写全名或直接用 ID |
| 画风不存在（如萌系简笔） | 萌系简笔固定映射自定义「新画风」`style-1786700640159-52ncev`，直接用 ID 导入；其余画风按 `references/import-style-profiles.md` 映射表处理 |
| `import_storyboard` 报「需为 TXT 或 Markdown」 | 检查文件名：结尾全角句号会使扩展名变成「。md」；以正文首句命名时去掉末尾句号，改名后重跑 |

更多细节见 `references/import-style-profiles.md`（画风对照）与 `references/import-workflow.md`（可复制的步骤二模板）。

## 离线自测

无客户端时可用内置假服务验证链路：

```bash
node -e "const fs=require('fs'),os=require('os'),p=require('path');const d=p.join(os.tmpdir(),'yy-mock');fs.mkdirSync(d,{recursive:true});fs.copyFileSync('scripts/mock-server.mjs',p.join(d,'server.mjs'))"
YY_HOME="%TEMP%\yy-mock" node scripts/yy.mjs doctor
YY_HOME="%TEMP%\yy-mock" node scripts/yy.mjs run --file "<任意含 ## 第N页 的 md>" --style 现代Q版
```

`MOCK_SAVE_MODE=tool|action|none` 可切换保存入口形态以验证探测逻辑。
