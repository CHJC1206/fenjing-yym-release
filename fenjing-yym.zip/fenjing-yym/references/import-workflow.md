# 步骤二模板（可复制）

> 变量只有两个：`{{导出稿绝对路径}}`、`{{画风}}`。安装路径、项目 ID、画风 ID 全部自动解析。
> 用途：接在「一、制作分镜」之后，完成「二、导入悠悠漫并设画风」。

## 0 前置自检

```bash
node "$YY" doctor
```

| 输出 | 处理 |
|---|---|
| `MCP 连通 : ✔` | 进入第 1 步 |
| `未找到悠悠漫安装` | `node "$YY" locate --force`；仍失败 `set YY_HOME=<安装根目录>` |
| `MCP 连接失败` | `node "$YY" launch` 启动客户端后重试 |

EXE 双击立刻退出＝已有实例在跑（单实例锁），不是崩溃，不要删 `lockfile`。

## 1 一键导入

```bash
node "$YY" run --file "{{导出稿绝对路径}}" --style "{{画风}}"
```

覆盖原流程全部人工步骤：

| 原步骤 | 对应 |
|---|---|
| 打开桌面「悠悠漫」 | `launch` / `doctor` 检测 |
| 章节工作台新建项目 | `create_project` |
| 重命名为导出稿文件名 | 项目名默认取 md 文件名（`--name` 可覆盖） |
| 导入完整分镜文件 | `import_storyboard`（读本地绝对路径，正文不进上下文） |
| 设置 → 画风设定 → 选画风 | `list_generation_options` + `manage_settings update` |
| 点保存 | `persistSettings`：专用保存工具 → `save` 动作 → 已落库则跳过 |
| 返回工作台确认 | `get_project` + `get_settings` 读回校验 |

## 2 校验

```bash
# 读 run 的 stdout JSON
pageCount > 0  &&  storyboardReady: true  &&  styleMatched: true  &&  settingsSaved: true
```

## 3 常见变体

| 需求 | 做法 |
|---|---|
| 只换画风 | 同一条 `run`，导入会自动跳过 |
| 强制重导分镜 | 加 `--reimport` |
| 另建同名新项目 | 加 `--new` |
| 只预演不写入 | 加 `--dry-run` |
| 改名 | `call manage_project '{"projectId":"…","action":"rename","name":"新名"}'` |
| 清空章节 | `call manage_chapter '{"projectId":"…","chapterId":"chapter-1","action":"clear"}'` |

## 4 收尾话术

只报一行：`已导入「<稿名>」：<N> 页 / <M> 角色，画风 <界面名> 已保存。`

## 5 坑位速查

1. 路径：不写死，靠定位链 + 缓存。
2. revision 乐观锁：写前现读；冲突就重跑。
3. 单实例锁：勿重复启动、勿删 lockfile。
4. 不要鼠标自动化：UIPI 会丢弃普通权限的模拟输入。
5. 不要手改 `%APPDATA%\storyboard-image-generator` 下的 sqlite。
