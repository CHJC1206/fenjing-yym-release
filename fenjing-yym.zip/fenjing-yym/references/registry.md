# 画风注册表（唯一来源）

> 加一行即多一个画风：按「序」插入到想放的位置即可，页码自动顺延。
> `语法` 决定读哪份输出契约，`requires` 决定问哪些设置项。

## 画风表（翻页式：每页 3 个画风 + 第 4 格翻页）

规则：按「序」排列，每 3 个一页；每页第 4 格固定为 `下一页`，最后一页第 4 格为 `回到第一页`。加画风时按顺序插入，页码自动顺延，不用改别处。

| 序 | 页 | 显示名 | 语法 | 画面模式默认 | 映射悠悠漫 | 模块文件 | requires |
|---|---|---|---|---|---|---|---|
| 1 | 1/5 | 彩铅纸白 | caiqian | 纸白 | 彩铅手绘 | `styles/caiqian-zb.md` | layout, dialogue, paper, emphasis |
| 2 | 1/5 | 彩铅全彩 | caiqian | 全彩 | 彩铅全彩（无则钢笔淡彩手绘） | `styles/caiqian-qc.md` | layout, dialogue, paper, emphasis |
| 3 | 1/5 | 插画绘本 | caiqian | 纸白 | 插画绘本 | `styles/huiben.md` | layout, dialogue, paper, emphasis |
| 4 | 2/5 | 折纸艺术 | caiqian | 全彩 | 折纸艺术 | `styles/zhezhi-art.md` | layout, dialogue, emphasis |
| 5 | 2/5 | 折纸立体 | caiqian | 全彩 | 折纸立体 | `styles/zhezhi-3d.md` | layout, dialogue, emphasis |
| 6 | 2/5 | 现代Q版圆润 | huochai | — | Q版圆润火柴人 | `styles/qban-yuanrun.md` | layout, dialogue, emphasis |
| 7 | 3/5 | Q版火柴 | huochai | — | Q版火柴人 | `styles/qban.md` | layout, dialogue, emphasis |
| 8 | 3/5 | 古代Q版圆润 | huochai | — | Q版古言圆润火柴人 | `styles/qban-guyan-yuanrun.md` | layout, dialogue, emphasis |
| 9 | 3/5 | 古代Q版 | huochai | — | Q版古言火柴人 | `styles/qban-guyan.md` | layout, dialogue, emphasis |
| 10 | 4/5 | 都市言情火柴 | huochai | — | 都市言情火柴人 | `styles/dushi-yanqing.md` | layout, dialogue, emphasis |
| 11 | 4/5 | 新古风韩漫柔光 | huochai | — | 新古风韩漫柔光 | `styles/xin-gufeng-hanman.md` | layout, dialogue, emphasis |
| 12 | 4/5 | 清新韩漫 | huochai | — | 清新韩漫 | `styles/qingxin-hanman.md` | layout, dialogue, emphasis |
| 13 | 5/5 | 悬疑火柴人 | huochai | — | 实感火柴人 | `styles/xuanyi-shigan.md` | layout, dialogue, emphasis |

**别名**：客户端「新画风」等同 `现代Q版圆润`（同一份模块），不单独占格。

## 设置项（按 requires 动态出卡，每卡 ≤4 选项）

| 键 | 设置 | 选项 |
|---|---|---|
| layout | 排版 | 多构图 ／ 上文下图 ／ 上图下文 ／ 上下两格 |
| dialogue | 对白框 | 自行决定 ／ 关闭 |
| mode | 画面模式 | 纸白 ／ 全彩（选择后成为本次设定，不再另问） |
| paper | 底纸颜色 | 白 ／ 暖米白 ／ 浅灰米色 ／ 自定义 |
| texture | 纸纹 | **固定关闭**（全部画风默认关，用户明确要求才开，不单独询问） |
| emphasis | 重点标红 | 开启 ／ 关闭（默认关闭） |

**固定项（不问）**：第 1 页必为单页大图；开头结尾沿用原文；画面比例 3:4。

## 选风后的必做动作

1. 跑 `node scripts/yy.mjs style-check --name "<映射悠悠漫列的值>"`，退出码 0 才继续（未命中弹卡：换画风／继续但导入手选／中止）
2. 只读白名单：`core/*` ＋ 本次 `styles/<该画风>.md`；其余 styles 不得引用
3. 输出契约按 `语法` 列选择 `core/output-caiqian.md` 或 `core/output-huochai.md`
