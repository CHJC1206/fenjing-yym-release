# 脚本清单与降级

> 需要确认「哪个脚本干什么」「失败时怎么降级」时读；日常按 SKILL.md 给的命令直接跑即可。

| 脚本 | 时机 | 用途 |
|---|---|---|
| `scripts/doctor.py` | 开工前 | 环境自检：Python 版本、两个制作库存在性、入口守卫、成品目录、编码、状态目录可写 |
| `scripts/prep_text.py` | 阶段一 | 清洗、书名删除（`--title`）、疑似简介检测与强制确认（`--drop`／`--drop-lines`／`--keep-intro`／`--intro-deep`）、字数门槛、候选截断与 `--cut` 落地、BO-01 全部替换（含题材判定 `--genre`、上床判定）、`--rewrite-file` 改句 |
| `scripts/audit_storyboard.py` | 交付前／分段自校 | 页数、页码、空镜、文字项、替换字与床／凶／血／巴掌／耳光 残留、删除线、手机逻辑、敏感词、第1页构图、制服与阵营与称谓、画面过程词、单页 220 字上限；`--json` 摘要、`--excerpt` 摘录、`--strict` 升级、`--allow-partial` 分段 |
| `scripts/yy.mjs` | 阶段三 | 导入悠悠漫：定位、建项目、导入分镜、设画风、保存、校验 |
| `scripts/mock-server.mjs` | 离线自测 | 无客户端时验证导入链路 |
| `scripts/update_check.py` | 触发「更新技能」 | 只读比对版本（BO-09），不下载不解压 |
| `scripts/update_apply.py` | 确认更新后 | 备份→校验→解压→自检→覆盖，失败自动回滚（支持本地目录与 http(s) 源） |
| `scripts/update.py` | 一键更新 | 检查→计划→询问→执行，一条命令走完 |
| `scripts/publish_release.py` | 发布端 | 自检→写版本→打包→写出带 sha256 与 package_url 的 version.json |
| `scripts/check_package.py` | 发布前 | 干净度自检：个人信息／凭据／本机文件／必需文件／doctor |
| `scripts/grow_tables.py` | 本机调偏好 | 维护 `_local_tables.md`（`--list` / `--local` / `--remove`） |
| `scripts/setup_deliver.py` | 换机／首次安装 | 写本机 `config.json` 的成品目录（`--show` / `--desktop` / `--path`） |

脚本只用 Python 标准库，需 3.7 或以上。无法执行脚本时仍可完成任务，但必须明确声明「程序校验未执行」，并改用人工逐项核对，不得宣称已通过全部检查。

