# 画风对照与传参

## 传参方式

`--style` 接受三种写法，大小写、空格、括号不敏感：

| 写法 | 示例 |
|---|---|
| 中文名（推荐） | `现代Q版`、`彩铅`、`国风言情`、`上文下图` |
| 完整界面名 | `"Q版圆润火柴人（现代Q版）"` |
| 精确 ID | `style-qban-yuanrun-huochairen` |

解析顺序：ID 精确匹配 → 界面名归一化匹配 → 别名表 → 唯一包含匹配 → 失败时列出全部候选。
**客户端 `list_generation_options` 返回的 ID 才是权威值**，内置表仅在没有项目可查时兜底；用户自建画风形如 `style-<时间戳>-<随机>`，必须用 ID。

## 内置 12 套

| 界面名 | 常用别名 | ID |
|---|---|---|
| Q版圆润火柴人（现代Q版） | 现代Q版、圆润火柴人 | `style-qban-yuanrun-huochairen` |
| Q版火柴人（现代酷版） | 现代酷版、Q版火柴 | `style-qban-huochairen` |
| Q版古言圆润火柴人 | 古代Q版 | `style-qban-guyan-yuanrun-huochairen` |
| Q版古言火柴人 | 古代酷版 | `style-qban-guyan-huochairen` |
| 实感火柴人 | 实感 | `style-shigan-huochairen` |
| 都市言情火柴人 | 都市言情 | `style-dushi-yanqing-huochairen-mingliang-jingzhi` |
| 彩铅手绘 | 彩铅、第一遍制作、彩铅纸白+第一次 | `style-caiqian-shouhui` |
| 彩铅全彩 | 彩铅全彩+第二次 | 客户端有同名项则用其 ID；无则回退 `style-gangbi-dancai-shouhui`（钢笔淡彩手绘），不映射到「彩铅手绘」 |
| 钢笔淡彩手绘 | 钢笔淡彩、第二遍制作 | `style-gangbi-dancai-shouhui` |
| 清新韩漫 | 韩漫、韩漫言情 | `style-default` |
| 新古风韩漫柔光 | 国风言情、古风言情 | `style-xin-gufeng-hanman-rouguang` |
| 上文下图 | — | `style-1791256111967-z10s9d` |
| 自定义「新画风」 | 新画风 | `style-1786700640159-52ncev` |

## 分镜稿画风在客户端无同名项时的映射

`run` 报「画风不存在」时按此表映射；表中「固定映射」项无需选项卡确认，其余先确认再用。

| 分镜稿画风 | 客户端映射 | 传参 |
|---|---|---|
| 萌系简笔（manhuaxiaoshuo，固定映射） | 自定义「新画风」 | `--style style-1786700640159-52ncev` |
| 折纸艺术（xiaoshuoman） | 内置 12 套无同名项，需查客户端实际值 | 先 `node "$YY" styles --project <id>`；有同名或等价项用其 ID，无则列候选让用户选，禁止自动映射到「彩铅手绘」等近似画风 |
| 折纸立体（xiaoshuoman） | 同上 | 同上，不得与「折纸艺术」互相替代 |

- 萌系简笔固定映射到自定义「新画风」，不弹确认卡；客户端无此 ID 时才列候选让用户选。
- 「折纸艺术」「折纸立体」是两套独立画风，客户端若只装了其中一套，另一套必须报缺失并让用户决定，不做替换。
- 两者都不改变全彩／纸白、排版与对白设置，导入时只处理画风项。
- 自建画风必须用 ID 传参（`style-<时间戳>-<随机>`），中文名仅在该客户端存在同名别名时可用。
- `run` 结果里 `pageCount/storyboardReady` 可能为 `null`，用 `call get_project '{"projectId":"…"}'` 读回 `pageCount` 与 `storyboardReady` 补校验。

## 自定义画风是「项目级」的（重要）

`list_generation_options` 按项目返回画风清单：**自定义画风只在创建它的那个项目里可见**，换个项目就查不到，客户端设置里也看不到。

### 三层解析（目标是「零标签」）

| 顺序 | 来源 | 是否打开项目标签 |
|---|---|---|
| 1 | 本机缓存 `%APPDATA%\yy-mcp\style-cache.json` | 0 |
| 2 | **客户端本地索引**：直接读 `%APPDATA%\storyboard-image-generator\desktop-records-v1\records.sqlite` 里各项目的 `uiConfig` 记录，抽出 `styleProfiles` | **0**（纯读文件） |
| 3 | 仍无 → 只查「当前已打开的项目」1 个（`--refresh-style` 时最多 3 个） | 0～3 |
| 4 | 全失败 → 报错并给出路（`--style <ID>` / `--refresh-style` / 先在当前项目选一次） | — |

本地索引里同名画风可能有多个（不同项目各建过一个），会按 **当前项目 → 同名项目 → 最近更新的项目** 自动挑选，并在输出里提示候选数量；要精确指定就传 `--style <style-xxx>`。

### 查询命令（都是零标签）

```bash
node "$YY" styles --all            # 读本地索引，列出所有项目的画风（不打开标签）
node "$YY" styles --project <id>   # 看单个项目的画风
```

只有本地索引读不到（例如客户端换了存储格式）时，`--all` 才会退回逐个调用 MCP——那种情况会打开项目标签。

**「插画绘本」是自定义画风**，本机存在同名两条（不同项目各建过），实际使用 `style-1794928584658-rvjhsk`。换机器时该 ID 不存在，对方需在自己客户端里建同名画风，或按上面三层解析自动检索。

## 查真实值

```bash
node "$YY" styles --project <项目id>   # 有项目时取客户端真实列表，末列 (动态) 为动态项
node "$YY" call list_generation_options '{"projectId":"<项目id>"}'
```

## 保存设置

选完画风必须落库，脚本自动完成，结果在 `saveVia`：

| 值 | 含义 |
|---|---|
| `save_settings` / `commit_settings` 等 | 调用客户端专用保存工具 |
| `manage_settings:save` | 调用设置工具的 save 动作 |
| `update 已落库` | 写入即生效，跳过保存 |
| `null` | 无保存入口，靠读回校验兜底（`styleMatched` 仍为 true 即可接受） |
