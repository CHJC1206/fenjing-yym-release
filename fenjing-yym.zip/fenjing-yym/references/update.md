# 更新与同步（细则）

> 本文件仅在用户明确要求更新技能时读取；任务流程不读它。

**触发词**：`更新技能` / `检查更新` / `同步分发包` / `拉新版`。命中即只做更新，**不读小说、不清洗、不弹画风选项卡**；没有这些词时，即使远端有新版本也不主动检查、不提示。

**两步确认**：

1. `python scripts/update.py`（推荐）—— 一条命令完成：检查 → 有新版本就打印计划 → 询问 → 更新。加 `--yes` 不问；`--check` 只看不更。
2. 需要分步时：`python scripts/update_check.py`（只读比对，退出码 0 已最新／1 有新版本／2 无法访问）→ `python scripts/update_apply.py --dry-run`（打印备份位置、包 sha256、将保留的本地文件）→ 用户同意后 `--apply`。

**apply 内部顺序**：备份 → 校验 sha256 → 解压到临时目录 → 必需文件校验 → 临时目录跑 `doctor.py` → 覆盖 → 再跑一次 `doctor.py`；任一步失败自动回滚到更新前版本，备份目录保留供核对。

**本地文件保护**：`_local_tables.md`、`_gaps.json`、`config.json` 原地保留、不被覆盖。本机偏好一律写在 `_local_tables.md`，**不要直接改 `SKILL.md`**——它属于更新包的必需文件，每次更新都会被覆盖。

**无法访问更新源**：原样告知「无法访问更新源：<路径>」，并指向 BO-09；不得假装已是最新，也不得改用网络搜索兜底。

**发布端**（只有本机用）：`python scripts/publish_release.py --out "<发布目录>" [--version X] [--notes "..."] [--base-url "<raw 根地址>"]`。它会**先跑 `check_package.py` 干净度自检**（个人信息／凭据／本机文件／doctor），不通过就中止；然后写入版本号、打包、算 sha256、产出 `version.json`。**版本号规则**：`日期.当天第几次`，如 `2026.11.19.1`、`2026.11.19.2`；跨天自动回到 `.1`，由 `publish_release.py` 自动算，不用手填。版本号只在 `version.json` 维护，SKILL.md 不重复写。

**远程源（公开仓库）**：`--source` 可直接给 http(s) 根地址（如 `https://raw.githubusercontent.com/<owner>/<repo>/main`），脚本自动补 `/version.json`；`version.json` 里的 `package_url` 指向安装包直链，`update_apply` 会下载并按 sha256 校验。**发布前必须确认包内不含任何本机路径、令牌与稿件残留**——这是公开仓库唯一的硬性要求。

### 【后门 BO-09｜更新源】

<!-- 维护：换网盘／换盘符只改这一处，发布目录与 update_check/update_apply 的 --source 同此 -->

默认更新源：`https://raw.githubusercontent.com/CHJC1206/fenjing-yym-release/main`（公开仓库，匿名可读，无需令牌）。

取值顺序：`--source` 参数 > 环境变量 `FENJING_UPDATE_SOURCE` > 本机 `config.json` 的 `update_source` > 上面这个默认值。换发布仓库只改这一行，或让对方在本机 `config.json` 覆盖。对方机器必须能访问该路径；访问不到时报「无法访问更新源」，改用手动传包，不做网络兜底。



## 更新方式（2026.11.20.2 起）

**全覆盖**：解压到临时目录 → 校验必需文件 → 临时目录跑 doctor → 备份当前目录 → **删除新包中不存在的旧文件** → 整包铺开 → 覆盖后 doctor 自检 → 写版本号。失败自动回滚，且不写版本号。

保留在本地、不参与覆盖：`config.json`、`_local_tables.md`、`_gaps.json`。

`doctor.py` 的 `layout` 项会校验「版本与结构是否一致」：若仍有 `style-caiqian.md` / `style-huochai.md`，或缺 `references/core`、`references/styles`，直接硬失败，避免出现「版本号新、文件旧」。
